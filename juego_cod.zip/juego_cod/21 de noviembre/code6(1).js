gdjs.ser_95nivel3Code = {};
gdjs.ser_95nivel3Code.forEachIndex2 = 0;

gdjs.ser_95nivel3Code.forEachObjects2 = [];

gdjs.ser_95nivel3Code.forEachTemporary2 = null;

gdjs.ser_95nivel3Code.forEachTotalCount2 = 0;

gdjs.ser_95nivel3Code.GDpersonajeObjects1= [];
gdjs.ser_95nivel3Code.GDpersonajeObjects2= [];
gdjs.ser_95nivel3Code.GDpersonajeObjects3= [];
gdjs.ser_95nivel3Code.GDpersonajeObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto1aObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto1aObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto1aObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto1aObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto1bObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto1bObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto1bObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto1bObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto2aObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto2aObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto2aObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto2aObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto2bObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto2bObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto2bObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto2bObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto3aObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto3aObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto3aObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto3aObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto3bObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto3bObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto3bObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto3bObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto4aObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto4aObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto4aObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto4aObjects4= [];
gdjs.ser_95nivel3Code.GDobjeto4bObjects1= [];
gdjs.ser_95nivel3Code.GDobjeto4bObjects2= [];
gdjs.ser_95nivel3Code.GDobjeto4bObjects3= [];
gdjs.ser_95nivel3Code.GDobjeto4bObjects4= [];
gdjs.ser_95nivel3Code.GDop1Objects1= [];
gdjs.ser_95nivel3Code.GDop1Objects2= [];
gdjs.ser_95nivel3Code.GDop1Objects3= [];
gdjs.ser_95nivel3Code.GDop1Objects4= [];
gdjs.ser_95nivel3Code.GDop2Objects1= [];
gdjs.ser_95nivel3Code.GDop2Objects2= [];
gdjs.ser_95nivel3Code.GDop2Objects3= [];
gdjs.ser_95nivel3Code.GDop2Objects4= [];
gdjs.ser_95nivel3Code.GDop3Objects1= [];
gdjs.ser_95nivel3Code.GDop3Objects2= [];
gdjs.ser_95nivel3Code.GDop3Objects3= [];
gdjs.ser_95nivel3Code.GDop3Objects4= [];
gdjs.ser_95nivel3Code.GDop4Objects1= [];
gdjs.ser_95nivel3Code.GDop4Objects2= [];
gdjs.ser_95nivel3Code.GDop4Objects3= [];
gdjs.ser_95nivel3Code.GDop4Objects4= [];
gdjs.ser_95nivel3Code.GDvacioObjects1= [];
gdjs.ser_95nivel3Code.GDvacioObjects2= [];
gdjs.ser_95nivel3Code.GDvacioObjects3= [];
gdjs.ser_95nivel3Code.GDvacioObjects4= [];
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects1= [];
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects2= [];
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects3= [];
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects4= [];
gdjs.ser_95nivel3Code.GDNivelObjects1= [];
gdjs.ser_95nivel3Code.GDNivelObjects2= [];
gdjs.ser_95nivel3Code.GDNivelObjects3= [];
gdjs.ser_95nivel3Code.GDNivelObjects4= [];
gdjs.ser_95nivel3Code.GDParejasObjects1= [];
gdjs.ser_95nivel3Code.GDParejasObjects2= [];
gdjs.ser_95nivel3Code.GDParejasObjects3= [];
gdjs.ser_95nivel3Code.GDParejasObjects4= [];
gdjs.ser_95nivel3Code.GDposicionObjects1= [];
gdjs.ser_95nivel3Code.GDposicionObjects2= [];
gdjs.ser_95nivel3Code.GDposicionObjects3= [];
gdjs.ser_95nivel3Code.GDposicionObjects4= [];
gdjs.ser_95nivel3Code.GDtextoObjects1= [];
gdjs.ser_95nivel3Code.GDtextoObjects2= [];
gdjs.ser_95nivel3Code.GDtextoObjects3= [];
gdjs.ser_95nivel3Code.GDtextoObjects4= [];
gdjs.ser_95nivel3Code.GDparticulasObjects1= [];
gdjs.ser_95nivel3Code.GDparticulasObjects2= [];
gdjs.ser_95nivel3Code.GDparticulasObjects3= [];
gdjs.ser_95nivel3Code.GDparticulasObjects4= [];
gdjs.ser_95nivel3Code.GDnivelObjects1= [];
gdjs.ser_95nivel3Code.GDnivelObjects2= [];
gdjs.ser_95nivel3Code.GDnivelObjects3= [];
gdjs.ser_95nivel3Code.GDnivelObjects4= [];
gdjs.ser_95nivel3Code.GDregresarObjects1= [];
gdjs.ser_95nivel3Code.GDregresarObjects2= [];
gdjs.ser_95nivel3Code.GDregresarObjects3= [];
gdjs.ser_95nivel3Code.GDregresarObjects4= [];
gdjs.ser_95nivel3Code.GDmototextoObjects1= [];
gdjs.ser_95nivel3Code.GDmototextoObjects2= [];
gdjs.ser_95nivel3Code.GDmototextoObjects3= [];
gdjs.ser_95nivel3Code.GDmototextoObjects4= [];
gdjs.ser_95nivel3Code.GDcarrotextoObjects1= [];
gdjs.ser_95nivel3Code.GDcarrotextoObjects2= [];
gdjs.ser_95nivel3Code.GDcarrotextoObjects3= [];
gdjs.ser_95nivel3Code.GDcarrotextoObjects4= [];
gdjs.ser_95nivel3Code.GDambutextoObjects1= [];
gdjs.ser_95nivel3Code.GDambutextoObjects2= [];
gdjs.ser_95nivel3Code.GDambutextoObjects3= [];
gdjs.ser_95nivel3Code.GDambutextoObjects4= [];
gdjs.ser_95nivel3Code.GDtrentextoObjects1= [];
gdjs.ser_95nivel3Code.GDtrentextoObjects2= [];
gdjs.ser_95nivel3Code.GDtrentextoObjects3= [];
gdjs.ser_95nivel3Code.GDtrentextoObjects4= [];

gdjs.ser_95nivel3Code.conditionTrue_0 = {val:false};
gdjs.ser_95nivel3Code.condition0IsTrue_0 = {val:false};
gdjs.ser_95nivel3Code.condition1IsTrue_0 = {val:false};
gdjs.ser_95nivel3Code.condition2IsTrue_0 = {val:false};


gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDvacioObjects2Objects = Hashtable.newFrom({"vacio": gdjs.ser_95nivel3Code.GDvacioObjects2});
gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDpersonajeObjects2Objects = Hashtable.newFrom({"personaje": gdjs.ser_95nivel3Code.GDpersonajeObjects2});
gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop1Objects2Objects = Hashtable.newFrom({"op1": gdjs.ser_95nivel3Code.GDop1Objects2});
gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop2Objects2Objects = Hashtable.newFrom({"op2": gdjs.ser_95nivel3Code.GDop2Objects2});
gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop3Objects2Objects = Hashtable.newFrom({"op3": gdjs.ser_95nivel3Code.GDop3Objects2});
gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop4Objects1Objects = Hashtable.newFrom({"op4": gdjs.ser_95nivel3Code.GDop4Objects1});
gdjs.ser_95nivel3Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if ( gdjs.ser_95nivel3Code.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length;i<l;++i) {
    if ( gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].isCurrentAnimationName("parpadeo") ) {
        gdjs.ser_95nivel3Code.condition1IsTrue_0.val = true;
        gdjs.ser_95nivel3Code.GDpersonajeObjects2[k] = gdjs.ser_95nivel3Code.GDpersonajeObjects2[i];
        ++k;
    }
}
gdjs.ser_95nivel3Code.GDpersonajeObjects2.length = k;}}
if (gdjs.ser_95nivel3Code.condition1IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("vacio"), gdjs.ser_95nivel3Code.GDvacioObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDvacioObjects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("objeto1a"), gdjs.ser_95nivel3Code.GDobjeto1aObjects2);
gdjs.copyArray(runtimeScene.getObjects("objeto2a"), gdjs.ser_95nivel3Code.GDobjeto2aObjects2);
gdjs.copyArray(runtimeScene.getObjects("objeto3a"), gdjs.ser_95nivel3Code.GDobjeto3aObjects2);
gdjs.copyArray(runtimeScene.getObjects("objeto4a"), gdjs.ser_95nivel3Code.GDobjeto4aObjects2);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("parpadeo");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects2[i].setAnimationName("front");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDpersonajeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.ser_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.ser_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDpersonajeObjects2 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("cerrados");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("parpadeo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("op1"), gdjs.ser_95nivel3Code.GDop1Objects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop1Objects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("op1");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("op2"), gdjs.ser_95nivel3Code.GDop2Objects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop2Objects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("op2");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("op3"), gdjs.ser_95nivel3Code.GDop3Objects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop3Objects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("op3");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("op4"), gdjs.ser_95nivel3Code.GDop4Objects1);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDop4Objects1Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects1);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects1[i].setAnimationName("op4");
}
}}

}


};gdjs.ser_95nivel3Code.eventsList1 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\que animal quieres ser.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects2[i].setAnimationName("quieto");
}
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto1aObjects3ObjectsGDgdjs_46ser_9595nivel3Code_46GDobjeto2aObjects3ObjectsGDgdjs_46ser_9595nivel3Code_46GDobjeto3aObjects3ObjectsGDgdjs_46ser_9595nivel3Code_46GDobjeto4aObjects3Objects = Hashtable.newFrom({"objeto1a": gdjs.ser_95nivel3Code.GDobjeto1aObjects3, "objeto2a": gdjs.ser_95nivel3Code.GDobjeto2aObjects3, "objeto3a": gdjs.ser_95nivel3Code.GDobjeto3aObjects3, "objeto4a": gdjs.ser_95nivel3Code.GDobjeto4aObjects3});
gdjs.ser_95nivel3Code.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.ser_95nivel3Code.GDobjeto1aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto2aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto3aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto4aObjects3 */

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto1aObjects3ObjectsGDgdjs_46ser_9595nivel3Code_46GDobjeto2aObjects3ObjectsGDgdjs_46ser_9595nivel3Code_46GDobjeto3aObjects3ObjectsGDgdjs_46ser_9595nivel3Code_46GDobjeto4aObjects3Objects);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto1aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto2aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto3aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto4aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDposicionObjects3 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDposicionObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDposicionObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.ser_95nivel3Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objeto1a"), gdjs.ser_95nivel3Code.GDobjeto1aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto2a"), gdjs.ser_95nivel3Code.GDobjeto2aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto3a"), gdjs.ser_95nivel3Code.GDobjeto3aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto4a"), gdjs.ser_95nivel3Code.GDobjeto4aObjects3);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length;i<l;++i) {
    if ( gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].isCurrentAnimationName("front") ) {
        gdjs.ser_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.ser_95nivel3Code.GDobjeto1aObjects3[k] = gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i];
        ++k;
    }
}
gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length = k;for(var i = 0, k = 0, l = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length;i<l;++i) {
    if ( gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].isCurrentAnimationName("front") ) {
        gdjs.ser_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.ser_95nivel3Code.GDobjeto2aObjects3[k] = gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i];
        ++k;
    }
}
gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length = k;for(var i = 0, k = 0, l = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length;i<l;++i) {
    if ( gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].isCurrentAnimationName("front") ) {
        gdjs.ser_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.ser_95nivel3Code.GDobjeto3aObjects3[k] = gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i];
        ++k;
    }
}
gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length = k;for(var i = 0, k = 0, l = gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length;i<l;++i) {
    if ( gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i].isCurrentAnimationName("front") ) {
        gdjs.ser_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.ser_95nivel3Code.GDobjeto4aObjects3[k] = gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i];
        ++k;
    }
}
gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length = k;}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto1aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto2aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto3aObjects3 */
/* Reuse gdjs.ser_95nivel3Code.GDobjeto4aObjects3 */
gdjs.copyArray(gdjs.ser_95nivel3Code.GDposicionObjects2, gdjs.ser_95nivel3Code.GDposicionObjects3);

{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
}
{ //Subevents
gdjs.ser_95nivel3Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.ser_95nivel3Code.eventsList4 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ser_95nivel3Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("posicion"), gdjs.ser_95nivel3Code.GDposicionObjects1);

for(gdjs.ser_95nivel3Code.forEachIndex2 = 0;gdjs.ser_95nivel3Code.forEachIndex2 < gdjs.ser_95nivel3Code.GDposicionObjects1.length;++gdjs.ser_95nivel3Code.forEachIndex2) {
gdjs.ser_95nivel3Code.GDposicionObjects2.length = 0;


gdjs.ser_95nivel3Code.forEachTemporary2 = gdjs.ser_95nivel3Code.GDposicionObjects1[gdjs.ser_95nivel3Code.forEachIndex2];
gdjs.ser_95nivel3Code.GDposicionObjects2.push(gdjs.ser_95nivel3Code.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.ser_95nivel3Code.eventsList3(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto1aObjects3Objects = Hashtable.newFrom({"objeto1a": gdjs.ser_95nivel3Code.GDobjeto1aObjects3});
gdjs.ser_95nivel3Code.eventsList5 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto1aObjects3 */
gdjs.copyArray(runtimeScene.getObjects("objeto1b"), gdjs.ser_95nivel3Code.GDobjeto1bObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto2a"), gdjs.ser_95nivel3Code.GDobjeto2aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto3a"), gdjs.ser_95nivel3Code.GDobjeto3aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto4a"), gdjs.ser_95nivel3Code.GDobjeto4aObjects3);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1bObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1bObjects3[i].getBehavior("Tween").addObjectPositionTween("block", (( gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto1aObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto1aObjects3[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1bObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1bObjects3[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects3[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\grillo.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ob1");
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto1bObjects2Objects = Hashtable.newFrom({"objeto1b": gdjs.ser_95nivel3Code.GDobjeto1bObjects2});
gdjs.ser_95nivel3Code.eventsList6 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\otra opcion.mp3", false, 100, 1);
}}

}


};gdjs.ser_95nivel3Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objeto1a"), gdjs.ser_95nivel3Code.GDobjeto1aObjects3);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if ( gdjs.ser_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto1aObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.ser_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto1aObjects3 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].setAnimationName("select");
}
}
{ //Subevents
gdjs.ser_95nivel3Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob1") <= 0;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("vacio");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob1") >= 5;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("grillo");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob1") >= 13;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "ob1");
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("vacio2");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objeto1b"), gdjs.ser_95nivel3Code.GDobjeto1bObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto1bObjects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ser_95nivel3Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto2aObjects3Objects = Hashtable.newFrom({"objeto2a": gdjs.ser_95nivel3Code.GDobjeto2aObjects3});
gdjs.ser_95nivel3Code.eventsList8 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("objeto1a"), gdjs.ser_95nivel3Code.GDobjeto1aObjects3);
/* Reuse gdjs.ser_95nivel3Code.GDobjeto2aObjects3 */
gdjs.copyArray(runtimeScene.getObjects("objeto2b"), gdjs.ser_95nivel3Code.GDobjeto2bObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto3a"), gdjs.ser_95nivel3Code.GDobjeto3aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto4a"), gdjs.ser_95nivel3Code.GDobjeto4aObjects3);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2bObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2bObjects3[i].getBehavior("Tween").addObjectPositionTween("block", (( gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto2aObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto2aObjects3[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2bObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2bObjects3[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects3[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\leon.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ob2");
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto2bObjects2Objects = Hashtable.newFrom({"objeto2b": gdjs.ser_95nivel3Code.GDobjeto2bObjects2});
gdjs.ser_95nivel3Code.eventsList9 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\otra opcion.mp3", false, 100, 1);
}}

}


};gdjs.ser_95nivel3Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objeto2a"), gdjs.ser_95nivel3Code.GDobjeto2aObjects3);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if ( gdjs.ser_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto2aObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.ser_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto2aObjects3 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].setAnimationName("select");
}
}
{ //Subevents
gdjs.ser_95nivel3Code.eventsList8(runtimeScene);} //End of subevents
}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob2") <= 0;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("vacio");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob2") >= 5;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("leon");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob2") >= 13;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "ob2");
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("vacio2");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objeto2b"), gdjs.ser_95nivel3Code.GDobjeto2bObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto2bObjects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ser_95nivel3Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto3aObjects3Objects = Hashtable.newFrom({"objeto3a": gdjs.ser_95nivel3Code.GDobjeto3aObjects3});
gdjs.ser_95nivel3Code.eventsList11 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("objeto1a"), gdjs.ser_95nivel3Code.GDobjeto1aObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto2a"), gdjs.ser_95nivel3Code.GDobjeto2aObjects3);
/* Reuse gdjs.ser_95nivel3Code.GDobjeto3aObjects3 */
gdjs.copyArray(runtimeScene.getObjects("objeto3b"), gdjs.ser_95nivel3Code.GDobjeto3bObjects3);
gdjs.copyArray(runtimeScene.getObjects("objeto4a"), gdjs.ser_95nivel3Code.GDobjeto4aObjects3);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3bObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3bObjects3[i].getBehavior("Tween").addObjectPositionTween("block", (( gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto3aObjects3[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto3aObjects3[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3bObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3bObjects3[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects3[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects3[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\pez.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ob3");
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto3bObjects2Objects = Hashtable.newFrom({"objeto3b": gdjs.ser_95nivel3Code.GDobjeto3bObjects2});
gdjs.ser_95nivel3Code.eventsList12 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\otra opcion.mp3", false, 100, 1);
}}

}


};gdjs.ser_95nivel3Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objeto3a"), gdjs.ser_95nivel3Code.GDobjeto3aObjects3);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if ( gdjs.ser_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto3aObjects3Objects, runtimeScene, true, false);
}}
if (gdjs.ser_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto3aObjects3 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects3[i].setAnimationName("select");
}
}
{ //Subevents
gdjs.ser_95nivel3Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob3") >= 13;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "ob3");
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("vacio2");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob3") >= 5;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("pez");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob3") <= 0;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects3);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects3.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects3[i].setAnimationName("vacio");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objeto3b"), gdjs.ser_95nivel3Code.GDobjeto3bObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto3bObjects2Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ser_95nivel3Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto4aObjects2Objects = Hashtable.newFrom({"objeto4a": gdjs.ser_95nivel3Code.GDobjeto4aObjects2});
gdjs.ser_95nivel3Code.eventsList14 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("objeto1a"), gdjs.ser_95nivel3Code.GDobjeto1aObjects2);
gdjs.copyArray(runtimeScene.getObjects("objeto2a"), gdjs.ser_95nivel3Code.GDobjeto2aObjects2);
gdjs.copyArray(runtimeScene.getObjects("objeto3a"), gdjs.ser_95nivel3Code.GDobjeto3aObjects2);
/* Reuse gdjs.ser_95nivel3Code.GDobjeto4aObjects2 */
gdjs.copyArray(runtimeScene.getObjects("objeto4b"), gdjs.ser_95nivel3Code.GDobjeto4bObjects2);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects2[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4bObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4bObjects2[i].getBehavior("Tween").addObjectPositionTween("block", (( gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto4aObjects2[0].getPointX("")), (( gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length === 0 ) ? 0 :gdjs.ser_95nivel3Code.GDobjeto4aObjects2[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4bObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4bObjects2[i].setAnimationName("select");
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto1aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto1aObjects2[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto2aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto2aObjects2[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto3aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto3aObjects2[i].pauseAnimation();
}
for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects2[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\rana.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ob4");
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto4bObjects1Objects = Hashtable.newFrom({"objeto4b": gdjs.ser_95nivel3Code.GDobjeto4bObjects1});
gdjs.ser_95nivel3Code.eventsList15 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.ser_95nivel3Code.GDpersonajeObjects1);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDpersonajeObjects1[i].setAnimationName("parpadeo");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\dialogos\\otra opcion.mp3", false, 100, 1);
}}

}


};gdjs.ser_95nivel3Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objeto4a"), gdjs.ser_95nivel3Code.GDobjeto4aObjects2);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if ( gdjs.ser_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.ser_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto4aObjects2Objects, runtimeScene, true, false);
}}
if (gdjs.ser_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDobjeto4aObjects2 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDobjeto4aObjects2[i].setAnimationName("select");
}
}
{ //Subevents
gdjs.ser_95nivel3Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob4") >= 13;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects2);
{runtimeScene.getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "ob4");
}{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects2[i].setAnimationName("vacio2");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob4") >= 5;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects2[i].setAnimationName("rana");
}
}}

}


{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "ob4") <= 0;
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("texto"), gdjs.ser_95nivel3Code.GDtextoObjects2);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDtextoObjects2.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDtextoObjects2[i].setAnimationName("vacio");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objeto4b"), gdjs.ser_95nivel3Code.GDobjeto4bObjects1);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDobjeto4bObjects1Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ser_95nivel3Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.ser_95nivel3Code.eventsList17 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.eventsList7(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList10(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList13(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList16(runtimeScene);
}


};gdjs.ser_95nivel3Code.eventsList18 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.ser_95nivel3Code.GDParejasObjects1);
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDParejasObjects1.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDParejasObjects1[i].setString("Parejas: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}}

}


};gdjs.ser_95nivel3Code.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.ser_95nivel3Code.GDParejasObjects1);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ser_95nivel3Code.GDParejasObjects1.length;i<l;++i) {
    if ( gdjs.ser_95nivel3Code.GDParejasObjects1[i].getString() == "Parejas: 4" ) {
        gdjs.ser_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.ser_95nivel3Code.GDParejasObjects1[k] = gdjs.ser_95nivel3Code.GDParejasObjects1[i];
        ++k;
    }
}
gdjs.ser_95nivel3Code.GDParejasObjects1.length = k;}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_pronunciacion", false);
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.ser_95nivel3Code.GDregresarObjects1});
gdjs.ser_95nivel3Code.eventsList20 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_pronunciacion", false);
}}

}


};gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.ser_95nivel3Code.GDregresarObjects1});
gdjs.ser_95nivel3Code.eventsList21 = function(runtimeScene) {

{


gdjs.ser_95nivel3Code.eventsList0(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList4(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList17(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList18(runtimeScene);
}


{


gdjs.ser_95nivel3Code.eventsList19(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.ser_95nivel3Code.GDregresarObjects1);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDregresarObjects1Objects, runtimeScene, true, false);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDregresarObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.ser_95nivel3Code.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.ser_95nivel3Code.GDregresarObjects1);

gdjs.ser_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.ser_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ser_95nivel3Code.mapOfGDgdjs_46ser_9595nivel3Code_46GDregresarObjects1Objects, runtimeScene, true, true);
}if (gdjs.ser_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.ser_95nivel3Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.ser_95nivel3Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.ser_95nivel3Code.GDregresarObjects1[i].setAnimationName("normal");
}
}}

}


};

gdjs.ser_95nivel3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ser_95nivel3Code.GDpersonajeObjects1.length = 0;
gdjs.ser_95nivel3Code.GDpersonajeObjects2.length = 0;
gdjs.ser_95nivel3Code.GDpersonajeObjects3.length = 0;
gdjs.ser_95nivel3Code.GDpersonajeObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1aObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1aObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1aObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1aObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1bObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1bObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1bObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto1bObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2aObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2aObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2aObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2aObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2bObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2bObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2bObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto2bObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3aObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3aObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3aObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3aObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3bObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3bObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3bObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto3bObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4aObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4aObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4aObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4aObjects4.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4bObjects1.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4bObjects2.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4bObjects3.length = 0;
gdjs.ser_95nivel3Code.GDobjeto4bObjects4.length = 0;
gdjs.ser_95nivel3Code.GDop1Objects1.length = 0;
gdjs.ser_95nivel3Code.GDop1Objects2.length = 0;
gdjs.ser_95nivel3Code.GDop1Objects3.length = 0;
gdjs.ser_95nivel3Code.GDop1Objects4.length = 0;
gdjs.ser_95nivel3Code.GDop2Objects1.length = 0;
gdjs.ser_95nivel3Code.GDop2Objects2.length = 0;
gdjs.ser_95nivel3Code.GDop2Objects3.length = 0;
gdjs.ser_95nivel3Code.GDop2Objects4.length = 0;
gdjs.ser_95nivel3Code.GDop3Objects1.length = 0;
gdjs.ser_95nivel3Code.GDop3Objects2.length = 0;
gdjs.ser_95nivel3Code.GDop3Objects3.length = 0;
gdjs.ser_95nivel3Code.GDop3Objects4.length = 0;
gdjs.ser_95nivel3Code.GDop4Objects1.length = 0;
gdjs.ser_95nivel3Code.GDop4Objects2.length = 0;
gdjs.ser_95nivel3Code.GDop4Objects3.length = 0;
gdjs.ser_95nivel3Code.GDop4Objects4.length = 0;
gdjs.ser_95nivel3Code.GDvacioObjects1.length = 0;
gdjs.ser_95nivel3Code.GDvacioObjects2.length = 0;
gdjs.ser_95nivel3Code.GDvacioObjects3.length = 0;
gdjs.ser_95nivel3Code.GDvacioObjects4.length = 0;
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects1.length = 0;
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects2.length = 0;
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects3.length = 0;
gdjs.ser_95nivel3Code.GDfondo_95pantallaObjects4.length = 0;
gdjs.ser_95nivel3Code.GDNivelObjects1.length = 0;
gdjs.ser_95nivel3Code.GDNivelObjects2.length = 0;
gdjs.ser_95nivel3Code.GDNivelObjects3.length = 0;
gdjs.ser_95nivel3Code.GDNivelObjects4.length = 0;
gdjs.ser_95nivel3Code.GDParejasObjects1.length = 0;
gdjs.ser_95nivel3Code.GDParejasObjects2.length = 0;
gdjs.ser_95nivel3Code.GDParejasObjects3.length = 0;
gdjs.ser_95nivel3Code.GDParejasObjects4.length = 0;
gdjs.ser_95nivel3Code.GDposicionObjects1.length = 0;
gdjs.ser_95nivel3Code.GDposicionObjects2.length = 0;
gdjs.ser_95nivel3Code.GDposicionObjects3.length = 0;
gdjs.ser_95nivel3Code.GDposicionObjects4.length = 0;
gdjs.ser_95nivel3Code.GDtextoObjects1.length = 0;
gdjs.ser_95nivel3Code.GDtextoObjects2.length = 0;
gdjs.ser_95nivel3Code.GDtextoObjects3.length = 0;
gdjs.ser_95nivel3Code.GDtextoObjects4.length = 0;
gdjs.ser_95nivel3Code.GDparticulasObjects1.length = 0;
gdjs.ser_95nivel3Code.GDparticulasObjects2.length = 0;
gdjs.ser_95nivel3Code.GDparticulasObjects3.length = 0;
gdjs.ser_95nivel3Code.GDparticulasObjects4.length = 0;
gdjs.ser_95nivel3Code.GDnivelObjects1.length = 0;
gdjs.ser_95nivel3Code.GDnivelObjects2.length = 0;
gdjs.ser_95nivel3Code.GDnivelObjects3.length = 0;
gdjs.ser_95nivel3Code.GDnivelObjects4.length = 0;
gdjs.ser_95nivel3Code.GDregresarObjects1.length = 0;
gdjs.ser_95nivel3Code.GDregresarObjects2.length = 0;
gdjs.ser_95nivel3Code.GDregresarObjects3.length = 0;
gdjs.ser_95nivel3Code.GDregresarObjects4.length = 0;
gdjs.ser_95nivel3Code.GDmototextoObjects1.length = 0;
gdjs.ser_95nivel3Code.GDmototextoObjects2.length = 0;
gdjs.ser_95nivel3Code.GDmototextoObjects3.length = 0;
gdjs.ser_95nivel3Code.GDmototextoObjects4.length = 0;
gdjs.ser_95nivel3Code.GDcarrotextoObjects1.length = 0;
gdjs.ser_95nivel3Code.GDcarrotextoObjects2.length = 0;
gdjs.ser_95nivel3Code.GDcarrotextoObjects3.length = 0;
gdjs.ser_95nivel3Code.GDcarrotextoObjects4.length = 0;
gdjs.ser_95nivel3Code.GDambutextoObjects1.length = 0;
gdjs.ser_95nivel3Code.GDambutextoObjects2.length = 0;
gdjs.ser_95nivel3Code.GDambutextoObjects3.length = 0;
gdjs.ser_95nivel3Code.GDambutextoObjects4.length = 0;
gdjs.ser_95nivel3Code.GDtrentextoObjects1.length = 0;
gdjs.ser_95nivel3Code.GDtrentextoObjects2.length = 0;
gdjs.ser_95nivel3Code.GDtrentextoObjects3.length = 0;
gdjs.ser_95nivel3Code.GDtrentextoObjects4.length = 0;

gdjs.ser_95nivel3Code.eventsList21(runtimeScene);

return;

}

gdjs['ser_95nivel3Code'] = gdjs.ser_95nivel3Code;
