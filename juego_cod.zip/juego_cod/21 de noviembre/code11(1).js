gdjs.Juego_32de_32memoriaCode = {};
gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95r1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95r1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95r1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95r2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95r2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95r2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95K1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95K1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95K1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95K2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95K2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95K2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95l1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95l1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95l1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95l2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95l2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95l2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95S1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95S1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95S1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95S2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95S2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDCarta_95S2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDbloque1Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDbloque1Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDbloque1Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDbloque2Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDbloque2Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDbloque2Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDbloque3Objects1= [];
gdjs.Juego_32de_32memoriaCode.GDbloque3Objects2= [];
gdjs.Juego_32de_32memoriaCode.GDbloque3Objects3= [];
gdjs.Juego_32de_32memoriaCode.GDfondoObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDfondoObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDfondoObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDNivelObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDNivelObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDNivelObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDParejasObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDParejasObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDParejasObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDposicionObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDposicionObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDposicionObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDparticulasObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDparticulasObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDparticulasObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDnivelObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDnivelObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDnivelObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDTitulo_95cargaObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDTitulo_95cargaObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDTitulo_95cargaObjects3= [];
gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects1= [];
gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects2= [];
gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects3= [];

gdjs.Juego_32de_32memoriaCode.conditionTrue_0 = {val:false};
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0 = {val:false};
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0 = {val:false};
gdjs.Juego_32de_32memoriaCode.condition2IsTrue_0 = {val:false};
gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = {val:false};
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_1 = {val:false};
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_1 = {val:false};
gdjs.Juego_32de_32memoriaCode.condition2IsTrue_1 = {val:false};


gdjs.Juego_32de_32memoriaCode.eventsList0 = function(runtimeScene) {

{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects1);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects1[i].setAnimationName("correcto");
}
}}

}


};gdjs.Juego_32de_32memoriaCode.eventsList1 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


};gdjs.Juego_32de_32memoriaCode.eventsList2 = function(runtimeScene) {

{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\¡Busquemos-los-pares.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects2[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects2[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2[i].setAnimationName("back");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "espera");
}
{ //Subevents
gdjs.Juego_32de_32memoriaCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "espera") >= 1;
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0;
gdjs.Juego_32de_32memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20595612);
}
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2[i].setAnimationName("front");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}}

}


{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "espera") >= 1.7;
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0;
gdjs.Juego_32de_32memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20596324);
}
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2[i].setAnimationName("front");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}}

}


{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "espera") >= 4;
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0;
gdjs.Juego_32de_32memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20597964);
}
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2[i].setAnimationName("back");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}}

}


{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "espera") >= 4.7;
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0;
gdjs.Juego_32de_32memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20598964);
}
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2[i].setAnimationName("back");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}}

}


{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "espera") >= 7;
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0;
gdjs.Juego_32de_32memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20598764);
}
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2[i].setAnimationName("front");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}}

}


{


gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "espera") >= 7.7;
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Juego_32de_32memoriaCode.conditionTrue_1 = gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0;
gdjs.Juego_32de_32memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20601028);
}
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects1[i].setAnimationName("front");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}}

}


};gdjs.Juego_32de_32memoriaCode.mapOfGDgdjs_46Juego_9532de_9532memoriaCode_46GDboton_9595jugarObjects1Objects = Hashtable.newFrom({"boton_jugar": gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects1});
gdjs.Juego_32de_32memoriaCode.eventsList3 = function(runtimeScene) {

{


gdjs.Juego_32de_32memoriaCode.eventsList0(runtimeScene);
}


{


gdjs.Juego_32de_32memoriaCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("boton_jugar"), gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects1);

gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = false;
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Juego_32de_32memoriaCode.mapOfGDgdjs_46Juego_9532de_9532memoriaCode_46GDboton_9595jugarObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Juego_32de_32memoriaCode.condition0IsTrue_0.val ) {
{
gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Juego_32de_32memoriaCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "p_nivel1", false);
}}

}


};

gdjs.Juego_32de_32memoriaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDpersonajeObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95R1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95R2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95L1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95L2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95r1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95r1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95r1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95r2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95r2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95r2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95K1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95K1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95K1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95K2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95K2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95K2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95l1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95l1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95l1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95l2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95l2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95l2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95S1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95S1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95S1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95S2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95S2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDCarta_95S2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque1Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque1Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque1Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque2Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque2Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque2Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque3Objects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque3Objects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDbloque3Objects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDfondoObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDfondoObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDfondoObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDNivelObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDNivelObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDNivelObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDParejasObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDParejasObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDParejasObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDposicionObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDposicionObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDposicionObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDparticulasObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDparticulasObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDparticulasObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDnivelObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDnivelObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDnivelObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDTitulo_95cargaObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDTitulo_95cargaObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDTitulo_95cargaObjects3.length = 0;
gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects1.length = 0;
gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects2.length = 0;
gdjs.Juego_32de_32memoriaCode.GDboton_95jugarObjects3.length = 0;

gdjs.Juego_32de_32memoriaCode.eventsList3(runtimeScene);

return;

}

gdjs['Juego_32de_32memoriaCode'] = gdjs.Juego_32de_32memoriaCode;
