gdjs.menu_95pronunciacionCode = {};
gdjs.menu_95pronunciacionCode.GDfondoObjects1= [];
gdjs.menu_95pronunciacionCode.GDfondoObjects2= [];
gdjs.menu_95pronunciacionCode.GDtituloObjects1= [];
gdjs.menu_95pronunciacionCode.GDtituloObjects2= [];
gdjs.menu_95pronunciacionCode.GDnextObjects1= [];
gdjs.menu_95pronunciacionCode.GDnextObjects2= [];
gdjs.menu_95pronunciacionCode.GDbackObjects1= [];
gdjs.menu_95pronunciacionCode.GDbackObjects2= [];
gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1= [];
gdjs.menu_95pronunciacionCode.GDquiero_95serObjects2= [];
gdjs.menu_95pronunciacionCode.GDabejaObjects1= [];
gdjs.menu_95pronunciacionCode.GDabejaObjects2= [];
gdjs.menu_95pronunciacionCode.GDetiquetaObjects1= [];
gdjs.menu_95pronunciacionCode.GDetiquetaObjects2= [];
gdjs.menu_95pronunciacionCode.GDpersonajeObjects1= [];
gdjs.menu_95pronunciacionCode.GDpersonajeObjects2= [];
gdjs.menu_95pronunciacionCode.GDover_95izquierdaObjects1= [];
gdjs.menu_95pronunciacionCode.GDover_95izquierdaObjects2= [];
gdjs.menu_95pronunciacionCode.GDover_95derechaObjects1= [];
gdjs.menu_95pronunciacionCode.GDover_95derechaObjects2= [];
gdjs.menu_95pronunciacionCode.GDover_95fondoObjects1= [];
gdjs.menu_95pronunciacionCode.GDover_95fondoObjects2= [];

gdjs.menu_95pronunciacionCode.conditionTrue_0 = {val:false};
gdjs.menu_95pronunciacionCode.condition0IsTrue_0 = {val:false};
gdjs.menu_95pronunciacionCode.condition1IsTrue_0 = {val:false};
gdjs.menu_95pronunciacionCode.condition2IsTrue_0 = {val:false};


gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDover_9595izquierdaObjects1Objects = Hashtable.newFrom({"over_izquierda": gdjs.menu_95pronunciacionCode.GDover_95izquierdaObjects1});
gdjs.menu_95pronunciacionCode.eventsList0 = function(runtimeScene) {

{


gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "abejas_nivel3", false);
}}

}


};gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDover_9595derechaObjects1Objects = Hashtable.newFrom({"over_derecha": gdjs.menu_95pronunciacionCode.GDover_95derechaObjects1});
gdjs.menu_95pronunciacionCode.eventsList1 = function(runtimeScene) {

{


gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ser_nivel1", false);
}}

}


};gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDover_9595fondoObjects1Objects = Hashtable.newFrom({"over_fondo": gdjs.menu_95pronunciacionCode.GDover_95fondoObjects1});
gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDnextObjects1Objects = Hashtable.newFrom({"next": gdjs.menu_95pronunciacionCode.GDnextObjects1});
gdjs.menu_95pronunciacionCode.eventsList2 = function(runtimeScene) {

{


gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_semantica", false);
}}

}


};gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.menu_95pronunciacionCode.GDbackObjects1});
gdjs.menu_95pronunciacionCode.eventsList3 = function(runtimeScene) {

{


gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_semantica", false);
}}

}


};gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDtituloObjects1Objects = Hashtable.newFrom({"titulo": gdjs.menu_95pronunciacionCode.GDtituloObjects1});
gdjs.menu_95pronunciacionCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.menu_95pronunciacionCode.GDpersonajeObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.menu_95pronunciacionCode.GDpersonajeObjects1.length;i<l;++i) {
    if ( gdjs.menu_95pronunciacionCode.GDpersonajeObjects1[i].isCurrentAnimationName("normal") ) {
        gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = true;
        gdjs.menu_95pronunciacionCode.GDpersonajeObjects1[k] = gdjs.menu_95pronunciacionCode.GDpersonajeObjects1[i];
        ++k;
    }
}
gdjs.menu_95pronunciacionCode.GDpersonajeObjects1.length = k;}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("over_izquierda"), gdjs.menu_95pronunciacionCode.GDover_95izquierdaObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDover_9595izquierdaObjects1Objects, runtimeScene, true, false);
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("abeja"), gdjs.menu_95pronunciacionCode.GDabejaObjects1);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.menu_95pronunciacionCode.GDpersonajeObjects1);
{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDpersonajeObjects1[i].setAnimationName("derecha");
}
}{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDabejaObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDabejaObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.menu_95pronunciacionCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("over_derecha"), gdjs.menu_95pronunciacionCode.GDover_95derechaObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDover_9595derechaObjects1Objects, runtimeScene, true, false);
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.menu_95pronunciacionCode.GDpersonajeObjects1);
gdjs.copyArray(runtimeScene.getObjects("quiero_ser"), gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1);
{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDpersonajeObjects1[i].setAnimationName("izquierda");
}
}{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.menu_95pronunciacionCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("over_fondo"), gdjs.menu_95pronunciacionCode.GDover_95fondoObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDover_9595fondoObjects1Objects, runtimeScene, true, false);
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("abeja"), gdjs.menu_95pronunciacionCode.GDabejaObjects1);
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.menu_95pronunciacionCode.GDbackObjects1);
gdjs.copyArray(runtimeScene.getObjects("next"), gdjs.menu_95pronunciacionCode.GDnextObjects1);
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.menu_95pronunciacionCode.GDpersonajeObjects1);
gdjs.copyArray(runtimeScene.getObjects("quiero_ser"), gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1);
{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDpersonajeObjects1[i].setAnimationName("normal");
}
}{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1[i].setAnimationName("normal");
}
}{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDabejaObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDabejaObjects1[i].setAnimationName("normal");
}
}{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDnextObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDnextObjects1[i].setAnimationName("normal");
}
}{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDbackObjects1[i].setAnimationName("normal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("next"), gdjs.menu_95pronunciacionCode.GDnextObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDnextObjects1Objects, runtimeScene, true, false);
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
/* Reuse gdjs.menu_95pronunciacionCode.GDnextObjects1 */
{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDnextObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDnextObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.menu_95pronunciacionCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.menu_95pronunciacionCode.GDbackObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDbackObjects1Objects, runtimeScene, true, false);
}if (gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val) {
/* Reuse gdjs.menu_95pronunciacionCode.GDbackObjects1 */
{for(var i = 0, len = gdjs.menu_95pronunciacionCode.GDbackObjects1.length ;i < len;++i) {
    gdjs.menu_95pronunciacionCode.GDbackObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.menu_95pronunciacionCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("titulo"), gdjs.menu_95pronunciacionCode.GDtituloObjects1);

gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = false;
gdjs.menu_95pronunciacionCode.condition1IsTrue_0.val = false;
{
gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.menu_95pronunciacionCode.condition0IsTrue_0.val ) {
{
gdjs.menu_95pronunciacionCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.menu_95pronunciacionCode.mapOfGDgdjs_46menu_9595pronunciacionCode_46GDtituloObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.menu_95pronunciacionCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Pantalla de carga final", false);
}}

}


};

gdjs.menu_95pronunciacionCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.menu_95pronunciacionCode.GDfondoObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDfondoObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDtituloObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDtituloObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDnextObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDnextObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDbackObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDbackObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDquiero_95serObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDquiero_95serObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDabejaObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDabejaObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDetiquetaObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDetiquetaObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDpersonajeObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDpersonajeObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDover_95izquierdaObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDover_95izquierdaObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDover_95derechaObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDover_95derechaObjects2.length = 0;
gdjs.menu_95pronunciacionCode.GDover_95fondoObjects1.length = 0;
gdjs.menu_95pronunciacionCode.GDover_95fondoObjects2.length = 0;

gdjs.menu_95pronunciacionCode.eventsList4(runtimeScene);

return;

}

gdjs['menu_95pronunciacionCode'] = gdjs.menu_95pronunciacionCode;
