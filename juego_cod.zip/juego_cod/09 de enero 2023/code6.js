gdjs.abejas_95nivel3Code = {};
gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final = [];

gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final = [];

gdjs.abejas_95nivel3Code.forEachIndex2 = 0;

gdjs.abejas_95nivel3Code.forEachIndex3 = 0;

gdjs.abejas_95nivel3Code.forEachObjects2 = [];

gdjs.abejas_95nivel3Code.forEachObjects3 = [];

gdjs.abejas_95nivel3Code.forEachTemporary2 = null;

gdjs.abejas_95nivel3Code.forEachTemporary3 = null;

gdjs.abejas_95nivel3Code.forEachTotalCount2 = 0;

gdjs.abejas_95nivel3Code.forEachTotalCount3 = 0;

gdjs.abejas_95nivel3Code.GDpersonajeObjects1= [];
gdjs.abejas_95nivel3Code.GDpersonajeObjects2= [];
gdjs.abejas_95nivel3Code.GDpersonajeObjects3= [];
gdjs.abejas_95nivel3Code.GDpersonajeObjects4= [];
gdjs.abejas_95nivel3Code.GDpersonajeObjects5= [];
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects1= [];
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects2= [];
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects3= [];
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects4= [];
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects5= [];
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects1= [];
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects2= [];
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects3= [];
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects4= [];
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects5= [];
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects1= [];
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects2= [];
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects3= [];
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects4= [];
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects5= [];
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects1= [];
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects2= [];
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects3= [];
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects4= [];
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects5= [];
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects1= [];
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects2= [];
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects3= [];
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects4= [];
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects5= [];
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects1= [];
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects2= [];
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects3= [];
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects4= [];
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects5= [];
gdjs.abejas_95nivel3Code.GDpersonajeDObjects1= [];
gdjs.abejas_95nivel3Code.GDpersonajeDObjects2= [];
gdjs.abejas_95nivel3Code.GDpersonajeDObjects3= [];
gdjs.abejas_95nivel3Code.GDpersonajeDObjects4= [];
gdjs.abejas_95nivel3Code.GDpersonajeDObjects5= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects1= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects2= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects3= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects4= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects5= [];
gdjs.abejas_95nivel3Code.GDflor1Objects1= [];
gdjs.abejas_95nivel3Code.GDflor1Objects2= [];
gdjs.abejas_95nivel3Code.GDflor1Objects3= [];
gdjs.abejas_95nivel3Code.GDflor1Objects4= [];
gdjs.abejas_95nivel3Code.GDflor1Objects5= [];
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1= [];
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects2= [];
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects3= [];
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects4= [];
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects5= [];
gdjs.abejas_95nivel3Code.GDflor2Objects1= [];
gdjs.abejas_95nivel3Code.GDflor2Objects2= [];
gdjs.abejas_95nivel3Code.GDflor2Objects3= [];
gdjs.abejas_95nivel3Code.GDflor2Objects4= [];
gdjs.abejas_95nivel3Code.GDflor2Objects5= [];
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects1= [];
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects2= [];
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects3= [];
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects4= [];
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects5= [];
gdjs.abejas_95nivel3Code.GDflor3Objects1= [];
gdjs.abejas_95nivel3Code.GDflor3Objects2= [];
gdjs.abejas_95nivel3Code.GDflor3Objects3= [];
gdjs.abejas_95nivel3Code.GDflor3Objects4= [];
gdjs.abejas_95nivel3Code.GDflor3Objects5= [];
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1= [];
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects2= [];
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects3= [];
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects4= [];
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects5= [];
gdjs.abejas_95nivel3Code.GDflor4Objects1= [];
gdjs.abejas_95nivel3Code.GDflor4Objects2= [];
gdjs.abejas_95nivel3Code.GDflor4Objects3= [];
gdjs.abejas_95nivel3Code.GDflor4Objects4= [];
gdjs.abejas_95nivel3Code.GDflor4Objects5= [];
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects1= [];
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects2= [];
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects3= [];
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects4= [];
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects5= [];
gdjs.abejas_95nivel3Code.GDflor5Objects1= [];
gdjs.abejas_95nivel3Code.GDflor5Objects2= [];
gdjs.abejas_95nivel3Code.GDflor5Objects3= [];
gdjs.abejas_95nivel3Code.GDflor5Objects4= [];
gdjs.abejas_95nivel3Code.GDflor5Objects5= [];
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1= [];
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects2= [];
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects3= [];
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects4= [];
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects5= [];
gdjs.abejas_95nivel3Code.GDflor6Objects1= [];
gdjs.abejas_95nivel3Code.GDflor6Objects2= [];
gdjs.abejas_95nivel3Code.GDflor6Objects3= [];
gdjs.abejas_95nivel3Code.GDflor6Objects4= [];
gdjs.abejas_95nivel3Code.GDflor6Objects5= [];
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects1= [];
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects2= [];
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects3= [];
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects4= [];
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects5= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects5= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects5= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects5= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects5= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects1= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects2= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects3= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects4= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects5= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects1= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects2= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects3= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects4= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects5= [];
gdjs.abejas_95nivel3Code.GDfondoObjects1= [];
gdjs.abejas_95nivel3Code.GDfondoObjects2= [];
gdjs.abejas_95nivel3Code.GDfondoObjects3= [];
gdjs.abejas_95nivel3Code.GDfondoObjects4= [];
gdjs.abejas_95nivel3Code.GDfondoObjects5= [];
gdjs.abejas_95nivel3Code.GDNivelObjects1= [];
gdjs.abejas_95nivel3Code.GDNivelObjects2= [];
gdjs.abejas_95nivel3Code.GDNivelObjects3= [];
gdjs.abejas_95nivel3Code.GDNivelObjects4= [];
gdjs.abejas_95nivel3Code.GDNivelObjects5= [];
gdjs.abejas_95nivel3Code.GDContadorObjects1= [];
gdjs.abejas_95nivel3Code.GDContadorObjects2= [];
gdjs.abejas_95nivel3Code.GDContadorObjects3= [];
gdjs.abejas_95nivel3Code.GDContadorObjects4= [];
gdjs.abejas_95nivel3Code.GDContadorObjects5= [];
gdjs.abejas_95nivel3Code.GDposicionObjects1= [];
gdjs.abejas_95nivel3Code.GDposicionObjects2= [];
gdjs.abejas_95nivel3Code.GDposicionObjects3= [];
gdjs.abejas_95nivel3Code.GDposicionObjects4= [];
gdjs.abejas_95nivel3Code.GDposicionObjects5= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects1= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects2= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects3= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects4= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects5= [];
gdjs.abejas_95nivel3Code.GDnivelObjects1= [];
gdjs.abejas_95nivel3Code.GDnivelObjects2= [];
gdjs.abejas_95nivel3Code.GDnivelObjects3= [];
gdjs.abejas_95nivel3Code.GDnivelObjects4= [];
gdjs.abejas_95nivel3Code.GDnivelObjects5= [];
gdjs.abejas_95nivel3Code.GDregresarObjects1= [];
gdjs.abejas_95nivel3Code.GDregresarObjects2= [];
gdjs.abejas_95nivel3Code.GDregresarObjects3= [];
gdjs.abejas_95nivel3Code.GDregresarObjects4= [];
gdjs.abejas_95nivel3Code.GDregresarObjects5= [];
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects1= [];
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects2= [];
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects3= [];
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects4= [];
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects5= [];

gdjs.abejas_95nivel3Code.conditionTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition0IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition1IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition2IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.conditionTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition0IsTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition1IsTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition2IsTrue_1 = {val:false};


gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects4Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects4});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador1Objects4Objects = Hashtable.newFrom({"creador1": gdjs.abejas_95nivel3Code.GDcreador1Objects4});
gdjs.abejas_95nivel3Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects4);

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDcreador1Objects3, gdjs.abejas_95nivel3Code.GDcreador1Objects4);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects4Objects, "Physics2", gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador1Objects4Objects, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects4 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getAngle()), 700, 0, 0);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador2Objects3Objects = Hashtable.newFrom({"creador2": gdjs.abejas_95nivel3Code.GDcreador2Objects3});
gdjs.abejas_95nivel3Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDcreador2Objects2, gdjs.abejas_95nivel3Code.GDcreador2Objects3);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, "Physics2", gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador2Objects3Objects, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects3 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getAngle()), 700, 0, 0);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("creador1"), gdjs.abejas_95nivel3Code.GDcreador1Objects2);

for(gdjs.abejas_95nivel3Code.forEachIndex3 = 0;gdjs.abejas_95nivel3Code.forEachIndex3 < gdjs.abejas_95nivel3Code.GDcreador1Objects2.length;++gdjs.abejas_95nivel3Code.forEachIndex3) {
gdjs.abejas_95nivel3Code.GDabeja1Objects3.length = 0;

gdjs.abejas_95nivel3Code.GDcreador1Objects3.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary3 = gdjs.abejas_95nivel3Code.GDcreador1Objects2[gdjs.abejas_95nivel3Code.forEachIndex3];
gdjs.abejas_95nivel3Code.GDcreador1Objects3.push(gdjs.abejas_95nivel3Code.forEachTemporary3);
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setSize(233, 192);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getAngle()), 700, 0, 0);
}
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\muy bien.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\como hacen las abejas1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\otra abeja.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\una abeja mas.wav");
}
{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("creador2"), gdjs.abejas_95nivel3Code.GDcreador2Objects1);

for(gdjs.abejas_95nivel3Code.forEachIndex2 = 0;gdjs.abejas_95nivel3Code.forEachIndex2 < gdjs.abejas_95nivel3Code.GDcreador2Objects1.length;++gdjs.abejas_95nivel3Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("creador1"), gdjs.abejas_95nivel3Code.GDcreador1Objects2);
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;

gdjs.abejas_95nivel3Code.GDcreador2Objects2.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary2 = gdjs.abejas_95nivel3Code.GDcreador2Objects1[gdjs.abejas_95nivel3Code.forEachIndex2];
gdjs.abejas_95nivel3Code.GDcreador2Objects2.push(gdjs.abejas_95nivel3Code.forEachTemporary2);
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].setSize(233, 192);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].getAngle()), 500, 0, 0);
}
}
{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList1(runtimeScene);} //Subevents end.
}
}

}


};gdjs.abejas_95nivel3Code.eventsList3 = function(runtimeScene) {

{


{
}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.eventsList4 = function(runtimeScene) {

{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34134316);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);

{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setAnimationName("click");
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].activateBehavior("Arrastrable", true);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setAnimationName("click");
}
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34135916);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);

{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setAnimationName("vuelo");
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].activateBehavior("Physics2", true);
}
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor1Objects1Objects = Hashtable.newFrom({"flor1": gdjs.abejas_95nivel3Code.GDflor1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor1Objects1Objects = Hashtable.newFrom({"flor1": gdjs.abejas_95nivel3Code.GDflor1Objects1});
gdjs.abejas_95nivel3Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
/* Reuse gdjs.abejas_95nivel3Code.GDflor1Objects1 */

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor1Objects1Objects, false, runtimeScene, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Contador"), gdjs.abejas_95nivel3Code.GDContadorObjects1);
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.abejas_95nivel3Code.GDflor1Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor1Objects1[0].getPointX("")), (( gdjs.abejas_95nivel3Code.GDflor1Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor1Objects1[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDContadorObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDContadorObjects1[i].setString(gdjs.abejas_95nivel3Code.GDContadorObjects1[i].getString() + ("1"));
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor2Objects1Objects = Hashtable.newFrom({"flor2": gdjs.abejas_95nivel3Code.GDflor2Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor2Objects1Objects = Hashtable.newFrom({"flor2": gdjs.abejas_95nivel3Code.GDflor2Objects1});
gdjs.abejas_95nivel3Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
/* Reuse gdjs.abejas_95nivel3Code.GDflor2Objects1 */

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("flor_rosa"), gdjs.abejas_95nivel3Code.GDflor_95rosaObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95rosaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95rosaObjects1[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.abejas_95nivel3Code.GDflor2Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor2Objects1[0].getPointX("")), (( gdjs.abejas_95nivel3Code.GDflor2Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor2Objects1[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor2Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor2Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor3Objects1Objects = Hashtable.newFrom({"flor3": gdjs.abejas_95nivel3Code.GDflor3Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor3Objects1Objects = Hashtable.newFrom({"flor3": gdjs.abejas_95nivel3Code.GDflor3Objects1});
gdjs.abejas_95nivel3Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
/* Reuse gdjs.abejas_95nivel3Code.GDflor3Objects1 */

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor3Objects1Objects, false, runtimeScene, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor3Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.abejas_95nivel3Code.GDflor3Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor3Objects1[0].getPointX("")), (( gdjs.abejas_95nivel3Code.GDflor3Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor3Objects1[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor3Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor3Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor4Objects1Objects = Hashtable.newFrom({"flor4": gdjs.abejas_95nivel3Code.GDflor4Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor4Objects1Objects = Hashtable.newFrom({"flor4": gdjs.abejas_95nivel3Code.GDflor4Objects1});
gdjs.abejas_95nivel3Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
/* Reuse gdjs.abejas_95nivel3Code.GDflor4Objects1 */

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor4Objects1Objects, false, runtimeScene, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor4Objects1 */
gdjs.copyArray(runtimeScene.getObjects("flor_rosada"), gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects1[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.abejas_95nivel3Code.GDflor4Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor4Objects1[0].getPointX("")), (( gdjs.abejas_95nivel3Code.GDflor4Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor4Objects1[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor4Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor4Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor5Objects1Objects = Hashtable.newFrom({"flor5": gdjs.abejas_95nivel3Code.GDflor5Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor5Objects1Objects = Hashtable.newFrom({"flor5": gdjs.abejas_95nivel3Code.GDflor5Objects1});
gdjs.abejas_95nivel3Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
/* Reuse gdjs.abejas_95nivel3Code.GDflor5Objects1 */

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor5Objects1Objects, false, runtimeScene, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor5Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.abejas_95nivel3Code.GDflor5Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor5Objects1[0].getPointX("")), (( gdjs.abejas_95nivel3Code.GDflor5Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor5Objects1[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor5Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor5Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor6Objects1Objects = Hashtable.newFrom({"flor6": gdjs.abejas_95nivel3Code.GDflor6Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor6Objects1Objects = Hashtable.newFrom({"flor6": gdjs.abejas_95nivel3Code.GDflor6Objects1});
gdjs.abejas_95nivel3Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
/* Reuse gdjs.abejas_95nivel3Code.GDflor6Objects1 */

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor6Objects1Objects, false, runtimeScene, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor6Objects1 */
gdjs.copyArray(runtimeScene.getObjects("flor_verde"), gdjs.abejas_95nivel3Code.GDflor_95verdeObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95verdeObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95verdeObjects1[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.abejas_95nivel3Code.GDflor6Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor6Objects1[0].getPointX("")), (( gdjs.abejas_95nivel3Code.GDflor6Objects1.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDflor6Objects1[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor6Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor6Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].getAngle()), 700, 0, 0);
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Contador"), gdjs.abejas_95nivel3Code.GDContadorObjects2);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDContadorObjects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDContadorObjects2[i].setString("Abejas atrapadas: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 1;
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34150356);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\muy bien.wav", false, 100, 1);
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 2;
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34151380);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\como hacen las abejas1.wav", false, 100, 1);
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 3;
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34152076);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\otra abeja.wav", false, 100, 1);
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 4;
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34152900);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\como hacen las abejas1.wav", false, 100, 1);
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 5;
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34153796);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\una abeja mas.wav", false, 100, 1);
}}

}


{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 6;
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(34154612);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Outro_abejas", false);
}}

}


};gdjs.abejas_95nivel3Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Contador"), gdjs.abejas_95nivel3Code.GDContadorObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDContadorObjects1.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDContadorObjects1[i].getString() == "Parejas: 6" ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.abejas_95nivel3Code.GDContadorObjects1[k] = gdjs.abejas_95nivel3Code.GDContadorObjects1[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDContadorObjects1.length = k;}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "p_final", false);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.abejas_95nivel3Code.GDregresarObjects1});
gdjs.abejas_95nivel3Code.eventsList13 = function(runtimeScene) {

{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_pronunciacion", false);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.abejas_95nivel3Code.GDregresarObjects1});
gdjs.abejas_95nivel3Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects4);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition0IsTrue_0;
gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.length = 0;gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects5);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects5[i].getCenterXInScene() < -(1920) ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects5[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects5[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects5.length = k;if( gdjs.abejas_95nivel3Code.condition0IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects5);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects5[i].getCenterXInScene() > 1920 ) {
        gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects5[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects5[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects5.length = k;if( gdjs.abejas_95nivel3Code.condition1IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final, gdjs.abejas_95nivel3Code.GDabeja1Objects4);
}
}
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects4 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].setX(((gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getPointX("")) * -(0.55)));
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition0IsTrue_0;
gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.length = 0;gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects4);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getCenterYInScene() < -(1080) ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects4[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects4[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects4.length = k;if( gdjs.abejas_95nivel3Code.condition0IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects4);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getCenterYInScene() > 1080 ) {
        gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects4[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects4[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects4.length = k;if( gdjs.abejas_95nivel3Code.condition1IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final, gdjs.abejas_95nivel3Code.GDabeja1Objects3);
}
}
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects3 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setY(((gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getPointY("")) * -(0.50)));
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList16 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects2);

for(gdjs.abejas_95nivel3Code.forEachIndex3 = 0;gdjs.abejas_95nivel3Code.forEachIndex3 < gdjs.abejas_95nivel3Code.GDabeja1Objects2.length;++gdjs.abejas_95nivel3Code.forEachIndex3) {
gdjs.abejas_95nivel3Code.GDabeja1Objects3.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary3 = gdjs.abejas_95nivel3Code.GDabeja1Objects2[gdjs.abejas_95nivel3Code.forEachIndex3];
gdjs.abejas_95nivel3Code.GDabeja1Objects3.push(gdjs.abejas_95nivel3Code.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList14(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);

for(gdjs.abejas_95nivel3Code.forEachIndex2 = 0;gdjs.abejas_95nivel3Code.forEachIndex2 < gdjs.abejas_95nivel3Code.GDabeja1Objects1.length;++gdjs.abejas_95nivel3Code.forEachIndex2) {
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary2 = gdjs.abejas_95nivel3Code.GDabeja1Objects1[gdjs.abejas_95nivel3Code.forEachIndex2];
gdjs.abejas_95nivel3Code.GDabeja1Objects2.push(gdjs.abejas_95nivel3Code.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList15(runtimeScene);} //Subevents end.
}
}

}


};gdjs.abejas_95nivel3Code.eventsList17 = function(runtimeScene) {

{


gdjs.abejas_95nivel3Code.eventsList2(runtimeScene);
}


{


gdjs.abejas_95nivel3Code.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);

for(gdjs.abejas_95nivel3Code.forEachIndex2 = 0;gdjs.abejas_95nivel3Code.forEachIndex2 < gdjs.abejas_95nivel3Code.GDabeja1Objects1.length;++gdjs.abejas_95nivel3Code.forEachIndex2) {
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary2 = gdjs.abejas_95nivel3Code.GDabeja1Objects1[gdjs.abejas_95nivel3Code.forEachIndex2];
gdjs.abejas_95nivel3Code.GDabeja1Objects2.push(gdjs.abejas_95nivel3Code.forEachTemporary2);
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList4(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("flor1"), gdjs.abejas_95nivel3Code.GDflor1Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor1Objects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_morada"), gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1[i].flipX(true);
}
}
{ //Subevents
gdjs.abejas_95nivel3Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("flor2"), gdjs.abejas_95nivel3Code.GDflor2Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor2Objects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.abejas_95nivel3Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("flor3"), gdjs.abejas_95nivel3Code.GDflor3Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor3Objects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_naranja"), gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1[i].flipX(true);
}
}
{ //Subevents
gdjs.abejas_95nivel3Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("flor4"), gdjs.abejas_95nivel3Code.GDflor4Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor4Objects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.abejas_95nivel3Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("flor5"), gdjs.abejas_95nivel3Code.GDflor5Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor5Objects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_amarilla"), gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1[i].flipX(true);
}
}
{ //Subevents
gdjs.abejas_95nivel3Code.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("flor6"), gdjs.abejas_95nivel3Code.GDflor6Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor6Objects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.abejas_95nivel3Code.eventsList10(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


gdjs.abejas_95nivel3Code.eventsList11(runtimeScene);
}


{


gdjs.abejas_95nivel3Code.eventsList12(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.abejas_95nivel3Code.GDregresarObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDregresarObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.abejas_95nivel3Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.abejas_95nivel3Code.GDregresarObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects, runtimeScene, true, true);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDregresarObjects1[i].setAnimationName("normal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Contador"), gdjs.abejas_95nivel3Code.GDContadorObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDContadorObjects1.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDContadorObjects1[i].getString() == "Abejas atrapadas:6" ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.abejas_95nivel3Code.GDContadorObjects1[k] = gdjs.abejas_95nivel3Code.GDContadorObjects1[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDContadorObjects1.length = k;}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
}

}


{


gdjs.abejas_95nivel3Code.eventsList16(runtimeScene);
}


{


{
}

}


{


{
}

}


};

gdjs.abejas_95nivel3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.abejas_95nivel3Code.GDpersonajeObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95K1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95R2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDCarta_95S2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeDObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeDObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeDObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeDObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDpersonajeDObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95moradaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95naranjaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95rosadaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95amarillaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor_95verdeObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDContadorObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDContadorObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDContadorObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDContadorObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDContadorObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDNewParticlesEmitterObjects5.length = 0;

gdjs.abejas_95nivel3Code.eventsList17(runtimeScene);

return;

}

gdjs['abejas_95nivel3Code'] = gdjs.abejas_95nivel3Code;
