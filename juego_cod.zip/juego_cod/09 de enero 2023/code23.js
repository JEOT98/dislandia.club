gdjs.nivel_321Code = {};
gdjs.nivel_321Code.forEachCount0_5 = 0;

gdjs.nivel_321Code.forEachCount10_5 = 0;

gdjs.nivel_321Code.forEachCount11_5 = 0;

gdjs.nivel_321Code.forEachCount1_5 = 0;

gdjs.nivel_321Code.forEachCount2_5 = 0;

gdjs.nivel_321Code.forEachCount3_5 = 0;

gdjs.nivel_321Code.forEachCount4_5 = 0;

gdjs.nivel_321Code.forEachCount5_5 = 0;

gdjs.nivel_321Code.forEachCount6_5 = 0;

gdjs.nivel_321Code.forEachCount7_5 = 0;

gdjs.nivel_321Code.forEachCount8_5 = 0;

gdjs.nivel_321Code.forEachCount9_5 = 0;

gdjs.nivel_321Code.forEachIndex2 = 0;

gdjs.nivel_321Code.forEachIndex5 = 0;

gdjs.nivel_321Code.forEachObjects2 = [];

gdjs.nivel_321Code.forEachObjects5 = [];

gdjs.nivel_321Code.forEachTemporary2 = null;

gdjs.nivel_321Code.forEachTotalCount2 = 0;

gdjs.nivel_321Code.forEachTotalCount5 = 0;

gdjs.nivel_321Code.GDpersonajeObjects1= [];
gdjs.nivel_321Code.GDpersonajeObjects2= [];
gdjs.nivel_321Code.GDpersonajeObjects3= [];
gdjs.nivel_321Code.GDpersonajeObjects4= [];
gdjs.nivel_321Code.GDpersonajeObjects5= [];
gdjs.nivel_321Code.GDpersonajeObjects6= [];
gdjs.nivel_321Code.GDpersonajeObjects7= [];
gdjs.nivel_321Code.GDCarta_95R1Objects1= [];
gdjs.nivel_321Code.GDCarta_95R1Objects2= [];
gdjs.nivel_321Code.GDCarta_95R1Objects3= [];
gdjs.nivel_321Code.GDCarta_95R1Objects4= [];
gdjs.nivel_321Code.GDCarta_95R1Objects5= [];
gdjs.nivel_321Code.GDCarta_95R1Objects6= [];
gdjs.nivel_321Code.GDCarta_95R1Objects7= [];
gdjs.nivel_321Code.GDCarta_95K2Objects1= [];
gdjs.nivel_321Code.GDCarta_95K2Objects2= [];
gdjs.nivel_321Code.GDCarta_95K2Objects3= [];
gdjs.nivel_321Code.GDCarta_95K2Objects4= [];
gdjs.nivel_321Code.GDCarta_95K2Objects5= [];
gdjs.nivel_321Code.GDCarta_95K2Objects6= [];
gdjs.nivel_321Code.GDCarta_95K2Objects7= [];
gdjs.nivel_321Code.GDCarta_95K1Objects1= [];
gdjs.nivel_321Code.GDCarta_95K1Objects2= [];
gdjs.nivel_321Code.GDCarta_95K1Objects3= [];
gdjs.nivel_321Code.GDCarta_95K1Objects4= [];
gdjs.nivel_321Code.GDCarta_95K1Objects5= [];
gdjs.nivel_321Code.GDCarta_95K1Objects6= [];
gdjs.nivel_321Code.GDCarta_95K1Objects7= [];
gdjs.nivel_321Code.GDCarta_95R2Objects1= [];
gdjs.nivel_321Code.GDCarta_95R2Objects2= [];
gdjs.nivel_321Code.GDCarta_95R2Objects3= [];
gdjs.nivel_321Code.GDCarta_95R2Objects4= [];
gdjs.nivel_321Code.GDCarta_95R2Objects5= [];
gdjs.nivel_321Code.GDCarta_95R2Objects6= [];
gdjs.nivel_321Code.GDCarta_95R2Objects7= [];
gdjs.nivel_321Code.GDCarta_95S1Objects1= [];
gdjs.nivel_321Code.GDCarta_95S1Objects2= [];
gdjs.nivel_321Code.GDCarta_95S1Objects3= [];
gdjs.nivel_321Code.GDCarta_95S1Objects4= [];
gdjs.nivel_321Code.GDCarta_95S1Objects5= [];
gdjs.nivel_321Code.GDCarta_95S1Objects6= [];
gdjs.nivel_321Code.GDCarta_95S1Objects7= [];
gdjs.nivel_321Code.GDCarta_95S2Objects1= [];
gdjs.nivel_321Code.GDCarta_95S2Objects2= [];
gdjs.nivel_321Code.GDCarta_95S2Objects3= [];
gdjs.nivel_321Code.GDCarta_95S2Objects4= [];
gdjs.nivel_321Code.GDCarta_95S2Objects5= [];
gdjs.nivel_321Code.GDCarta_95S2Objects6= [];
gdjs.nivel_321Code.GDCarta_95S2Objects7= [];
gdjs.nivel_321Code.GDpersonajeDObjects1= [];
gdjs.nivel_321Code.GDpersonajeDObjects2= [];
gdjs.nivel_321Code.GDpersonajeDObjects3= [];
gdjs.nivel_321Code.GDpersonajeDObjects4= [];
gdjs.nivel_321Code.GDpersonajeDObjects5= [];
gdjs.nivel_321Code.GDpersonajeDObjects6= [];
gdjs.nivel_321Code.GDpersonajeDObjects7= [];
gdjs.nivel_321Code.GDpersonaje1Objects1= [];
gdjs.nivel_321Code.GDpersonaje1Objects2= [];
gdjs.nivel_321Code.GDpersonaje1Objects3= [];
gdjs.nivel_321Code.GDpersonaje1Objects4= [];
gdjs.nivel_321Code.GDpersonaje1Objects5= [];
gdjs.nivel_321Code.GDpersonaje1Objects6= [];
gdjs.nivel_321Code.GDpersonaje1Objects7= [];
gdjs.nivel_321Code.GDpersonajeObjects1= [];
gdjs.nivel_321Code.GDpersonajeObjects2= [];
gdjs.nivel_321Code.GDpersonajeObjects3= [];
gdjs.nivel_321Code.GDpersonajeObjects4= [];
gdjs.nivel_321Code.GDpersonajeObjects5= [];
gdjs.nivel_321Code.GDpersonajeObjects6= [];
gdjs.nivel_321Code.GDpersonajeObjects7= [];
gdjs.nivel_321Code.GDCarta_95R2Objects1= [];
gdjs.nivel_321Code.GDCarta_95R2Objects2= [];
gdjs.nivel_321Code.GDCarta_95R2Objects3= [];
gdjs.nivel_321Code.GDCarta_95R2Objects4= [];
gdjs.nivel_321Code.GDCarta_95R2Objects5= [];
gdjs.nivel_321Code.GDCarta_95R2Objects6= [];
gdjs.nivel_321Code.GDCarta_95R2Objects7= [];
gdjs.nivel_321Code.GDCarta_95L1Objects1= [];
gdjs.nivel_321Code.GDCarta_95L1Objects2= [];
gdjs.nivel_321Code.GDCarta_95L1Objects3= [];
gdjs.nivel_321Code.GDCarta_95L1Objects4= [];
gdjs.nivel_321Code.GDCarta_95L1Objects5= [];
gdjs.nivel_321Code.GDCarta_95L1Objects6= [];
gdjs.nivel_321Code.GDCarta_95L1Objects7= [];
gdjs.nivel_321Code.GDCarta_95L2Objects1= [];
gdjs.nivel_321Code.GDCarta_95L2Objects2= [];
gdjs.nivel_321Code.GDCarta_95L2Objects3= [];
gdjs.nivel_321Code.GDCarta_95L2Objects4= [];
gdjs.nivel_321Code.GDCarta_95L2Objects5= [];
gdjs.nivel_321Code.GDCarta_95L2Objects6= [];
gdjs.nivel_321Code.GDCarta_95L2Objects7= [];
gdjs.nivel_321Code.GDCarta_95r1Objects1= [];
gdjs.nivel_321Code.GDCarta_95r1Objects2= [];
gdjs.nivel_321Code.GDCarta_95r1Objects3= [];
gdjs.nivel_321Code.GDCarta_95r1Objects4= [];
gdjs.nivel_321Code.GDCarta_95r1Objects5= [];
gdjs.nivel_321Code.GDCarta_95r1Objects6= [];
gdjs.nivel_321Code.GDCarta_95r1Objects7= [];
gdjs.nivel_321Code.GDCarta_95r2Objects1= [];
gdjs.nivel_321Code.GDCarta_95r2Objects2= [];
gdjs.nivel_321Code.GDCarta_95r2Objects3= [];
gdjs.nivel_321Code.GDCarta_95r2Objects4= [];
gdjs.nivel_321Code.GDCarta_95r2Objects5= [];
gdjs.nivel_321Code.GDCarta_95r2Objects6= [];
gdjs.nivel_321Code.GDCarta_95r2Objects7= [];
gdjs.nivel_321Code.GDCarta_95K1Objects1= [];
gdjs.nivel_321Code.GDCarta_95K1Objects2= [];
gdjs.nivel_321Code.GDCarta_95K1Objects3= [];
gdjs.nivel_321Code.GDCarta_95K1Objects4= [];
gdjs.nivel_321Code.GDCarta_95K1Objects5= [];
gdjs.nivel_321Code.GDCarta_95K1Objects6= [];
gdjs.nivel_321Code.GDCarta_95K1Objects7= [];
gdjs.nivel_321Code.GDCarta_95K2Objects1= [];
gdjs.nivel_321Code.GDCarta_95K2Objects2= [];
gdjs.nivel_321Code.GDCarta_95K2Objects3= [];
gdjs.nivel_321Code.GDCarta_95K2Objects4= [];
gdjs.nivel_321Code.GDCarta_95K2Objects5= [];
gdjs.nivel_321Code.GDCarta_95K2Objects6= [];
gdjs.nivel_321Code.GDCarta_95K2Objects7= [];
gdjs.nivel_321Code.GDCarta_95l1Objects1= [];
gdjs.nivel_321Code.GDCarta_95l1Objects2= [];
gdjs.nivel_321Code.GDCarta_95l1Objects3= [];
gdjs.nivel_321Code.GDCarta_95l1Objects4= [];
gdjs.nivel_321Code.GDCarta_95l1Objects5= [];
gdjs.nivel_321Code.GDCarta_95l1Objects6= [];
gdjs.nivel_321Code.GDCarta_95l1Objects7= [];
gdjs.nivel_321Code.GDCarta_95l2Objects1= [];
gdjs.nivel_321Code.GDCarta_95l2Objects2= [];
gdjs.nivel_321Code.GDCarta_95l2Objects3= [];
gdjs.nivel_321Code.GDCarta_95l2Objects4= [];
gdjs.nivel_321Code.GDCarta_95l2Objects5= [];
gdjs.nivel_321Code.GDCarta_95l2Objects6= [];
gdjs.nivel_321Code.GDCarta_95l2Objects7= [];
gdjs.nivel_321Code.GDCarta_95S1Objects1= [];
gdjs.nivel_321Code.GDCarta_95S1Objects2= [];
gdjs.nivel_321Code.GDCarta_95S1Objects3= [];
gdjs.nivel_321Code.GDCarta_95S1Objects4= [];
gdjs.nivel_321Code.GDCarta_95S1Objects5= [];
gdjs.nivel_321Code.GDCarta_95S1Objects6= [];
gdjs.nivel_321Code.GDCarta_95S1Objects7= [];
gdjs.nivel_321Code.GDCarta_95S2Objects1= [];
gdjs.nivel_321Code.GDCarta_95S2Objects2= [];
gdjs.nivel_321Code.GDCarta_95S2Objects3= [];
gdjs.nivel_321Code.GDCarta_95S2Objects4= [];
gdjs.nivel_321Code.GDCarta_95S2Objects5= [];
gdjs.nivel_321Code.GDCarta_95S2Objects6= [];
gdjs.nivel_321Code.GDCarta_95S2Objects7= [];
gdjs.nivel_321Code.GDbloque1Objects1= [];
gdjs.nivel_321Code.GDbloque1Objects2= [];
gdjs.nivel_321Code.GDbloque1Objects3= [];
gdjs.nivel_321Code.GDbloque1Objects4= [];
gdjs.nivel_321Code.GDbloque1Objects5= [];
gdjs.nivel_321Code.GDbloque1Objects6= [];
gdjs.nivel_321Code.GDbloque1Objects7= [];
gdjs.nivel_321Code.GDbloque2Objects1= [];
gdjs.nivel_321Code.GDbloque2Objects2= [];
gdjs.nivel_321Code.GDbloque2Objects3= [];
gdjs.nivel_321Code.GDbloque2Objects4= [];
gdjs.nivel_321Code.GDbloque2Objects5= [];
gdjs.nivel_321Code.GDbloque2Objects6= [];
gdjs.nivel_321Code.GDbloque2Objects7= [];
gdjs.nivel_321Code.GDbloque3Objects1= [];
gdjs.nivel_321Code.GDbloque3Objects2= [];
gdjs.nivel_321Code.GDbloque3Objects3= [];
gdjs.nivel_321Code.GDbloque3Objects4= [];
gdjs.nivel_321Code.GDbloque3Objects5= [];
gdjs.nivel_321Code.GDbloque3Objects6= [];
gdjs.nivel_321Code.GDbloque3Objects7= [];
gdjs.nivel_321Code.GDfondoObjects1= [];
gdjs.nivel_321Code.GDfondoObjects2= [];
gdjs.nivel_321Code.GDfondoObjects3= [];
gdjs.nivel_321Code.GDfondoObjects4= [];
gdjs.nivel_321Code.GDfondoObjects5= [];
gdjs.nivel_321Code.GDfondoObjects6= [];
gdjs.nivel_321Code.GDfondoObjects7= [];
gdjs.nivel_321Code.GDNivelObjects1= [];
gdjs.nivel_321Code.GDNivelObjects2= [];
gdjs.nivel_321Code.GDNivelObjects3= [];
gdjs.nivel_321Code.GDNivelObjects4= [];
gdjs.nivel_321Code.GDNivelObjects5= [];
gdjs.nivel_321Code.GDNivelObjects6= [];
gdjs.nivel_321Code.GDNivelObjects7= [];
gdjs.nivel_321Code.GDParejasObjects1= [];
gdjs.nivel_321Code.GDParejasObjects2= [];
gdjs.nivel_321Code.GDParejasObjects3= [];
gdjs.nivel_321Code.GDParejasObjects4= [];
gdjs.nivel_321Code.GDParejasObjects5= [];
gdjs.nivel_321Code.GDParejasObjects6= [];
gdjs.nivel_321Code.GDParejasObjects7= [];
gdjs.nivel_321Code.GDposicionObjects1= [];
gdjs.nivel_321Code.GDposicionObjects2= [];
gdjs.nivel_321Code.GDposicionObjects3= [];
gdjs.nivel_321Code.GDposicionObjects4= [];
gdjs.nivel_321Code.GDposicionObjects5= [];
gdjs.nivel_321Code.GDposicionObjects6= [];
gdjs.nivel_321Code.GDposicionObjects7= [];
gdjs.nivel_321Code.GDparticulasObjects1= [];
gdjs.nivel_321Code.GDparticulasObjects2= [];
gdjs.nivel_321Code.GDparticulasObjects3= [];
gdjs.nivel_321Code.GDparticulasObjects4= [];
gdjs.nivel_321Code.GDparticulasObjects5= [];
gdjs.nivel_321Code.GDparticulasObjects6= [];
gdjs.nivel_321Code.GDparticulasObjects7= [];
gdjs.nivel_321Code.GDnivelObjects1= [];
gdjs.nivel_321Code.GDnivelObjects2= [];
gdjs.nivel_321Code.GDnivelObjects3= [];
gdjs.nivel_321Code.GDnivelObjects4= [];
gdjs.nivel_321Code.GDnivelObjects5= [];
gdjs.nivel_321Code.GDnivelObjects6= [];
gdjs.nivel_321Code.GDnivelObjects7= [];
gdjs.nivel_321Code.GDregresarObjects1= [];
gdjs.nivel_321Code.GDregresarObjects2= [];
gdjs.nivel_321Code.GDregresarObjects3= [];
gdjs.nivel_321Code.GDregresarObjects4= [];
gdjs.nivel_321Code.GDregresarObjects5= [];
gdjs.nivel_321Code.GDregresarObjects6= [];
gdjs.nivel_321Code.GDregresarObjects7= [];

gdjs.nivel_321Code.conditionTrue_0 = {val:false};
gdjs.nivel_321Code.condition0IsTrue_0 = {val:false};
gdjs.nivel_321Code.condition1IsTrue_0 = {val:false};
gdjs.nivel_321Code.condition2IsTrue_0 = {val:false};
gdjs.nivel_321Code.condition3IsTrue_0 = {val:false};
gdjs.nivel_321Code.conditionTrue_1 = {val:false};
gdjs.nivel_321Code.condition0IsTrue_1 = {val:false};
gdjs.nivel_321Code.condition1IsTrue_1 = {val:false};
gdjs.nivel_321Code.condition2IsTrue_1 = {val:false};
gdjs.nivel_321Code.condition3IsTrue_1 = {val:false};


gdjs.nivel_321Code.eventsList0 = function(runtimeScene) {

{


{
}

}


};gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDbloque1Objects2Objects = Hashtable.newFrom({"bloque1": gdjs.nivel_321Code.GDbloque1Objects2});
gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDbloque2Objects2Objects = Hashtable.newFrom({"bloque2": gdjs.nivel_321Code.GDbloque2Objects2});
gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDbloque3Objects2Objects = Hashtable.newFrom({"bloque3": gdjs.nivel_321Code.GDbloque3Objects2});
gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDfondoObjects1Objects = Hashtable.newFrom({"fondo": gdjs.nivel_321Code.GDfondoObjects1});
gdjs.nivel_321Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.nivel_321Code.GDpersonajeObjects2);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDpersonajeObjects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDpersonajeObjects2[i].isCurrentAnimationName("parpadeo") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDpersonajeObjects2[k] = gdjs.nivel_321Code.GDpersonajeObjects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDpersonajeObjects2.length = k;}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bloque1"), gdjs.nivel_321Code.GDbloque1Objects2);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDbloque1Objects2Objects, runtimeScene, true, false);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.nivel_321Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.nivel_321Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDpersonajeObjects2[i].setAnimationName("fila1");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bloque2"), gdjs.nivel_321Code.GDbloque2Objects2);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDbloque2Objects2Objects, runtimeScene, true, false);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.nivel_321Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.nivel_321Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDpersonajeObjects2[i].setAnimationName("fila2");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bloque3"), gdjs.nivel_321Code.GDbloque3Objects2);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDbloque3Objects2Objects, runtimeScene, true, false);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.nivel_321Code.GDpersonajeObjects2);
{for(var i = 0, len = gdjs.nivel_321Code.GDpersonajeObjects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDpersonajeObjects2[i].setAnimationName("fila3");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fondo"), gdjs.nivel_321Code.GDfondoObjects1);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDfondoObjects1Objects, runtimeScene, true, false);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personaje"), gdjs.nivel_321Code.GDpersonajeObjects1);
gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.nivel_321Code.GDregresarObjects1);
{for(var i = 0, len = gdjs.nivel_321Code.GDpersonajeObjects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDpersonajeObjects1[i].setAnimationName("parpadeo");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDregresarObjects1[i].setAnimationName("normal");
}
}}

}


};gdjs.nivel_321Code.eventsList2 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


};gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDCarta_9595R1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595R2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S2Objects3Objects = Hashtable.newFrom({"Carta_R1": gdjs.nivel_321Code.GDCarta_95R1Objects3, "Carta_R2": gdjs.nivel_321Code.GDCarta_95R2Objects3, "Carta_L1": gdjs.nivel_321Code.GDCarta_95L1Objects3, "Carta_L2": gdjs.nivel_321Code.GDCarta_95L2Objects3, "Carta_r1": gdjs.nivel_321Code.GDCarta_95r1Objects3, "Carta_r2": gdjs.nivel_321Code.GDCarta_95r2Objects3, "Carta_K1": gdjs.nivel_321Code.GDCarta_95K1Objects3, "Carta_K2": gdjs.nivel_321Code.GDCarta_95K2Objects3, "Carta_l1": gdjs.nivel_321Code.GDCarta_95l1Objects3, "Carta_l2": gdjs.nivel_321Code.GDCarta_95l2Objects3, "Carta_S1": gdjs.nivel_321Code.GDCarta_95S1Objects3, "Carta_S2": gdjs.nivel_321Code.GDCarta_95S2Objects3});
gdjs.nivel_321Code.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects3 */

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDCarta_9595R1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595R2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l2Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S1Objects3ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S2Objects3Objects);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects3 */
/* Reuse gdjs.nivel_321Code.GDposicionObjects3 */
{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects3[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDposicionObjects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDposicionObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.nivel_321Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Carta_K1"), gdjs.nivel_321Code.GDCarta_95K1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_K2"), gdjs.nivel_321Code.GDCarta_95K2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.nivel_321Code.GDCarta_95L1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.nivel_321Code.GDCarta_95L2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.nivel_321Code.GDCarta_95R1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.nivel_321Code.GDCarta_95R2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.nivel_321Code.GDCarta_95S1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.nivel_321Code.GDCarta_95S2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_l1"), gdjs.nivel_321Code.GDCarta_95l1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_l2"), gdjs.nivel_321Code.GDCarta_95l2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_r1"), gdjs.nivel_321Code.GDCarta_95r1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_r2"), gdjs.nivel_321Code.GDCarta_95r2Objects3);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R1Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R1Objects3[k] = gdjs.nivel_321Code.GDCarta_95R1Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R2Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R2Objects3[k] = gdjs.nivel_321Code.GDCarta_95R2Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L1Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L1Objects3[k] = gdjs.nivel_321Code.GDCarta_95L1Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L2Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L2Objects3[k] = gdjs.nivel_321Code.GDCarta_95L2Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r1Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r1Objects3[k] = gdjs.nivel_321Code.GDCarta_95r1Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r2Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r2Objects3[k] = gdjs.nivel_321Code.GDCarta_95r2Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K1Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K1Objects3[k] = gdjs.nivel_321Code.GDCarta_95K1Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K2Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K2Objects3[k] = gdjs.nivel_321Code.GDCarta_95K2Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l1Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l1Objects3[k] = gdjs.nivel_321Code.GDCarta_95l1Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l2Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l2Objects3[k] = gdjs.nivel_321Code.GDCarta_95l2Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S1Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S1Objects3[k] = gdjs.nivel_321Code.GDCarta_95S1Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S2Objects3.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S2Objects3[k] = gdjs.nivel_321Code.GDCarta_95S2Objects3[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S2Objects3.length = k;}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects3 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects3 */
gdjs.copyArray(gdjs.nivel_321Code.GDposicionObjects2, gdjs.nivel_321Code.GDposicionObjects3);

{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointX("")), (( gdjs.nivel_321Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.nivel_321Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
}
{ //Subevents
gdjs.nivel_321Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.nivel_321Code.eventsList5 = function(runtimeScene) {

{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("posicion"), gdjs.nivel_321Code.GDposicionObjects1);

for(gdjs.nivel_321Code.forEachIndex2 = 0;gdjs.nivel_321Code.forEachIndex2 < gdjs.nivel_321Code.GDposicionObjects1.length;++gdjs.nivel_321Code.forEachIndex2) {
gdjs.nivel_321Code.GDposicionObjects2.length = 0;


gdjs.nivel_321Code.forEachTemporary2 = gdjs.nivel_321Code.GDposicionObjects1[gdjs.nivel_321Code.forEachIndex2];
gdjs.nivel_321Code.GDposicionObjects2.push(gdjs.nivel_321Code.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.nivel_321Code.eventsList4(runtimeScene);} //Subevents end.
}
}

}


};gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDCarta_9595R1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595R2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S2Objects2Objects = Hashtable.newFrom({"Carta_R1": gdjs.nivel_321Code.GDCarta_95R1Objects2, "Carta_R2": gdjs.nivel_321Code.GDCarta_95R2Objects2, "Carta_L1": gdjs.nivel_321Code.GDCarta_95L1Objects2, "Carta_L2": gdjs.nivel_321Code.GDCarta_95L2Objects2, "Carta_r1": gdjs.nivel_321Code.GDCarta_95r1Objects2, "Carta_r2": gdjs.nivel_321Code.GDCarta_95r2Objects2, "Carta_K1": gdjs.nivel_321Code.GDCarta_95K1Objects2, "Carta_K2": gdjs.nivel_321Code.GDCarta_95K2Objects2, "Carta_l1": gdjs.nivel_321Code.GDCarta_95l1Objects2, "Carta_l2": gdjs.nivel_321Code.GDCarta_95l2Objects2, "Carta_S1": gdjs.nivel_321Code.GDCarta_95S1Objects2, "Carta_S2": gdjs.nivel_321Code.GDCarta_95S2Objects2});
gdjs.nivel_321Code.eventsList6 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "show_cards");
}{runtimeScene.getScene().getVariables().getFromIndex(4).setString("show_cards");
}}

}


};gdjs.nivel_321Code.eventsList7 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K1Objects2, gdjs.nivel_321Code.GDCarta_95K1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K2Objects2, gdjs.nivel_321Code.GDCarta_95K2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L1Objects2, gdjs.nivel_321Code.GDCarta_95L1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L2Objects2, gdjs.nivel_321Code.GDCarta_95L2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R1Objects2, gdjs.nivel_321Code.GDCarta_95R1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R2Objects2, gdjs.nivel_321Code.GDCarta_95R2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S1Objects2, gdjs.nivel_321Code.GDCarta_95S1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S2Objects2, gdjs.nivel_321Code.GDCarta_95S2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l1Objects2, gdjs.nivel_321Code.GDCarta_95l1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l2Objects2, gdjs.nivel_321Code.GDCarta_95l2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r1Objects2, gdjs.nivel_321Code.GDCarta_95r1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r2Objects2, gdjs.nivel_321Code.GDCarta_95r2Objects3);

{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects3[i].getBehavior("Tween").removeTween("uncover_1");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects3.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
}}

}


{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 2;
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K1Objects2, gdjs.nivel_321Code.GDCarta_95K1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K2Objects2, gdjs.nivel_321Code.GDCarta_95K2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L1Objects2, gdjs.nivel_321Code.GDCarta_95L1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L2Objects2, gdjs.nivel_321Code.GDCarta_95L2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R1Objects2, gdjs.nivel_321Code.GDCarta_95R1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R2Objects2, gdjs.nivel_321Code.GDCarta_95R2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S1Objects2, gdjs.nivel_321Code.GDCarta_95S1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S2Objects2, gdjs.nivel_321Code.GDCarta_95S2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l1Objects2, gdjs.nivel_321Code.GDCarta_95l1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l2Objects2, gdjs.nivel_321Code.GDCarta_95l2Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r1Objects2, gdjs.nivel_321Code.GDCarta_95r1Objects3);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r2Objects2, gdjs.nivel_321Code.GDCarta_95r2Objects3);

{runtimeScene.getScene().getVariables().getFromIndex(2).setString((gdjs.RuntimeObject.getVariableString(((gdjs.nivel_321Code.GDCarta_95S2Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95S1Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95l2Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95l1Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95K2Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95K1Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95r2Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95r1Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95L2Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95L1Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95R2Objects3.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95R1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.nivel_321Code.GDCarta_95R1Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95R2Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95L1Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95L2Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95r1Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95r2Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95K1Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95K2Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95l1Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95l2Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95S1Objects3[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95S2Objects3[0].getVariables()).get("id"))));
}
{ //Subevents
gdjs.nivel_321Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 1;
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).setString((gdjs.RuntimeObject.getVariableString(((gdjs.nivel_321Code.GDCarta_95S2Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95S1Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95l2Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95l1Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95K2Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95K1Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95r2Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95r1Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95L2Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95L1Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95R2Objects2.length === 0 ) ? ((gdjs.nivel_321Code.GDCarta_95R1Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.nivel_321Code.GDCarta_95R1Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95R2Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95L1Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95L2Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95r1Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95r2Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95K1Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95K2Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95l1Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95l2Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95S1Objects2[0].getVariables()) : gdjs.nivel_321Code.GDCarta_95S2Objects2[0].getVariables()).get("id"))));
}}

}


};gdjs.nivel_321Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Carta_K1"), gdjs.nivel_321Code.GDCarta_95K1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_K2"), gdjs.nivel_321Code.GDCarta_95K2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.nivel_321Code.GDCarta_95L1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.nivel_321Code.GDCarta_95L2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.nivel_321Code.GDCarta_95R1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.nivel_321Code.GDCarta_95R2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.nivel_321Code.GDCarta_95S1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.nivel_321Code.GDCarta_95S2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_l1"), gdjs.nivel_321Code.GDCarta_95l1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_l2"), gdjs.nivel_321Code.GDCarta_95l2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_r1"), gdjs.nivel_321Code.GDCarta_95r1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_r2"), gdjs.nivel_321Code.GDCarta_95r2Objects2);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
gdjs.nivel_321Code.condition1IsTrue_0.val = false;
gdjs.nivel_321Code.condition2IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.nivel_321Code.condition0IsTrue_0.val ) {
{
gdjs.nivel_321Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDCarta_9595R1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595R2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l2Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S1Objects2ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S2Objects2Objects, runtimeScene, true, false);
}if ( gdjs.nivel_321Code.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R1Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R1Objects2[k] = gdjs.nivel_321Code.GDCarta_95R1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R2Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R2Objects2[k] = gdjs.nivel_321Code.GDCarta_95R2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L1Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L1Objects2[k] = gdjs.nivel_321Code.GDCarta_95L1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L2Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L2Objects2[k] = gdjs.nivel_321Code.GDCarta_95L2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r1Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r1Objects2[k] = gdjs.nivel_321Code.GDCarta_95r1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r2Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r2Objects2[k] = gdjs.nivel_321Code.GDCarta_95r2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K1Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K1Objects2[k] = gdjs.nivel_321Code.GDCarta_95K1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K2Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K2Objects2[k] = gdjs.nivel_321Code.GDCarta_95K2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l1Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l1Objects2[k] = gdjs.nivel_321Code.GDCarta_95l1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l2Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l2Objects2[k] = gdjs.nivel_321Code.GDCarta_95l2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S1Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S1Objects2[k] = gdjs.nivel_321Code.GDCarta_95S1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S2Objects2[i].isCurrentAnimationName("back") ) {
        gdjs.nivel_321Code.condition2IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S2Objects2[k] = gdjs.nivel_321Code.GDCarta_95S2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S2Objects2.length = k;}}
}
if (gdjs.nivel_321Code.condition2IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\sonidos\\cartas.mp3", false, 100, 1);
}
{ //Subevents
gdjs.nivel_321Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.nivel_321Code.eventsList9 = function(runtimeScene) {

{


{
/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects2 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects2 */
{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects2[i].setAnimationName("front");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects2[i].getBehavior("Tween").removeTween("uncover_0");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects2.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
}}

}


};gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDCarta_9595R1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595R2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S2Objects4Objects = Hashtable.newFrom({"Carta_R1": gdjs.nivel_321Code.GDCarta_95R1Objects4, "Carta_R2": gdjs.nivel_321Code.GDCarta_95R2Objects4, "Carta_L1": gdjs.nivel_321Code.GDCarta_95L1Objects4, "Carta_L2": gdjs.nivel_321Code.GDCarta_95L2Objects4, "Carta_r1": gdjs.nivel_321Code.GDCarta_95r1Objects4, "Carta_r2": gdjs.nivel_321Code.GDCarta_95r2Objects4, "Carta_K1": gdjs.nivel_321Code.GDCarta_95K1Objects4, "Carta_K2": gdjs.nivel_321Code.GDCarta_95K2Objects4, "Carta_l1": gdjs.nivel_321Code.GDCarta_95l1Objects4, "Carta_l2": gdjs.nivel_321Code.GDCarta_95l2Objects4, "Carta_S1": gdjs.nivel_321Code.GDCarta_95S1Objects4, "Carta_S2": gdjs.nivel_321Code.GDCarta_95S2Objects4});
gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDparticulasObjects6Objects = Hashtable.newFrom({"particulas": gdjs.nivel_321Code.GDparticulasObjects6});
gdjs.nivel_321Code.eventsList10 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K1Objects5, gdjs.nivel_321Code.GDCarta_95K1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K2Objects5, gdjs.nivel_321Code.GDCarta_95K2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L1Objects5, gdjs.nivel_321Code.GDCarta_95L1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L2Objects5, gdjs.nivel_321Code.GDCarta_95L2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R1Objects5, gdjs.nivel_321Code.GDCarta_95R1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R2Objects5, gdjs.nivel_321Code.GDCarta_95R2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S1Objects5, gdjs.nivel_321Code.GDCarta_95S1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S2Objects5, gdjs.nivel_321Code.GDCarta_95S2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l1Objects5, gdjs.nivel_321Code.GDCarta_95l1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l2Objects5, gdjs.nivel_321Code.GDCarta_95l2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r1Objects5, gdjs.nivel_321Code.GDCarta_95r1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r2Objects5, gdjs.nivel_321Code.GDCarta_95r2Objects6);

gdjs.copyArray(runtimeScene.getObjects("personaje1"), gdjs.nivel_321Code.GDpersonaje1Objects6);
gdjs.nivel_321Code.GDparticulasObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDparticulasObjects6Objects, (( gdjs.nivel_321Code.GDCarta_95S2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95S1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95l2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95l1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95K2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95K1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95r2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95r1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95L2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95L1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95R2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95R1Objects6.length === 0 ) ? 0 :gdjs.nivel_321Code.GDCarta_95R1Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95R2Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95L1Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95L2Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95r1Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95r2Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95K1Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95K2Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95l1Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95l2Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95S1Objects6[0].getPointX("")) :gdjs.nivel_321Code.GDCarta_95S2Objects6[0].getPointX("")), (( gdjs.nivel_321Code.GDCarta_95S2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95S1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95l2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95l1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95K2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95K1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95r2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95r1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95L2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95L1Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95R2Objects6.length === 0 ) ? (( gdjs.nivel_321Code.GDCarta_95R1Objects6.length === 0 ) ? 0 :gdjs.nivel_321Code.GDCarta_95R1Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95R2Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95L1Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95L2Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95r1Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95r2Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95K1Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95K2Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95l1Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95l2Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95S1Objects6[0].getPointY("")) :gdjs.nivel_321Code.GDCarta_95S2Objects6[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.nivel_321Code.GDparticulasObjects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDparticulasObjects6[i].setZOrder(100);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\busquemos_los_pares\\sonidos\\parejass.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.nivel_321Code.GDpersonaje1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDpersonaje1Objects6[i].setAnimationName("correcto");
}
}}

}


{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
{gdjs.nivel_321Code.conditionTrue_1 = gdjs.nivel_321Code.condition0IsTrue_0;
gdjs.nivel_321Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35917924);
}
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K1Objects5, gdjs.nivel_321Code.GDCarta_95K1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95K2Objects5, gdjs.nivel_321Code.GDCarta_95K2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L1Objects5, gdjs.nivel_321Code.GDCarta_95L1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95L2Objects5, gdjs.nivel_321Code.GDCarta_95L2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R1Objects5, gdjs.nivel_321Code.GDCarta_95R1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95R2Objects5, gdjs.nivel_321Code.GDCarta_95R2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S1Objects5, gdjs.nivel_321Code.GDCarta_95S1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95S2Objects5, gdjs.nivel_321Code.GDCarta_95S2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l1Objects5, gdjs.nivel_321Code.GDCarta_95l1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95l2Objects5, gdjs.nivel_321Code.GDCarta_95l2Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r1Objects5, gdjs.nivel_321Code.GDCarta_95r1Objects6);

gdjs.copyArray(gdjs.nivel_321Code.GDCarta_95r2Objects5, gdjs.nivel_321Code.GDCarta_95r2Objects6);

{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects6.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
}}

}


};gdjs.nivel_321Code.eventsList11 = function(runtimeScene) {

{

/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects4 */

gdjs.nivel_321Code.forEachTotalCount5 = 0;
gdjs.nivel_321Code.forEachObjects5.length = 0;
gdjs.nivel_321Code.forEachCount0_5 = gdjs.nivel_321Code.GDCarta_95R1Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount0_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95R1Objects4);
gdjs.nivel_321Code.forEachCount1_5 = gdjs.nivel_321Code.GDCarta_95R2Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount1_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95R2Objects4);
gdjs.nivel_321Code.forEachCount2_5 = gdjs.nivel_321Code.GDCarta_95L1Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount2_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95L1Objects4);
gdjs.nivel_321Code.forEachCount3_5 = gdjs.nivel_321Code.GDCarta_95L2Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount3_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95L2Objects4);
gdjs.nivel_321Code.forEachCount4_5 = gdjs.nivel_321Code.GDCarta_95r1Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount4_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95r1Objects4);
gdjs.nivel_321Code.forEachCount5_5 = gdjs.nivel_321Code.GDCarta_95r2Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount5_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95r2Objects4);
gdjs.nivel_321Code.forEachCount6_5 = gdjs.nivel_321Code.GDCarta_95K1Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount6_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95K1Objects4);
gdjs.nivel_321Code.forEachCount7_5 = gdjs.nivel_321Code.GDCarta_95K2Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount7_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95K2Objects4);
gdjs.nivel_321Code.forEachCount8_5 = gdjs.nivel_321Code.GDCarta_95l1Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount8_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95l1Objects4);
gdjs.nivel_321Code.forEachCount9_5 = gdjs.nivel_321Code.GDCarta_95l2Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount9_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95l2Objects4);
gdjs.nivel_321Code.forEachCount10_5 = gdjs.nivel_321Code.GDCarta_95S1Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount10_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95S1Objects4);
gdjs.nivel_321Code.forEachCount11_5 = gdjs.nivel_321Code.GDCarta_95S2Objects4.length;
gdjs.nivel_321Code.forEachTotalCount5 += gdjs.nivel_321Code.forEachCount11_5;
gdjs.nivel_321Code.forEachObjects5.push.apply(gdjs.nivel_321Code.forEachObjects5,gdjs.nivel_321Code.GDCarta_95S2Objects4);
for(gdjs.nivel_321Code.forEachIndex5 = 0;gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachTotalCount5;++gdjs.nivel_321Code.forEachIndex5) {
gdjs.nivel_321Code.GDCarta_95K1Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95K2Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95L1Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95L2Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95R1Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95R2Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95S1Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95S2Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95l1Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95l2Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95r1Objects5.length = 0;

gdjs.nivel_321Code.GDCarta_95r2Objects5.length = 0;


if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5) {
    gdjs.nivel_321Code.GDCarta_95R1Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5) {
    gdjs.nivel_321Code.GDCarta_95R2Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5) {
    gdjs.nivel_321Code.GDCarta_95L1Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5) {
    gdjs.nivel_321Code.GDCarta_95L2Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5) {
    gdjs.nivel_321Code.GDCarta_95r1Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5) {
    gdjs.nivel_321Code.GDCarta_95r2Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5+gdjs.nivel_321Code.forEachCount6_5) {
    gdjs.nivel_321Code.GDCarta_95K1Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5+gdjs.nivel_321Code.forEachCount6_5+gdjs.nivel_321Code.forEachCount7_5) {
    gdjs.nivel_321Code.GDCarta_95K2Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5+gdjs.nivel_321Code.forEachCount6_5+gdjs.nivel_321Code.forEachCount7_5+gdjs.nivel_321Code.forEachCount8_5) {
    gdjs.nivel_321Code.GDCarta_95l1Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5+gdjs.nivel_321Code.forEachCount6_5+gdjs.nivel_321Code.forEachCount7_5+gdjs.nivel_321Code.forEachCount8_5+gdjs.nivel_321Code.forEachCount9_5) {
    gdjs.nivel_321Code.GDCarta_95l2Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5+gdjs.nivel_321Code.forEachCount6_5+gdjs.nivel_321Code.forEachCount7_5+gdjs.nivel_321Code.forEachCount8_5+gdjs.nivel_321Code.forEachCount9_5+gdjs.nivel_321Code.forEachCount10_5) {
    gdjs.nivel_321Code.GDCarta_95S1Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
else if (gdjs.nivel_321Code.forEachIndex5 < gdjs.nivel_321Code.forEachCount0_5+gdjs.nivel_321Code.forEachCount1_5+gdjs.nivel_321Code.forEachCount2_5+gdjs.nivel_321Code.forEachCount3_5+gdjs.nivel_321Code.forEachCount4_5+gdjs.nivel_321Code.forEachCount5_5+gdjs.nivel_321Code.forEachCount6_5+gdjs.nivel_321Code.forEachCount7_5+gdjs.nivel_321Code.forEachCount8_5+gdjs.nivel_321Code.forEachCount9_5+gdjs.nivel_321Code.forEachCount10_5+gdjs.nivel_321Code.forEachCount11_5) {
    gdjs.nivel_321Code.GDCarta_95S2Objects5.push(gdjs.nivel_321Code.forEachObjects5[gdjs.nivel_321Code.forEachIndex5]);
}
if (true) {

{ //Subevents: 
gdjs.nivel_321Code.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.nivel_321Code.eventsList12 = function(runtimeScene) {

{

/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects4 */

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R1Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95R1Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R1Objects4[k] = gdjs.nivel_321Code.GDCarta_95R1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R2Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95R2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R2Objects4[k] = gdjs.nivel_321Code.GDCarta_95R2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L1Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95L1Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L1Objects4[k] = gdjs.nivel_321Code.GDCarta_95L1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L2Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95L2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L2Objects4[k] = gdjs.nivel_321Code.GDCarta_95L2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r1Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95r1Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r1Objects4[k] = gdjs.nivel_321Code.GDCarta_95r1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r2Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95r2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r2Objects4[k] = gdjs.nivel_321Code.GDCarta_95r2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K1Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95K1Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K1Objects4[k] = gdjs.nivel_321Code.GDCarta_95K1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K2Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95K2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K2Objects4[k] = gdjs.nivel_321Code.GDCarta_95K2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l1Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95l1Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l1Objects4[k] = gdjs.nivel_321Code.GDCarta_95l1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l2Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95l2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l2Objects4[k] = gdjs.nivel_321Code.GDCarta_95l2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S1Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95S1Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S1Objects4[k] = gdjs.nivel_321Code.GDCarta_95S1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S2Objects4[i].getVariableString(gdjs.nivel_321Code.GDCarta_95S2Objects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S2Objects4[k] = gdjs.nivel_321Code.GDCarta_95S2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S2Objects4.length = k;}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.nivel_321Code.eventsList13 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Carta_K1"), gdjs.nivel_321Code.GDCarta_95K1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_K2"), gdjs.nivel_321Code.GDCarta_95K2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.nivel_321Code.GDCarta_95L1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.nivel_321Code.GDCarta_95L2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.nivel_321Code.GDCarta_95R1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.nivel_321Code.GDCarta_95R2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.nivel_321Code.GDCarta_95S1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.nivel_321Code.GDCarta_95S2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_l1"), gdjs.nivel_321Code.GDCarta_95l1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_l2"), gdjs.nivel_321Code.GDCarta_95l2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_r1"), gdjs.nivel_321Code.GDCarta_95r1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_r2"), gdjs.nivel_321Code.GDCarta_95r2Objects4);
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDCarta_9595R1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595R2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595L2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595r2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595K2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595l2Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S1Objects4ObjectsGDgdjs_46nivel_95321Code_46GDCarta_9595S2Objects4Objects);
}
{ //Subevents
gdjs.nivel_321Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.nivel_321Code.eventsList14 = function(runtimeScene) {

{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2));
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{ //Subevents
gdjs.nivel_321Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carta_K1"), gdjs.nivel_321Code.GDCarta_95K1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_K2"), gdjs.nivel_321Code.GDCarta_95K2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.nivel_321Code.GDCarta_95L1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.nivel_321Code.GDCarta_95L2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.nivel_321Code.GDCarta_95R1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.nivel_321Code.GDCarta_95R2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.nivel_321Code.GDCarta_95S1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.nivel_321Code.GDCarta_95S2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_l1"), gdjs.nivel_321Code.GDCarta_95l1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_l2"), gdjs.nivel_321Code.GDCarta_95l2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_r1"), gdjs.nivel_321Code.GDCarta_95r1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Carta_r2"), gdjs.nivel_321Code.GDCarta_95r2Objects4);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
gdjs.nivel_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R1Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R1Objects4[k] = gdjs.nivel_321Code.GDCarta_95R1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R2Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R2Objects4[k] = gdjs.nivel_321Code.GDCarta_95R2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L1Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L1Objects4[k] = gdjs.nivel_321Code.GDCarta_95L1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L2Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L2Objects4[k] = gdjs.nivel_321Code.GDCarta_95L2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r1Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r1Objects4[k] = gdjs.nivel_321Code.GDCarta_95r1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r2Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r2Objects4[k] = gdjs.nivel_321Code.GDCarta_95r2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K1Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K1Objects4[k] = gdjs.nivel_321Code.GDCarta_95K1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K2Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K2Objects4[k] = gdjs.nivel_321Code.GDCarta_95K2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l1Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l1Objects4[k] = gdjs.nivel_321Code.GDCarta_95l1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l2Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l2Objects4[k] = gdjs.nivel_321Code.GDCarta_95l2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S1Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S1Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S1Objects4[k] = gdjs.nivel_321Code.GDCarta_95S1Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S2Objects4.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S2Objects4[i].isCurrentAnimationName("front") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S2Objects4[k] = gdjs.nivel_321Code.GDCarta_95S2Objects4[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S2Objects4.length = k;}if ( gdjs.nivel_321Code.condition0IsTrue_0.val ) {
{
{gdjs.nivel_321Code.conditionTrue_1 = gdjs.nivel_321Code.condition1IsTrue_0;
gdjs.nivel_321Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35919060);
}
}}
if (gdjs.nivel_321Code.condition1IsTrue_0.val) {
/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects4 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects4 */
{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects4[i].getBehavior("Tween").removeTween("cover_1");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects4.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
}}

}


{


{
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.nivel_321Code.eventsList15 = function(runtimeScene) {

{


{

{ //Subevents
gdjs.nivel_321Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


{
{runtimeScene.getScene().getVariables().getFromIndex(4).setString("player_turn");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


};gdjs.nivel_321Code.eventsList16 = function(runtimeScene) {

{


{
/* Reuse gdjs.nivel_321Code.GDCarta_95K1Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95K2Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L1Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95L2Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R1Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95R2Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S1Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95S2Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l1Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95l2Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r1Objects1 */
/* Reuse gdjs.nivel_321Code.GDCarta_95r2Objects1 */
{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects1[i].getBehavior("Tween").removeTween("cover_0");
}
}{for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R1Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95R2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L1Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95L2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95L2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r1Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95r2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95r2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K1Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95K2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95K2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l1Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95l2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95l2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S1Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.nivel_321Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDCarta_95S2Objects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
}}

}


};gdjs.nivel_321Code.eventsList17 = function(runtimeScene) {

{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)) == "player_turn";
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carta_K1"), gdjs.nivel_321Code.GDCarta_95K1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_K2"), gdjs.nivel_321Code.GDCarta_95K2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.nivel_321Code.GDCarta_95L1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.nivel_321Code.GDCarta_95L2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.nivel_321Code.GDCarta_95R1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.nivel_321Code.GDCarta_95R2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.nivel_321Code.GDCarta_95S1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.nivel_321Code.GDCarta_95S2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_l1"), gdjs.nivel_321Code.GDCarta_95l1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_l2"), gdjs.nivel_321Code.GDCarta_95l2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_r1"), gdjs.nivel_321Code.GDCarta_95r1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Carta_r2"), gdjs.nivel_321Code.GDCarta_95r2Objects2);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R1Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R1Objects2[k] = gdjs.nivel_321Code.GDCarta_95R1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R2Objects2[k] = gdjs.nivel_321Code.GDCarta_95R2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L1Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L1Objects2[k] = gdjs.nivel_321Code.GDCarta_95L1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L2Objects2[k] = gdjs.nivel_321Code.GDCarta_95L2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r1Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r1Objects2[k] = gdjs.nivel_321Code.GDCarta_95r1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r2Objects2[k] = gdjs.nivel_321Code.GDCarta_95r2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K1Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K1Objects2[k] = gdjs.nivel_321Code.GDCarta_95K1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K2Objects2[k] = gdjs.nivel_321Code.GDCarta_95K2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l1Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l1Objects2[k] = gdjs.nivel_321Code.GDCarta_95l1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l2Objects2[k] = gdjs.nivel_321Code.GDCarta_95l2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S1Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S1Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S1Objects2[k] = gdjs.nivel_321Code.GDCarta_95S1Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S2Objects2.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S2Objects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S2Objects2[k] = gdjs.nivel_321Code.GDCarta_95S2Objects2[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S2Objects2.length = k;}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
gdjs.nivel_321Code.condition1IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "show_cards") > 1;
}if ( gdjs.nivel_321Code.condition0IsTrue_0.val ) {
{
{gdjs.nivel_321Code.conditionTrue_1 = gdjs.nivel_321Code.condition1IsTrue_0;
gdjs.nivel_321Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35914212);
}
}}
if (gdjs.nivel_321Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carta_K1"), gdjs.nivel_321Code.GDCarta_95K1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_K2"), gdjs.nivel_321Code.GDCarta_95K2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.nivel_321Code.GDCarta_95L1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.nivel_321Code.GDCarta_95L2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.nivel_321Code.GDCarta_95R1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.nivel_321Code.GDCarta_95R2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.nivel_321Code.GDCarta_95S1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.nivel_321Code.GDCarta_95S2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_l1"), gdjs.nivel_321Code.GDCarta_95l1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_l2"), gdjs.nivel_321Code.GDCarta_95l2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_r1"), gdjs.nivel_321Code.GDCarta_95r1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_r2"), gdjs.nivel_321Code.GDCarta_95r2Objects1);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
gdjs.nivel_321Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R1Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R1Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R1Objects1[k] = gdjs.nivel_321Code.GDCarta_95R1Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95R2Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95R2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95R2Objects1[k] = gdjs.nivel_321Code.GDCarta_95R2Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95R2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L1Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L1Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L1Objects1[k] = gdjs.nivel_321Code.GDCarta_95L1Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95L2Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95L2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95L2Objects1[k] = gdjs.nivel_321Code.GDCarta_95L2Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95L2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r1Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r1Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r1Objects1[k] = gdjs.nivel_321Code.GDCarta_95r1Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95r2Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95r2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95r2Objects1[k] = gdjs.nivel_321Code.GDCarta_95r2Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95r2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K1Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K1Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K1Objects1[k] = gdjs.nivel_321Code.GDCarta_95K1Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95K2Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95K2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95K2Objects1[k] = gdjs.nivel_321Code.GDCarta_95K2Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95K2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l1Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l1Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l1Objects1[k] = gdjs.nivel_321Code.GDCarta_95l1Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95l2Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95l2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95l2Objects1[k] = gdjs.nivel_321Code.GDCarta_95l2Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95l2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S1Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S1Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S1Objects1[k] = gdjs.nivel_321Code.GDCarta_95S1Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDCarta_95S2Objects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDCarta_95S2Objects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDCarta_95S2Objects1[k] = gdjs.nivel_321Code.GDCarta_95S2Objects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDCarta_95S2Objects1.length = k;}if ( gdjs.nivel_321Code.condition0IsTrue_0.val ) {
{
{gdjs.nivel_321Code.conditionTrue_1 = gdjs.nivel_321Code.condition1IsTrue_0;
gdjs.nivel_321Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35922148);
}
}}
if (gdjs.nivel_321Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs.nivel_321Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.nivel_321Code.eventsList18 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.nivel_321Code.GDParejasObjects1);
{for(var i = 0, len = gdjs.nivel_321Code.GDParejasObjects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDParejasObjects1[i].setString("Parejas: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}}

}


};gdjs.nivel_321Code.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.nivel_321Code.GDParejasObjects1);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.nivel_321Code.GDParejasObjects1.length;i<l;++i) {
    if ( gdjs.nivel_321Code.GDParejasObjects1[i].getString() == "Parejas: 2" ) {
        gdjs.nivel_321Code.condition0IsTrue_0.val = true;
        gdjs.nivel_321Code.GDParejasObjects1[k] = gdjs.nivel_321Code.GDParejasObjects1[i];
        ++k;
    }
}
gdjs.nivel_321Code.GDParejasObjects1.length = k;}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "nivel 2", false);
}}

}


};gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.nivel_321Code.GDregresarObjects1});
gdjs.nivel_321Code.eventsList20 = function(runtimeScene) {

{


gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_semantica", false);
}}

}


};gdjs.nivel_321Code.eventsList21 = function(runtimeScene) {

{


gdjs.nivel_321Code.eventsList1(runtimeScene);
}


{


gdjs.nivel_321Code.eventsList5(runtimeScene);
}


{


gdjs.nivel_321Code.eventsList17(runtimeScene);
}


{


gdjs.nivel_321Code.eventsList18(runtimeScene);
}


{


gdjs.nivel_321Code.eventsList19(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.nivel_321Code.GDregresarObjects1);

gdjs.nivel_321Code.condition0IsTrue_0.val = false;
{
gdjs.nivel_321Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.nivel_321Code.mapOfGDgdjs_46nivel_95321Code_46GDregresarObjects1Objects, runtimeScene, true, false);
}if (gdjs.nivel_321Code.condition0IsTrue_0.val) {
/* Reuse gdjs.nivel_321Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.nivel_321Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.nivel_321Code.GDregresarObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.nivel_321Code.eventsList20(runtimeScene);} //End of subevents
}

}


};

gdjs.nivel_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.nivel_321Code.GDpersonajeObjects1.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects2.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects3.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects4.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects5.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects6.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects7.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95R1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects7.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects1.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects2.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects3.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects4.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects5.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects6.length = 0;
gdjs.nivel_321Code.GDpersonajeDObjects7.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects1.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects2.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects3.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects4.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects5.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects6.length = 0;
gdjs.nivel_321Code.GDpersonaje1Objects7.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects1.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects2.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects3.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects4.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects5.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects6.length = 0;
gdjs.nivel_321Code.GDpersonajeObjects7.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95R2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95L1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95L2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95r1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95r2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95K1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95K2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95l1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95l2Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95S1Objects7.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects1.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects2.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects3.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects4.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects5.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects6.length = 0;
gdjs.nivel_321Code.GDCarta_95S2Objects7.length = 0;
gdjs.nivel_321Code.GDbloque1Objects1.length = 0;
gdjs.nivel_321Code.GDbloque1Objects2.length = 0;
gdjs.nivel_321Code.GDbloque1Objects3.length = 0;
gdjs.nivel_321Code.GDbloque1Objects4.length = 0;
gdjs.nivel_321Code.GDbloque1Objects5.length = 0;
gdjs.nivel_321Code.GDbloque1Objects6.length = 0;
gdjs.nivel_321Code.GDbloque1Objects7.length = 0;
gdjs.nivel_321Code.GDbloque2Objects1.length = 0;
gdjs.nivel_321Code.GDbloque2Objects2.length = 0;
gdjs.nivel_321Code.GDbloque2Objects3.length = 0;
gdjs.nivel_321Code.GDbloque2Objects4.length = 0;
gdjs.nivel_321Code.GDbloque2Objects5.length = 0;
gdjs.nivel_321Code.GDbloque2Objects6.length = 0;
gdjs.nivel_321Code.GDbloque2Objects7.length = 0;
gdjs.nivel_321Code.GDbloque3Objects1.length = 0;
gdjs.nivel_321Code.GDbloque3Objects2.length = 0;
gdjs.nivel_321Code.GDbloque3Objects3.length = 0;
gdjs.nivel_321Code.GDbloque3Objects4.length = 0;
gdjs.nivel_321Code.GDbloque3Objects5.length = 0;
gdjs.nivel_321Code.GDbloque3Objects6.length = 0;
gdjs.nivel_321Code.GDbloque3Objects7.length = 0;
gdjs.nivel_321Code.GDfondoObjects1.length = 0;
gdjs.nivel_321Code.GDfondoObjects2.length = 0;
gdjs.nivel_321Code.GDfondoObjects3.length = 0;
gdjs.nivel_321Code.GDfondoObjects4.length = 0;
gdjs.nivel_321Code.GDfondoObjects5.length = 0;
gdjs.nivel_321Code.GDfondoObjects6.length = 0;
gdjs.nivel_321Code.GDfondoObjects7.length = 0;
gdjs.nivel_321Code.GDNivelObjects1.length = 0;
gdjs.nivel_321Code.GDNivelObjects2.length = 0;
gdjs.nivel_321Code.GDNivelObjects3.length = 0;
gdjs.nivel_321Code.GDNivelObjects4.length = 0;
gdjs.nivel_321Code.GDNivelObjects5.length = 0;
gdjs.nivel_321Code.GDNivelObjects6.length = 0;
gdjs.nivel_321Code.GDNivelObjects7.length = 0;
gdjs.nivel_321Code.GDParejasObjects1.length = 0;
gdjs.nivel_321Code.GDParejasObjects2.length = 0;
gdjs.nivel_321Code.GDParejasObjects3.length = 0;
gdjs.nivel_321Code.GDParejasObjects4.length = 0;
gdjs.nivel_321Code.GDParejasObjects5.length = 0;
gdjs.nivel_321Code.GDParejasObjects6.length = 0;
gdjs.nivel_321Code.GDParejasObjects7.length = 0;
gdjs.nivel_321Code.GDposicionObjects1.length = 0;
gdjs.nivel_321Code.GDposicionObjects2.length = 0;
gdjs.nivel_321Code.GDposicionObjects3.length = 0;
gdjs.nivel_321Code.GDposicionObjects4.length = 0;
gdjs.nivel_321Code.GDposicionObjects5.length = 0;
gdjs.nivel_321Code.GDposicionObjects6.length = 0;
gdjs.nivel_321Code.GDposicionObjects7.length = 0;
gdjs.nivel_321Code.GDparticulasObjects1.length = 0;
gdjs.nivel_321Code.GDparticulasObjects2.length = 0;
gdjs.nivel_321Code.GDparticulasObjects3.length = 0;
gdjs.nivel_321Code.GDparticulasObjects4.length = 0;
gdjs.nivel_321Code.GDparticulasObjects5.length = 0;
gdjs.nivel_321Code.GDparticulasObjects6.length = 0;
gdjs.nivel_321Code.GDparticulasObjects7.length = 0;
gdjs.nivel_321Code.GDnivelObjects1.length = 0;
gdjs.nivel_321Code.GDnivelObjects2.length = 0;
gdjs.nivel_321Code.GDnivelObjects3.length = 0;
gdjs.nivel_321Code.GDnivelObjects4.length = 0;
gdjs.nivel_321Code.GDnivelObjects5.length = 0;
gdjs.nivel_321Code.GDnivelObjects6.length = 0;
gdjs.nivel_321Code.GDnivelObjects7.length = 0;
gdjs.nivel_321Code.GDregresarObjects1.length = 0;
gdjs.nivel_321Code.GDregresarObjects2.length = 0;
gdjs.nivel_321Code.GDregresarObjects3.length = 0;
gdjs.nivel_321Code.GDregresarObjects4.length = 0;
gdjs.nivel_321Code.GDregresarObjects5.length = 0;
gdjs.nivel_321Code.GDregresarObjects6.length = 0;
gdjs.nivel_321Code.GDregresarObjects7.length = 0;

gdjs.nivel_321Code.eventsList21(runtimeScene);

return;

}

gdjs['nivel_321Code'] = gdjs.nivel_321Code;
