gdjs.Outro_95palabraCode = {};
gdjs.Outro_95palabraCode.GDpersonajeObjects1= [];
gdjs.Outro_95palabraCode.GDpersonajeObjects2= [];
gdjs.Outro_95palabraCode.GDCarta_95R1Objects1= [];
gdjs.Outro_95palabraCode.GDCarta_95R1Objects2= [];
gdjs.Outro_95palabraCode.GDCarta_95K2Objects1= [];
gdjs.Outro_95palabraCode.GDCarta_95K2Objects2= [];
gdjs.Outro_95palabraCode.GDCarta_95K1Objects1= [];
gdjs.Outro_95palabraCode.GDCarta_95K1Objects2= [];
gdjs.Outro_95palabraCode.GDCarta_95R2Objects1= [];
gdjs.Outro_95palabraCode.GDCarta_95R2Objects2= [];
gdjs.Outro_95palabraCode.GDCarta_95S1Objects1= [];
gdjs.Outro_95palabraCode.GDCarta_95S1Objects2= [];
gdjs.Outro_95palabraCode.GDCarta_95S2Objects1= [];
gdjs.Outro_95palabraCode.GDCarta_95S2Objects2= [];
gdjs.Outro_95palabraCode.GDpersonajeDObjects1= [];
gdjs.Outro_95palabraCode.GDpersonajeDObjects2= [];
gdjs.Outro_95palabraCode.GDabeja1Objects1= [];
gdjs.Outro_95palabraCode.GDabeja1Objects2= [];
gdjs.Outro_95palabraCode.GDflor1Objects1= [];
gdjs.Outro_95palabraCode.GDflor1Objects2= [];
gdjs.Outro_95palabraCode.GDflor_95moradaObjects1= [];
gdjs.Outro_95palabraCode.GDflor_95moradaObjects2= [];
gdjs.Outro_95palabraCode.GDflor2Objects1= [];
gdjs.Outro_95palabraCode.GDflor2Objects2= [];
gdjs.Outro_95palabraCode.GDflor_95rosaObjects1= [];
gdjs.Outro_95palabraCode.GDflor_95rosaObjects2= [];
gdjs.Outro_95palabraCode.GDflor3Objects1= [];
gdjs.Outro_95palabraCode.GDflor3Objects2= [];
gdjs.Outro_95palabraCode.GDflor_95naranjaObjects1= [];
gdjs.Outro_95palabraCode.GDflor_95naranjaObjects2= [];
gdjs.Outro_95palabraCode.GDflor4Objects1= [];
gdjs.Outro_95palabraCode.GDflor4Objects2= [];
gdjs.Outro_95palabraCode.GDflor_95rosadaObjects1= [];
gdjs.Outro_95palabraCode.GDflor_95rosadaObjects2= [];
gdjs.Outro_95palabraCode.GDflor5Objects1= [];
gdjs.Outro_95palabraCode.GDflor5Objects2= [];
gdjs.Outro_95palabraCode.GDflor_95amarillaObjects1= [];
gdjs.Outro_95palabraCode.GDflor_95amarillaObjects2= [];
gdjs.Outro_95palabraCode.GDflor6Objects1= [];
gdjs.Outro_95palabraCode.GDflor6Objects2= [];
gdjs.Outro_95palabraCode.GDflor_95verdeObjects1= [];
gdjs.Outro_95palabraCode.GDflor_95verdeObjects2= [];
gdjs.Outro_95palabraCode.GDmuro_95arribaObjects1= [];
gdjs.Outro_95palabraCode.GDmuro_95arribaObjects2= [];
gdjs.Outro_95palabraCode.GDmuro_95abajoObjects1= [];
gdjs.Outro_95palabraCode.GDmuro_95abajoObjects2= [];
gdjs.Outro_95palabraCode.GDmuro_95izquierdaObjects1= [];
gdjs.Outro_95palabraCode.GDmuro_95izquierdaObjects2= [];
gdjs.Outro_95palabraCode.GDmuro_95derechaObjects1= [];
gdjs.Outro_95palabraCode.GDmuro_95derechaObjects2= [];
gdjs.Outro_95palabraCode.GDcreador1Objects1= [];
gdjs.Outro_95palabraCode.GDcreador1Objects2= [];
gdjs.Outro_95palabraCode.GDcreador2Objects1= [];
gdjs.Outro_95palabraCode.GDcreador2Objects2= [];
gdjs.Outro_95palabraCode.GDcreador3Objects1= [];
gdjs.Outro_95palabraCode.GDcreador3Objects2= [];
gdjs.Outro_95palabraCode.GDcreador4Objects1= [];
gdjs.Outro_95palabraCode.GDcreador4Objects2= [];
gdjs.Outro_95palabraCode.GDbloque2Objects1= [];
gdjs.Outro_95palabraCode.GDbloque2Objects2= [];
gdjs.Outro_95palabraCode.GDbloque3Objects1= [];
gdjs.Outro_95palabraCode.GDbloque3Objects2= [];
gdjs.Outro_95palabraCode.GDfondoObjects1= [];
gdjs.Outro_95palabraCode.GDfondoObjects2= [];
gdjs.Outro_95palabraCode.GDNivelObjects1= [];
gdjs.Outro_95palabraCode.GDNivelObjects2= [];
gdjs.Outro_95palabraCode.GDContadorObjects1= [];
gdjs.Outro_95palabraCode.GDContadorObjects2= [];
gdjs.Outro_95palabraCode.GDposicionObjects1= [];
gdjs.Outro_95palabraCode.GDposicionObjects2= [];
gdjs.Outro_95palabraCode.GDparticulasObjects1= [];
gdjs.Outro_95palabraCode.GDparticulasObjects2= [];
gdjs.Outro_95palabraCode.GDnivelObjects1= [];
gdjs.Outro_95palabraCode.GDnivelObjects2= [];
gdjs.Outro_95palabraCode.GDregresarObjects1= [];
gdjs.Outro_95palabraCode.GDregresarObjects2= [];
gdjs.Outro_95palabraCode.GDNewParticlesEmitterObjects1= [];
gdjs.Outro_95palabraCode.GDNewParticlesEmitterObjects2= [];
gdjs.Outro_95palabraCode.GDNewTextObjects1= [];
gdjs.Outro_95palabraCode.GDNewTextObjects2= [];
gdjs.Outro_95palabraCode.GDINDICACIONESObjects1= [];
gdjs.Outro_95palabraCode.GDINDICACIONESObjects2= [];
gdjs.Outro_95palabraCode.GDtituloObjects1= [];
gdjs.Outro_95palabraCode.GDtituloObjects2= [];
gdjs.Outro_95palabraCode.GDdenuevoObjects1= [];
gdjs.Outro_95palabraCode.GDdenuevoObjects2= [];
gdjs.Outro_95palabraCode.GDsalirObjects1= [];
gdjs.Outro_95palabraCode.GDsalirObjects2= [];

gdjs.Outro_95palabraCode.conditionTrue_0 = {val:false};
gdjs.Outro_95palabraCode.condition0IsTrue_0 = {val:false};
gdjs.Outro_95palabraCode.condition1IsTrue_0 = {val:false};
gdjs.Outro_95palabraCode.condition2IsTrue_0 = {val:false};
gdjs.Outro_95palabraCode.conditionTrue_1 = {val:false};
gdjs.Outro_95palabraCode.condition0IsTrue_1 = {val:false};
gdjs.Outro_95palabraCode.condition1IsTrue_1 = {val:false};
gdjs.Outro_95palabraCode.condition2IsTrue_1 = {val:false};


gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDdenuevoObjects1Objects = Hashtable.newFrom({"denuevo": gdjs.Outro_95palabraCode.GDdenuevoObjects1});
gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDdenuevoObjects1Objects = Hashtable.newFrom({"denuevo": gdjs.Outro_95palabraCode.GDdenuevoObjects1});
gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDdenuevoObjects1Objects = Hashtable.newFrom({"denuevo": gdjs.Outro_95palabraCode.GDdenuevoObjects1});
gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDsalirObjects1Objects = Hashtable.newFrom({"salir": gdjs.Outro_95palabraCode.GDsalirObjects1});
gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDsalirObjects1Objects = Hashtable.newFrom({"salir": gdjs.Outro_95palabraCode.GDsalirObjects1});
gdjs.Outro_95palabraCode.eventsList0 = function(runtimeScene) {

{


gdjs.Outro_95palabraCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Outro_95palabraCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_verde"), gdjs.Outro_95palabraCode.GDflor_95verdeObjects1);
{for(var i = 0, len = gdjs.Outro_95palabraCode.GDflor_95verdeObjects1.length ;i < len;++i) {
    gdjs.Outro_95palabraCode.GDflor_95verdeObjects1[i].setAnimationName("atrapada");
}
}{for(var i = 0, len = gdjs.Outro_95palabraCode.GDflor_95verdeObjects1.length ;i < len;++i) {
    gdjs.Outro_95palabraCode.GDflor_95verdeObjects1[i].flipX(true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\gran-juego.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("denuevo"), gdjs.Outro_95palabraCode.GDdenuevoObjects1);

gdjs.Outro_95palabraCode.condition0IsTrue_0.val = false;
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDdenuevoObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95palabraCode.condition0IsTrue_0.val ) {
{
{gdjs.Outro_95palabraCode.conditionTrue_1 = gdjs.Outro_95palabraCode.condition1IsTrue_0;
gdjs.Outro_95palabraCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35448980);
}
}}
if (gdjs.Outro_95palabraCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Outro_95palabraCode.GDdenuevoObjects1 */
{for(var i = 0, len = gdjs.Outro_95palabraCode.GDdenuevoObjects1.length ;i < len;++i) {
    gdjs.Outro_95palabraCode.GDdenuevoObjects1[i].setAnimationName("hover");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\juguemos-otra-vez.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("denuevo"), gdjs.Outro_95palabraCode.GDdenuevoObjects1);

gdjs.Outro_95palabraCode.condition0IsTrue_0.val = false;
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDdenuevoObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95palabraCode.condition0IsTrue_0.val ) {
{
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Outro_95palabraCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "palabra_correcta1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("denuevo"), gdjs.Outro_95palabraCode.GDdenuevoObjects1);

gdjs.Outro_95palabraCode.condition0IsTrue_0.val = false;
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDdenuevoObjects1Objects, runtimeScene, true, true);
}if ( gdjs.Outro_95palabraCode.condition0IsTrue_0.val ) {
{
{gdjs.Outro_95palabraCode.conditionTrue_1 = gdjs.Outro_95palabraCode.condition1IsTrue_0;
gdjs.Outro_95palabraCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35451124);
}
}}
if (gdjs.Outro_95palabraCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Outro_95palabraCode.GDdenuevoObjects1 */
{for(var i = 0, len = gdjs.Outro_95palabraCode.GDdenuevoObjects1.length ;i < len;++i) {
    gdjs.Outro_95palabraCode.GDdenuevoObjects1[i].setAnimationName("normal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("salir"), gdjs.Outro_95palabraCode.GDsalirObjects1);

gdjs.Outro_95palabraCode.condition0IsTrue_0.val = false;
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDsalirObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95palabraCode.condition0IsTrue_0.val ) {
{
{gdjs.Outro_95palabraCode.conditionTrue_1 = gdjs.Outro_95palabraCode.condition1IsTrue_0;
gdjs.Outro_95palabraCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35451932);
}
}}
if (gdjs.Outro_95palabraCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\-busquemos otro juego.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("salir"), gdjs.Outro_95palabraCode.GDsalirObjects1);

gdjs.Outro_95palabraCode.condition0IsTrue_0.val = false;
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95palabraCode.mapOfGDgdjs_46Outro_9595palabraCode_46GDsalirObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95palabraCode.condition0IsTrue_0.val ) {
{
gdjs.Outro_95palabraCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Outro_95palabraCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_semantica", false);
}}

}


{


{
}

}


{


{
}

}


};

gdjs.Outro_95palabraCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Outro_95palabraCode.GDpersonajeObjects1.length = 0;
gdjs.Outro_95palabraCode.GDpersonajeObjects2.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95R1Objects1.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95R1Objects2.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95K2Objects1.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95K2Objects2.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95K1Objects1.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95K1Objects2.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95R2Objects1.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95R2Objects2.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95S1Objects1.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95S1Objects2.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95S2Objects1.length = 0;
gdjs.Outro_95palabraCode.GDCarta_95S2Objects2.length = 0;
gdjs.Outro_95palabraCode.GDpersonajeDObjects1.length = 0;
gdjs.Outro_95palabraCode.GDpersonajeDObjects2.length = 0;
gdjs.Outro_95palabraCode.GDabeja1Objects1.length = 0;
gdjs.Outro_95palabraCode.GDabeja1Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor1Objects1.length = 0;
gdjs.Outro_95palabraCode.GDflor1Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor_95moradaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDflor_95moradaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDflor2Objects1.length = 0;
gdjs.Outro_95palabraCode.GDflor2Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor_95rosaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDflor_95rosaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDflor3Objects1.length = 0;
gdjs.Outro_95palabraCode.GDflor3Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor_95naranjaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDflor_95naranjaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDflor4Objects1.length = 0;
gdjs.Outro_95palabraCode.GDflor4Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor_95rosadaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDflor_95rosadaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDflor5Objects1.length = 0;
gdjs.Outro_95palabraCode.GDflor5Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor_95amarillaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDflor_95amarillaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDflor6Objects1.length = 0;
gdjs.Outro_95palabraCode.GDflor6Objects2.length = 0;
gdjs.Outro_95palabraCode.GDflor_95verdeObjects1.length = 0;
gdjs.Outro_95palabraCode.GDflor_95verdeObjects2.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95arribaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95arribaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95abajoObjects1.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95abajoObjects2.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95izquierdaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95izquierdaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95derechaObjects1.length = 0;
gdjs.Outro_95palabraCode.GDmuro_95derechaObjects2.length = 0;
gdjs.Outro_95palabraCode.GDcreador1Objects1.length = 0;
gdjs.Outro_95palabraCode.GDcreador1Objects2.length = 0;
gdjs.Outro_95palabraCode.GDcreador2Objects1.length = 0;
gdjs.Outro_95palabraCode.GDcreador2Objects2.length = 0;
gdjs.Outro_95palabraCode.GDcreador3Objects1.length = 0;
gdjs.Outro_95palabraCode.GDcreador3Objects2.length = 0;
gdjs.Outro_95palabraCode.GDcreador4Objects1.length = 0;
gdjs.Outro_95palabraCode.GDcreador4Objects2.length = 0;
gdjs.Outro_95palabraCode.GDbloque2Objects1.length = 0;
gdjs.Outro_95palabraCode.GDbloque2Objects2.length = 0;
gdjs.Outro_95palabraCode.GDbloque3Objects1.length = 0;
gdjs.Outro_95palabraCode.GDbloque3Objects2.length = 0;
gdjs.Outro_95palabraCode.GDfondoObjects1.length = 0;
gdjs.Outro_95palabraCode.GDfondoObjects2.length = 0;
gdjs.Outro_95palabraCode.GDNivelObjects1.length = 0;
gdjs.Outro_95palabraCode.GDNivelObjects2.length = 0;
gdjs.Outro_95palabraCode.GDContadorObjects1.length = 0;
gdjs.Outro_95palabraCode.GDContadorObjects2.length = 0;
gdjs.Outro_95palabraCode.GDposicionObjects1.length = 0;
gdjs.Outro_95palabraCode.GDposicionObjects2.length = 0;
gdjs.Outro_95palabraCode.GDparticulasObjects1.length = 0;
gdjs.Outro_95palabraCode.GDparticulasObjects2.length = 0;
gdjs.Outro_95palabraCode.GDnivelObjects1.length = 0;
gdjs.Outro_95palabraCode.GDnivelObjects2.length = 0;
gdjs.Outro_95palabraCode.GDregresarObjects1.length = 0;
gdjs.Outro_95palabraCode.GDregresarObjects2.length = 0;
gdjs.Outro_95palabraCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Outro_95palabraCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Outro_95palabraCode.GDNewTextObjects1.length = 0;
gdjs.Outro_95palabraCode.GDNewTextObjects2.length = 0;
gdjs.Outro_95palabraCode.GDINDICACIONESObjects1.length = 0;
gdjs.Outro_95palabraCode.GDINDICACIONESObjects2.length = 0;
gdjs.Outro_95palabraCode.GDtituloObjects1.length = 0;
gdjs.Outro_95palabraCode.GDtituloObjects2.length = 0;
gdjs.Outro_95palabraCode.GDdenuevoObjects1.length = 0;
gdjs.Outro_95palabraCode.GDdenuevoObjects2.length = 0;
gdjs.Outro_95palabraCode.GDsalirObjects1.length = 0;
gdjs.Outro_95palabraCode.GDsalirObjects2.length = 0;

gdjs.Outro_95palabraCode.eventsList0(runtimeScene);

return;

}

gdjs['Outro_95palabraCode'] = gdjs.Outro_95palabraCode;
