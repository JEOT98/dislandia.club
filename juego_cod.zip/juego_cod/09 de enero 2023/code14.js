gdjs.Intro_95palabraCode = {};
gdjs.Intro_95palabraCode.GDpersonajeObjects1= [];
gdjs.Intro_95palabraCode.GDpersonajeObjects2= [];
gdjs.Intro_95palabraCode.GDCarta_95R1Objects1= [];
gdjs.Intro_95palabraCode.GDCarta_95R1Objects2= [];
gdjs.Intro_95palabraCode.GDCarta_95K2Objects1= [];
gdjs.Intro_95palabraCode.GDCarta_95K2Objects2= [];
gdjs.Intro_95palabraCode.GDCarta_95K1Objects1= [];
gdjs.Intro_95palabraCode.GDCarta_95K1Objects2= [];
gdjs.Intro_95palabraCode.GDCarta_95R2Objects1= [];
gdjs.Intro_95palabraCode.GDCarta_95R2Objects2= [];
gdjs.Intro_95palabraCode.GDCarta_95S1Objects1= [];
gdjs.Intro_95palabraCode.GDCarta_95S1Objects2= [];
gdjs.Intro_95palabraCode.GDCarta_95S2Objects1= [];
gdjs.Intro_95palabraCode.GDCarta_95S2Objects2= [];
gdjs.Intro_95palabraCode.GDpersonajeDObjects1= [];
gdjs.Intro_95palabraCode.GDpersonajeDObjects2= [];
gdjs.Intro_95palabraCode.GDabeja1Objects1= [];
gdjs.Intro_95palabraCode.GDabeja1Objects2= [];
gdjs.Intro_95palabraCode.GDflor1Objects1= [];
gdjs.Intro_95palabraCode.GDflor1Objects2= [];
gdjs.Intro_95palabraCode.GDflor_95moradaObjects1= [];
gdjs.Intro_95palabraCode.GDflor_95moradaObjects2= [];
gdjs.Intro_95palabraCode.GDflor2Objects1= [];
gdjs.Intro_95palabraCode.GDflor2Objects2= [];
gdjs.Intro_95palabraCode.GDflor_95rosaObjects1= [];
gdjs.Intro_95palabraCode.GDflor_95rosaObjects2= [];
gdjs.Intro_95palabraCode.GDflor3Objects1= [];
gdjs.Intro_95palabraCode.GDflor3Objects2= [];
gdjs.Intro_95palabraCode.GDflor_95naranjaObjects1= [];
gdjs.Intro_95palabraCode.GDflor_95naranjaObjects2= [];
gdjs.Intro_95palabraCode.GDflor4Objects1= [];
gdjs.Intro_95palabraCode.GDflor4Objects2= [];
gdjs.Intro_95palabraCode.GDflor_95rosadaObjects1= [];
gdjs.Intro_95palabraCode.GDflor_95rosadaObjects2= [];
gdjs.Intro_95palabraCode.GDflor5Objects1= [];
gdjs.Intro_95palabraCode.GDflor5Objects2= [];
gdjs.Intro_95palabraCode.GDflor_95amarillaObjects1= [];
gdjs.Intro_95palabraCode.GDflor_95amarillaObjects2= [];
gdjs.Intro_95palabraCode.GDflor6Objects1= [];
gdjs.Intro_95palabraCode.GDflor6Objects2= [];
gdjs.Intro_95palabraCode.GDflor_95verdeObjects1= [];
gdjs.Intro_95palabraCode.GDflor_95verdeObjects2= [];
gdjs.Intro_95palabraCode.GDmuro_95arribaObjects1= [];
gdjs.Intro_95palabraCode.GDmuro_95arribaObjects2= [];
gdjs.Intro_95palabraCode.GDmuro_95abajoObjects1= [];
gdjs.Intro_95palabraCode.GDmuro_95abajoObjects2= [];
gdjs.Intro_95palabraCode.GDmuro_95izquierdaObjects1= [];
gdjs.Intro_95palabraCode.GDmuro_95izquierdaObjects2= [];
gdjs.Intro_95palabraCode.GDmuro_95derechaObjects1= [];
gdjs.Intro_95palabraCode.GDmuro_95derechaObjects2= [];
gdjs.Intro_95palabraCode.GDcreador1Objects1= [];
gdjs.Intro_95palabraCode.GDcreador1Objects2= [];
gdjs.Intro_95palabraCode.GDcreador2Objects1= [];
gdjs.Intro_95palabraCode.GDcreador2Objects2= [];
gdjs.Intro_95palabraCode.GDcreador3Objects1= [];
gdjs.Intro_95palabraCode.GDcreador3Objects2= [];
gdjs.Intro_95palabraCode.GDcreador4Objects1= [];
gdjs.Intro_95palabraCode.GDcreador4Objects2= [];
gdjs.Intro_95palabraCode.GDbloque2Objects1= [];
gdjs.Intro_95palabraCode.GDbloque2Objects2= [];
gdjs.Intro_95palabraCode.GDbloque3Objects1= [];
gdjs.Intro_95palabraCode.GDbloque3Objects2= [];
gdjs.Intro_95palabraCode.GDfondoObjects1= [];
gdjs.Intro_95palabraCode.GDfondoObjects2= [];
gdjs.Intro_95palabraCode.GDNivelObjects1= [];
gdjs.Intro_95palabraCode.GDNivelObjects2= [];
gdjs.Intro_95palabraCode.GDContadorObjects1= [];
gdjs.Intro_95palabraCode.GDContadorObjects2= [];
gdjs.Intro_95palabraCode.GDposicionObjects1= [];
gdjs.Intro_95palabraCode.GDposicionObjects2= [];
gdjs.Intro_95palabraCode.GDparticulasObjects1= [];
gdjs.Intro_95palabraCode.GDparticulasObjects2= [];
gdjs.Intro_95palabraCode.GDnivelObjects1= [];
gdjs.Intro_95palabraCode.GDnivelObjects2= [];
gdjs.Intro_95palabraCode.GDregresarObjects1= [];
gdjs.Intro_95palabraCode.GDregresarObjects2= [];
gdjs.Intro_95palabraCode.GDNewParticlesEmitterObjects1= [];
gdjs.Intro_95palabraCode.GDNewParticlesEmitterObjects2= [];
gdjs.Intro_95palabraCode.GDNewTextObjects1= [];
gdjs.Intro_95palabraCode.GDNewTextObjects2= [];
gdjs.Intro_95palabraCode.GDINDICACIONESObjects1= [];
gdjs.Intro_95palabraCode.GDINDICACIONESObjects2= [];
gdjs.Intro_95palabraCode.GDtituloObjects1= [];
gdjs.Intro_95palabraCode.GDtituloObjects2= [];

gdjs.Intro_95palabraCode.conditionTrue_0 = {val:false};
gdjs.Intro_95palabraCode.condition0IsTrue_0 = {val:false};
gdjs.Intro_95palabraCode.condition1IsTrue_0 = {val:false};


gdjs.Intro_95palabraCode.eventsList0 = function(runtimeScene) {

{


gdjs.Intro_95palabraCode.condition0IsTrue_0.val = false;
{
gdjs.Intro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Intro_95palabraCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_morada"), gdjs.Intro_95palabraCode.GDflor_95moradaObjects1);
{for(var i = 0, len = gdjs.Intro_95palabraCode.GDflor_95moradaObjects1.length ;i < len;++i) {
    gdjs.Intro_95palabraCode.GDflor_95moradaObjects1[i].setAnimationName("atrapada");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\Para jugar a la palabra correcta tienes .wav", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "nivel1");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "animación");
}}

}


{


gdjs.Intro_95palabraCode.condition0IsTrue_0.val = false;
{
gdjs.Intro_95palabraCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "nivel1") >= 16;
}if (gdjs.Intro_95palabraCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "palabra_correcta1", false);
}}

}


};

gdjs.Intro_95palabraCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Intro_95palabraCode.GDpersonajeObjects1.length = 0;
gdjs.Intro_95palabraCode.GDpersonajeObjects2.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95R1Objects1.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95R1Objects2.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95K2Objects1.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95K2Objects2.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95K1Objects1.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95K1Objects2.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95R2Objects1.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95R2Objects2.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95S1Objects1.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95S1Objects2.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95S2Objects1.length = 0;
gdjs.Intro_95palabraCode.GDCarta_95S2Objects2.length = 0;
gdjs.Intro_95palabraCode.GDpersonajeDObjects1.length = 0;
gdjs.Intro_95palabraCode.GDpersonajeDObjects2.length = 0;
gdjs.Intro_95palabraCode.GDabeja1Objects1.length = 0;
gdjs.Intro_95palabraCode.GDabeja1Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor1Objects1.length = 0;
gdjs.Intro_95palabraCode.GDflor1Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor_95moradaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDflor_95moradaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDflor2Objects1.length = 0;
gdjs.Intro_95palabraCode.GDflor2Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor_95rosaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDflor_95rosaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDflor3Objects1.length = 0;
gdjs.Intro_95palabraCode.GDflor3Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor_95naranjaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDflor_95naranjaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDflor4Objects1.length = 0;
gdjs.Intro_95palabraCode.GDflor4Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor_95rosadaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDflor_95rosadaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDflor5Objects1.length = 0;
gdjs.Intro_95palabraCode.GDflor5Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor_95amarillaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDflor_95amarillaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDflor6Objects1.length = 0;
gdjs.Intro_95palabraCode.GDflor6Objects2.length = 0;
gdjs.Intro_95palabraCode.GDflor_95verdeObjects1.length = 0;
gdjs.Intro_95palabraCode.GDflor_95verdeObjects2.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95arribaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95arribaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95abajoObjects1.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95abajoObjects2.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95izquierdaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95izquierdaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95derechaObjects1.length = 0;
gdjs.Intro_95palabraCode.GDmuro_95derechaObjects2.length = 0;
gdjs.Intro_95palabraCode.GDcreador1Objects1.length = 0;
gdjs.Intro_95palabraCode.GDcreador1Objects2.length = 0;
gdjs.Intro_95palabraCode.GDcreador2Objects1.length = 0;
gdjs.Intro_95palabraCode.GDcreador2Objects2.length = 0;
gdjs.Intro_95palabraCode.GDcreador3Objects1.length = 0;
gdjs.Intro_95palabraCode.GDcreador3Objects2.length = 0;
gdjs.Intro_95palabraCode.GDcreador4Objects1.length = 0;
gdjs.Intro_95palabraCode.GDcreador4Objects2.length = 0;
gdjs.Intro_95palabraCode.GDbloque2Objects1.length = 0;
gdjs.Intro_95palabraCode.GDbloque2Objects2.length = 0;
gdjs.Intro_95palabraCode.GDbloque3Objects1.length = 0;
gdjs.Intro_95palabraCode.GDbloque3Objects2.length = 0;
gdjs.Intro_95palabraCode.GDfondoObjects1.length = 0;
gdjs.Intro_95palabraCode.GDfondoObjects2.length = 0;
gdjs.Intro_95palabraCode.GDNivelObjects1.length = 0;
gdjs.Intro_95palabraCode.GDNivelObjects2.length = 0;
gdjs.Intro_95palabraCode.GDContadorObjects1.length = 0;
gdjs.Intro_95palabraCode.GDContadorObjects2.length = 0;
gdjs.Intro_95palabraCode.GDposicionObjects1.length = 0;
gdjs.Intro_95palabraCode.GDposicionObjects2.length = 0;
gdjs.Intro_95palabraCode.GDparticulasObjects1.length = 0;
gdjs.Intro_95palabraCode.GDparticulasObjects2.length = 0;
gdjs.Intro_95palabraCode.GDnivelObjects1.length = 0;
gdjs.Intro_95palabraCode.GDnivelObjects2.length = 0;
gdjs.Intro_95palabraCode.GDregresarObjects1.length = 0;
gdjs.Intro_95palabraCode.GDregresarObjects2.length = 0;
gdjs.Intro_95palabraCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Intro_95palabraCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Intro_95palabraCode.GDNewTextObjects1.length = 0;
gdjs.Intro_95palabraCode.GDNewTextObjects2.length = 0;
gdjs.Intro_95palabraCode.GDINDICACIONESObjects1.length = 0;
gdjs.Intro_95palabraCode.GDINDICACIONESObjects2.length = 0;
gdjs.Intro_95palabraCode.GDtituloObjects1.length = 0;
gdjs.Intro_95palabraCode.GDtituloObjects2.length = 0;

gdjs.Intro_95palabraCode.eventsList0(runtimeScene);

return;

}

gdjs['Intro_95palabraCode'] = gdjs.Intro_95palabraCode;
