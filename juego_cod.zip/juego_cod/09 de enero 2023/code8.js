gdjs.Intro_95serCode = {};
gdjs.Intro_95serCode.GDpersonajeObjects1= [];
gdjs.Intro_95serCode.GDpersonajeObjects2= [];
gdjs.Intro_95serCode.GDCarta_95R1Objects1= [];
gdjs.Intro_95serCode.GDCarta_95R1Objects2= [];
gdjs.Intro_95serCode.GDCarta_95K2Objects1= [];
gdjs.Intro_95serCode.GDCarta_95K2Objects2= [];
gdjs.Intro_95serCode.GDCarta_95K1Objects1= [];
gdjs.Intro_95serCode.GDCarta_95K1Objects2= [];
gdjs.Intro_95serCode.GDCarta_95R2Objects1= [];
gdjs.Intro_95serCode.GDCarta_95R2Objects2= [];
gdjs.Intro_95serCode.GDCarta_95S1Objects1= [];
gdjs.Intro_95serCode.GDCarta_95S1Objects2= [];
gdjs.Intro_95serCode.GDCarta_95S2Objects1= [];
gdjs.Intro_95serCode.GDCarta_95S2Objects2= [];
gdjs.Intro_95serCode.GDpersonajeDObjects1= [];
gdjs.Intro_95serCode.GDpersonajeDObjects2= [];
gdjs.Intro_95serCode.GDabeja1Objects1= [];
gdjs.Intro_95serCode.GDabeja1Objects2= [];
gdjs.Intro_95serCode.GDflor1Objects1= [];
gdjs.Intro_95serCode.GDflor1Objects2= [];
gdjs.Intro_95serCode.GDflor_95moradaObjects1= [];
gdjs.Intro_95serCode.GDflor_95moradaObjects2= [];
gdjs.Intro_95serCode.GDflor2Objects1= [];
gdjs.Intro_95serCode.GDflor2Objects2= [];
gdjs.Intro_95serCode.GDflor_95rosaObjects1= [];
gdjs.Intro_95serCode.GDflor_95rosaObjects2= [];
gdjs.Intro_95serCode.GDflor3Objects1= [];
gdjs.Intro_95serCode.GDflor3Objects2= [];
gdjs.Intro_95serCode.GDflor_95naranjaObjects1= [];
gdjs.Intro_95serCode.GDflor_95naranjaObjects2= [];
gdjs.Intro_95serCode.GDflor4Objects1= [];
gdjs.Intro_95serCode.GDflor4Objects2= [];
gdjs.Intro_95serCode.GDflor_95rosadaObjects1= [];
gdjs.Intro_95serCode.GDflor_95rosadaObjects2= [];
gdjs.Intro_95serCode.GDflor5Objects1= [];
gdjs.Intro_95serCode.GDflor5Objects2= [];
gdjs.Intro_95serCode.GDflor_95amarillaObjects1= [];
gdjs.Intro_95serCode.GDflor_95amarillaObjects2= [];
gdjs.Intro_95serCode.GDflor6Objects1= [];
gdjs.Intro_95serCode.GDflor6Objects2= [];
gdjs.Intro_95serCode.GDflor_95verdeObjects1= [];
gdjs.Intro_95serCode.GDflor_95verdeObjects2= [];
gdjs.Intro_95serCode.GDmuro_95arribaObjects1= [];
gdjs.Intro_95serCode.GDmuro_95arribaObjects2= [];
gdjs.Intro_95serCode.GDmuro_95abajoObjects1= [];
gdjs.Intro_95serCode.GDmuro_95abajoObjects2= [];
gdjs.Intro_95serCode.GDmuro_95izquierdaObjects1= [];
gdjs.Intro_95serCode.GDmuro_95izquierdaObjects2= [];
gdjs.Intro_95serCode.GDmuro_95derechaObjects1= [];
gdjs.Intro_95serCode.GDmuro_95derechaObjects2= [];
gdjs.Intro_95serCode.GDcreador1Objects1= [];
gdjs.Intro_95serCode.GDcreador1Objects2= [];
gdjs.Intro_95serCode.GDcreador2Objects1= [];
gdjs.Intro_95serCode.GDcreador2Objects2= [];
gdjs.Intro_95serCode.GDcreador3Objects1= [];
gdjs.Intro_95serCode.GDcreador3Objects2= [];
gdjs.Intro_95serCode.GDcreador4Objects1= [];
gdjs.Intro_95serCode.GDcreador4Objects2= [];
gdjs.Intro_95serCode.GDbloque2Objects1= [];
gdjs.Intro_95serCode.GDbloque2Objects2= [];
gdjs.Intro_95serCode.GDbloque3Objects1= [];
gdjs.Intro_95serCode.GDbloque3Objects2= [];
gdjs.Intro_95serCode.GDfondoObjects1= [];
gdjs.Intro_95serCode.GDfondoObjects2= [];
gdjs.Intro_95serCode.GDNivelObjects1= [];
gdjs.Intro_95serCode.GDNivelObjects2= [];
gdjs.Intro_95serCode.GDContadorObjects1= [];
gdjs.Intro_95serCode.GDContadorObjects2= [];
gdjs.Intro_95serCode.GDposicionObjects1= [];
gdjs.Intro_95serCode.GDposicionObjects2= [];
gdjs.Intro_95serCode.GDparticulasObjects1= [];
gdjs.Intro_95serCode.GDparticulasObjects2= [];
gdjs.Intro_95serCode.GDnivelObjects1= [];
gdjs.Intro_95serCode.GDnivelObjects2= [];
gdjs.Intro_95serCode.GDregresarObjects1= [];
gdjs.Intro_95serCode.GDregresarObjects2= [];
gdjs.Intro_95serCode.GDNewParticlesEmitterObjects1= [];
gdjs.Intro_95serCode.GDNewParticlesEmitterObjects2= [];
gdjs.Intro_95serCode.GDNewTextObjects1= [];
gdjs.Intro_95serCode.GDNewTextObjects2= [];
gdjs.Intro_95serCode.GDINDICACIONESObjects1= [];
gdjs.Intro_95serCode.GDINDICACIONESObjects2= [];
gdjs.Intro_95serCode.GDtituloObjects1= [];
gdjs.Intro_95serCode.GDtituloObjects2= [];

gdjs.Intro_95serCode.conditionTrue_0 = {val:false};
gdjs.Intro_95serCode.condition0IsTrue_0 = {val:false};
gdjs.Intro_95serCode.condition1IsTrue_0 = {val:false};


gdjs.Intro_95serCode.eventsList0 = function(runtimeScene) {

{


gdjs.Intro_95serCode.condition0IsTrue_0.val = false;
{
gdjs.Intro_95serCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Intro_95serCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_morada"), gdjs.Intro_95serCode.GDflor_95moradaObjects1);
{for(var i = 0, len = gdjs.Intro_95serCode.GDflor_95moradaObjects1.length ;i < len;++i) {
    gdjs.Intro_95serCode.GDflor_95moradaObjects1[i].setAnimationName("atrapada");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\yo_quiero_ser\\Sonidos\\Para jugar a yo quiero ser tienes que Se.wav", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "nivel1");
}}

}


{


gdjs.Intro_95serCode.condition0IsTrue_0.val = false;
{
gdjs.Intro_95serCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "nivel1") >= 11;
}if (gdjs.Intro_95serCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "ser_nivel1", false);
}}

}


};

gdjs.Intro_95serCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Intro_95serCode.GDpersonajeObjects1.length = 0;
gdjs.Intro_95serCode.GDpersonajeObjects2.length = 0;
gdjs.Intro_95serCode.GDCarta_95R1Objects1.length = 0;
gdjs.Intro_95serCode.GDCarta_95R1Objects2.length = 0;
gdjs.Intro_95serCode.GDCarta_95K2Objects1.length = 0;
gdjs.Intro_95serCode.GDCarta_95K2Objects2.length = 0;
gdjs.Intro_95serCode.GDCarta_95K1Objects1.length = 0;
gdjs.Intro_95serCode.GDCarta_95K1Objects2.length = 0;
gdjs.Intro_95serCode.GDCarta_95R2Objects1.length = 0;
gdjs.Intro_95serCode.GDCarta_95R2Objects2.length = 0;
gdjs.Intro_95serCode.GDCarta_95S1Objects1.length = 0;
gdjs.Intro_95serCode.GDCarta_95S1Objects2.length = 0;
gdjs.Intro_95serCode.GDCarta_95S2Objects1.length = 0;
gdjs.Intro_95serCode.GDCarta_95S2Objects2.length = 0;
gdjs.Intro_95serCode.GDpersonajeDObjects1.length = 0;
gdjs.Intro_95serCode.GDpersonajeDObjects2.length = 0;
gdjs.Intro_95serCode.GDabeja1Objects1.length = 0;
gdjs.Intro_95serCode.GDabeja1Objects2.length = 0;
gdjs.Intro_95serCode.GDflor1Objects1.length = 0;
gdjs.Intro_95serCode.GDflor1Objects2.length = 0;
gdjs.Intro_95serCode.GDflor_95moradaObjects1.length = 0;
gdjs.Intro_95serCode.GDflor_95moradaObjects2.length = 0;
gdjs.Intro_95serCode.GDflor2Objects1.length = 0;
gdjs.Intro_95serCode.GDflor2Objects2.length = 0;
gdjs.Intro_95serCode.GDflor_95rosaObjects1.length = 0;
gdjs.Intro_95serCode.GDflor_95rosaObjects2.length = 0;
gdjs.Intro_95serCode.GDflor3Objects1.length = 0;
gdjs.Intro_95serCode.GDflor3Objects2.length = 0;
gdjs.Intro_95serCode.GDflor_95naranjaObjects1.length = 0;
gdjs.Intro_95serCode.GDflor_95naranjaObjects2.length = 0;
gdjs.Intro_95serCode.GDflor4Objects1.length = 0;
gdjs.Intro_95serCode.GDflor4Objects2.length = 0;
gdjs.Intro_95serCode.GDflor_95rosadaObjects1.length = 0;
gdjs.Intro_95serCode.GDflor_95rosadaObjects2.length = 0;
gdjs.Intro_95serCode.GDflor5Objects1.length = 0;
gdjs.Intro_95serCode.GDflor5Objects2.length = 0;
gdjs.Intro_95serCode.GDflor_95amarillaObjects1.length = 0;
gdjs.Intro_95serCode.GDflor_95amarillaObjects2.length = 0;
gdjs.Intro_95serCode.GDflor6Objects1.length = 0;
gdjs.Intro_95serCode.GDflor6Objects2.length = 0;
gdjs.Intro_95serCode.GDflor_95verdeObjects1.length = 0;
gdjs.Intro_95serCode.GDflor_95verdeObjects2.length = 0;
gdjs.Intro_95serCode.GDmuro_95arribaObjects1.length = 0;
gdjs.Intro_95serCode.GDmuro_95arribaObjects2.length = 0;
gdjs.Intro_95serCode.GDmuro_95abajoObjects1.length = 0;
gdjs.Intro_95serCode.GDmuro_95abajoObjects2.length = 0;
gdjs.Intro_95serCode.GDmuro_95izquierdaObjects1.length = 0;
gdjs.Intro_95serCode.GDmuro_95izquierdaObjects2.length = 0;
gdjs.Intro_95serCode.GDmuro_95derechaObjects1.length = 0;
gdjs.Intro_95serCode.GDmuro_95derechaObjects2.length = 0;
gdjs.Intro_95serCode.GDcreador1Objects1.length = 0;
gdjs.Intro_95serCode.GDcreador1Objects2.length = 0;
gdjs.Intro_95serCode.GDcreador2Objects1.length = 0;
gdjs.Intro_95serCode.GDcreador2Objects2.length = 0;
gdjs.Intro_95serCode.GDcreador3Objects1.length = 0;
gdjs.Intro_95serCode.GDcreador3Objects2.length = 0;
gdjs.Intro_95serCode.GDcreador4Objects1.length = 0;
gdjs.Intro_95serCode.GDcreador4Objects2.length = 0;
gdjs.Intro_95serCode.GDbloque2Objects1.length = 0;
gdjs.Intro_95serCode.GDbloque2Objects2.length = 0;
gdjs.Intro_95serCode.GDbloque3Objects1.length = 0;
gdjs.Intro_95serCode.GDbloque3Objects2.length = 0;
gdjs.Intro_95serCode.GDfondoObjects1.length = 0;
gdjs.Intro_95serCode.GDfondoObjects2.length = 0;
gdjs.Intro_95serCode.GDNivelObjects1.length = 0;
gdjs.Intro_95serCode.GDNivelObjects2.length = 0;
gdjs.Intro_95serCode.GDContadorObjects1.length = 0;
gdjs.Intro_95serCode.GDContadorObjects2.length = 0;
gdjs.Intro_95serCode.GDposicionObjects1.length = 0;
gdjs.Intro_95serCode.GDposicionObjects2.length = 0;
gdjs.Intro_95serCode.GDparticulasObjects1.length = 0;
gdjs.Intro_95serCode.GDparticulasObjects2.length = 0;
gdjs.Intro_95serCode.GDnivelObjects1.length = 0;
gdjs.Intro_95serCode.GDnivelObjects2.length = 0;
gdjs.Intro_95serCode.GDregresarObjects1.length = 0;
gdjs.Intro_95serCode.GDregresarObjects2.length = 0;
gdjs.Intro_95serCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Intro_95serCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Intro_95serCode.GDNewTextObjects1.length = 0;
gdjs.Intro_95serCode.GDNewTextObjects2.length = 0;
gdjs.Intro_95serCode.GDINDICACIONESObjects1.length = 0;
gdjs.Intro_95serCode.GDINDICACIONESObjects2.length = 0;
gdjs.Intro_95serCode.GDtituloObjects1.length = 0;
gdjs.Intro_95serCode.GDtituloObjects2.length = 0;

gdjs.Intro_95serCode.eventsList0(runtimeScene);

return;

}

gdjs['Intro_95serCode'] = gdjs.Intro_95serCode;
