gdjs.abejas_95nivel3Code = {};
gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final = [];

gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final = [];

gdjs.abejas_95nivel3Code.forEachIndex2 = 0;

gdjs.abejas_95nivel3Code.forEachIndex3 = 0;

gdjs.abejas_95nivel3Code.forEachObjects2 = [];

gdjs.abejas_95nivel3Code.forEachObjects3 = [];

gdjs.abejas_95nivel3Code.forEachTemporary2 = null;

gdjs.abejas_95nivel3Code.forEachTemporary3 = null;

gdjs.abejas_95nivel3Code.forEachTotalCount2 = 0;

gdjs.abejas_95nivel3Code.forEachTotalCount3 = 0;

gdjs.abejas_95nivel3Code.GDabeja1Objects1= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects2= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects3= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects4= [];
gdjs.abejas_95nivel3Code.GDabeja1Objects5= [];
gdjs.abejas_95nivel3Code.GDflor1Objects1= [];
gdjs.abejas_95nivel3Code.GDflor1Objects2= [];
gdjs.abejas_95nivel3Code.GDflor1Objects3= [];
gdjs.abejas_95nivel3Code.GDflor1Objects4= [];
gdjs.abejas_95nivel3Code.GDflor1Objects5= [];
gdjs.abejas_95nivel3Code.GDflor2Objects1= [];
gdjs.abejas_95nivel3Code.GDflor2Objects2= [];
gdjs.abejas_95nivel3Code.GDflor2Objects3= [];
gdjs.abejas_95nivel3Code.GDflor2Objects4= [];
gdjs.abejas_95nivel3Code.GDflor2Objects5= [];
gdjs.abejas_95nivel3Code.GDflor3Objects1= [];
gdjs.abejas_95nivel3Code.GDflor3Objects2= [];
gdjs.abejas_95nivel3Code.GDflor3Objects3= [];
gdjs.abejas_95nivel3Code.GDflor3Objects4= [];
gdjs.abejas_95nivel3Code.GDflor3Objects5= [];
gdjs.abejas_95nivel3Code.GDflor4Objects1= [];
gdjs.abejas_95nivel3Code.GDflor4Objects2= [];
gdjs.abejas_95nivel3Code.GDflor4Objects3= [];
gdjs.abejas_95nivel3Code.GDflor4Objects4= [];
gdjs.abejas_95nivel3Code.GDflor4Objects5= [];
gdjs.abejas_95nivel3Code.GDflor5Objects1= [];
gdjs.abejas_95nivel3Code.GDflor5Objects2= [];
gdjs.abejas_95nivel3Code.GDflor5Objects3= [];
gdjs.abejas_95nivel3Code.GDflor5Objects4= [];
gdjs.abejas_95nivel3Code.GDflor5Objects5= [];
gdjs.abejas_95nivel3Code.GDflor6Objects1= [];
gdjs.abejas_95nivel3Code.GDflor6Objects2= [];
gdjs.abejas_95nivel3Code.GDflor6Objects3= [];
gdjs.abejas_95nivel3Code.GDflor6Objects4= [];
gdjs.abejas_95nivel3Code.GDflor6Objects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects5= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects1= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects2= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects3= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects4= [];
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects5= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador1Objects5= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador2Objects5= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador3Objects5= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects1= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects2= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects3= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects4= [];
gdjs.abejas_95nivel3Code.GDcreador4Objects5= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects1= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects2= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects3= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects4= [];
gdjs.abejas_95nivel3Code.GDbloque2Objects5= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects1= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects2= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects3= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects4= [];
gdjs.abejas_95nivel3Code.GDbloque3Objects5= [];
gdjs.abejas_95nivel3Code.GDfondoObjects1= [];
gdjs.abejas_95nivel3Code.GDfondoObjects2= [];
gdjs.abejas_95nivel3Code.GDfondoObjects3= [];
gdjs.abejas_95nivel3Code.GDfondoObjects4= [];
gdjs.abejas_95nivel3Code.GDfondoObjects5= [];
gdjs.abejas_95nivel3Code.GDNivelObjects1= [];
gdjs.abejas_95nivel3Code.GDNivelObjects2= [];
gdjs.abejas_95nivel3Code.GDNivelObjects3= [];
gdjs.abejas_95nivel3Code.GDNivelObjects4= [];
gdjs.abejas_95nivel3Code.GDNivelObjects5= [];
gdjs.abejas_95nivel3Code.GDParejasObjects1= [];
gdjs.abejas_95nivel3Code.GDParejasObjects2= [];
gdjs.abejas_95nivel3Code.GDParejasObjects3= [];
gdjs.abejas_95nivel3Code.GDParejasObjects4= [];
gdjs.abejas_95nivel3Code.GDParejasObjects5= [];
gdjs.abejas_95nivel3Code.GDposicionObjects1= [];
gdjs.abejas_95nivel3Code.GDposicionObjects2= [];
gdjs.abejas_95nivel3Code.GDposicionObjects3= [];
gdjs.abejas_95nivel3Code.GDposicionObjects4= [];
gdjs.abejas_95nivel3Code.GDposicionObjects5= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects1= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects2= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects3= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects4= [];
gdjs.abejas_95nivel3Code.GDparticulasObjects5= [];
gdjs.abejas_95nivel3Code.GDnivelObjects1= [];
gdjs.abejas_95nivel3Code.GDnivelObjects2= [];
gdjs.abejas_95nivel3Code.GDnivelObjects3= [];
gdjs.abejas_95nivel3Code.GDnivelObjects4= [];
gdjs.abejas_95nivel3Code.GDnivelObjects5= [];
gdjs.abejas_95nivel3Code.GDregresarObjects1= [];
gdjs.abejas_95nivel3Code.GDregresarObjects2= [];
gdjs.abejas_95nivel3Code.GDregresarObjects3= [];
gdjs.abejas_95nivel3Code.GDregresarObjects4= [];
gdjs.abejas_95nivel3Code.GDregresarObjects5= [];

gdjs.abejas_95nivel3Code.conditionTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition0IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition1IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition2IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.condition3IsTrue_0 = {val:false};
gdjs.abejas_95nivel3Code.conditionTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition0IsTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition1IsTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition2IsTrue_1 = {val:false};
gdjs.abejas_95nivel3Code.condition3IsTrue_1 = {val:false};


gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects4Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects4});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador1Objects4Objects = Hashtable.newFrom({"creador1": gdjs.abejas_95nivel3Code.GDcreador1Objects4});
gdjs.abejas_95nivel3Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects4);

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDcreador1Objects3, gdjs.abejas_95nivel3Code.GDcreador1Objects4);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects4Objects, "Physics2", gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador1Objects4Objects, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects4 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getAngle()), 700, 0, 0);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects3});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador2Objects3Objects = Hashtable.newFrom({"creador2": gdjs.abejas_95nivel3Code.GDcreador2Objects3});
gdjs.abejas_95nivel3Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDcreador2Objects2, gdjs.abejas_95nivel3Code.GDcreador2Objects3);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, "Physics2", gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDcreador2Objects3Objects, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects3 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getAngle()), 700, 0, 0);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("creador1"), gdjs.abejas_95nivel3Code.GDcreador1Objects2);

for(gdjs.abejas_95nivel3Code.forEachIndex3 = 0;gdjs.abejas_95nivel3Code.forEachIndex3 < gdjs.abejas_95nivel3Code.GDcreador1Objects2.length;++gdjs.abejas_95nivel3Code.forEachIndex3) {
gdjs.abejas_95nivel3Code.GDabeja1Objects3.length = 0;

gdjs.abejas_95nivel3Code.GDcreador1Objects3.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary3 = gdjs.abejas_95nivel3Code.GDcreador1Objects2[gdjs.abejas_95nivel3Code.forEachIndex3];
gdjs.abejas_95nivel3Code.GDcreador1Objects3.push(gdjs.abejas_95nivel3Code.forEachTemporary3);
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects3Objects, (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects3.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects3[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setSize(233, 192);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getAngle()), 700, 0, 0);
}
}
{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("creador2"), gdjs.abejas_95nivel3Code.GDcreador2Objects1);

for(gdjs.abejas_95nivel3Code.forEachIndex2 = 0;gdjs.abejas_95nivel3Code.forEachIndex2 < gdjs.abejas_95nivel3Code.GDcreador2Objects1.length;++gdjs.abejas_95nivel3Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("creador1"), gdjs.abejas_95nivel3Code.GDcreador1Objects2);
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;

gdjs.abejas_95nivel3Code.GDcreador2Objects2.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary2 = gdjs.abejas_95nivel3Code.GDcreador2Objects1[gdjs.abejas_95nivel3Code.forEachIndex2];
gdjs.abejas_95nivel3Code.GDcreador2Objects2.push(gdjs.abejas_95nivel3Code.forEachTemporary2);
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, (( gdjs.abejas_95nivel3Code.GDcreador2Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador2Objects2[0].getCenterXInScene()), (( gdjs.abejas_95nivel3Code.GDcreador1Objects2.length === 0 ) ? 0 :gdjs.abejas_95nivel3Code.GDcreador1Objects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].setSize(233, 192);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].rotateTowardAngle(gdjs.randomFloatInRange(0, 360), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects2.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].getBehavior("Physics2").applyPolarForce((gdjs.abejas_95nivel3Code.GDabeja1Objects2[i].getAngle()), 500, 0, 0);
}
}
{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList1(runtimeScene);} //Subevents end.
}
}

}


};gdjs.abejas_95nivel3Code.eventsList3 = function(runtimeScene) {

{


{
}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects2});
gdjs.abejas_95nivel3Code.eventsList4 = function(runtimeScene) {

{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition1IsTrue_0;
gdjs.abejas_95nivel3Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20111724);
}
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);

{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setAnimationName("click");
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].activateBehavior("Arrastrable", true);
}
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor1Objects1Objects = Hashtable.newFrom({"flor1": gdjs.abejas_95nivel3Code.GDflor1Objects1});
gdjs.abejas_95nivel3Code.eventsList5 = function(runtimeScene) {

{


{
}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects = Hashtable.newFrom({"abeja1": gdjs.abejas_95nivel3Code.GDabeja1Objects1});
gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDfondoObjects1Objects = Hashtable.newFrom({"fondo": gdjs.abejas_95nivel3Code.GDfondoObjects1});
gdjs.abejas_95nivel3Code.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.abejas_95nivel3Code.GDParejasObjects1);
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDParejasObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDParejasObjects1[i].setString("Abejas atrapadas: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.abejas_95nivel3Code.GDParejasObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDParejasObjects1.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDParejasObjects1[i].getString() == "Parejas: 6" ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = true;
        gdjs.abejas_95nivel3Code.GDParejasObjects1[k] = gdjs.abejas_95nivel3Code.GDParejasObjects1[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDParejasObjects1.length = k;}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "p_final", false);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.abejas_95nivel3Code.GDregresarObjects1});
gdjs.abejas_95nivel3Code.eventsList8 = function(runtimeScene) {

{


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_pronunciacion", false);
}}

}


};gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.abejas_95nivel3Code.GDregresarObjects1});
gdjs.abejas_95nivel3Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects4);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition0IsTrue_0;
gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.length = 0;gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects5);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects5[i].getCenterXInScene() < -(1920) ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects5[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects5[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects5.length = k;if( gdjs.abejas_95nivel3Code.condition0IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3, gdjs.abejas_95nivel3Code.GDabeja1Objects5);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects5[i].getCenterXInScene() > 1920 ) {
        gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects5[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects5[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects5.length = k;if( gdjs.abejas_95nivel3Code.condition1IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects5.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects4_1final, gdjs.abejas_95nivel3Code.GDabeja1Objects4);
}
}
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects4 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].setX(((gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getPointX("")) * -(0.55)));
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects3);


gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
{gdjs.abejas_95nivel3Code.conditionTrue_1 = gdjs.abejas_95nivel3Code.condition0IsTrue_0;
gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.length = 0;gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects4);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getCenterYInScene() < -(1080) ) {
        gdjs.abejas_95nivel3Code.condition0IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects4[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects4[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects4.length = k;if( gdjs.abejas_95nivel3Code.condition0IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects2, gdjs.abejas_95nivel3Code.GDabeja1Objects4);

for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects4[i].getCenterYInScene() > 1080 ) {
        gdjs.abejas_95nivel3Code.condition1IsTrue_1.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects4[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects4[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects4.length = k;if( gdjs.abejas_95nivel3Code.condition1IsTrue_1.val ) {
    gdjs.abejas_95nivel3Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.abejas_95nivel3Code.GDabeja1Objects4.length;j<jLen;++j) {
        if ( gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.indexOf(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]) === -1 )
            gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final.push(gdjs.abejas_95nivel3Code.GDabeja1Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.abejas_95nivel3Code.GDabeja1Objects3_1final, gdjs.abejas_95nivel3Code.GDabeja1Objects3);
}
}
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects3 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects3.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].setY(((gdjs.abejas_95nivel3Code.GDabeja1Objects3[i].getPointY("")) * -(0.50)));
}
}}

}


};gdjs.abejas_95nivel3Code.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects2);

for(gdjs.abejas_95nivel3Code.forEachIndex3 = 0;gdjs.abejas_95nivel3Code.forEachIndex3 < gdjs.abejas_95nivel3Code.GDabeja1Objects2.length;++gdjs.abejas_95nivel3Code.forEachIndex3) {
gdjs.abejas_95nivel3Code.GDabeja1Objects3.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary3 = gdjs.abejas_95nivel3Code.GDabeja1Objects2[gdjs.abejas_95nivel3Code.forEachIndex3];
gdjs.abejas_95nivel3Code.GDabeja1Objects3.push(gdjs.abejas_95nivel3Code.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);

for(gdjs.abejas_95nivel3Code.forEachIndex2 = 0;gdjs.abejas_95nivel3Code.forEachIndex2 < gdjs.abejas_95nivel3Code.GDabeja1Objects1.length;++gdjs.abejas_95nivel3Code.forEachIndex2) {
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary2 = gdjs.abejas_95nivel3Code.GDabeja1Objects1[gdjs.abejas_95nivel3Code.forEachIndex2];
gdjs.abejas_95nivel3Code.GDabeja1Objects2.push(gdjs.abejas_95nivel3Code.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.abejas_95nivel3Code.eventsList12 = function(runtimeScene) {

{


gdjs.abejas_95nivel3Code.eventsList2(runtimeScene);
}


{


gdjs.abejas_95nivel3Code.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);

for(gdjs.abejas_95nivel3Code.forEachIndex2 = 0;gdjs.abejas_95nivel3Code.forEachIndex2 < gdjs.abejas_95nivel3Code.GDabeja1Objects1.length;++gdjs.abejas_95nivel3Code.forEachIndex2) {
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;


gdjs.abejas_95nivel3Code.forEachTemporary2 = gdjs.abejas_95nivel3Code.GDabeja1Objects1[gdjs.abejas_95nivel3Code.forEachIndex2];
gdjs.abejas_95nivel3Code.GDabeja1Objects2.push(gdjs.abejas_95nivel3Code.forEachTemporary2);
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects2Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.abejas_95nivel3Code.eventsList4(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
gdjs.copyArray(runtimeScene.getObjects("flor1"), gdjs.abejas_95nivel3Code.GDflor1Objects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition2IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDflor1Objects1Objects, runtimeScene, true, false);
}if ( gdjs.abejas_95nivel3Code.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length;i<l;++i) {
    if ( gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].hasNoForces() ) {
        gdjs.abejas_95nivel3Code.condition2IsTrue_0.val = true;
        gdjs.abejas_95nivel3Code.GDabeja1Objects1[k] = gdjs.abejas_95nivel3Code.GDabeja1Objects1[i];
        ++k;
    }
}
gdjs.abejas_95nivel3Code.GDabeja1Objects1.length = k;}}
}
if (gdjs.abejas_95nivel3Code.condition2IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
/* Reuse gdjs.abejas_95nivel3Code.GDflor1Objects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].activateBehavior("Arrastrable", false);
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDflor1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDflor1Objects1[i].setAnimationName("abeja");
}
}{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].setAnimationName("atrapada");
}
}
{ //Subevents
gdjs.abejas_95nivel3Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("abeja1"), gdjs.abejas_95nivel3Code.GDabeja1Objects1);
gdjs.copyArray(runtimeScene.getObjects("fondo"), gdjs.abejas_95nivel3Code.GDfondoObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDabeja1Objects1Objects, runtimeScene, true, false);
}if ( gdjs.abejas_95nivel3Code.condition0IsTrue_0.val ) {
{
gdjs.abejas_95nivel3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDfondoObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.abejas_95nivel3Code.condition1IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDabeja1Objects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDabeja1Objects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDabeja1Objects1[i].setAnimationName("vuelo");
}
}}

}


{


gdjs.abejas_95nivel3Code.eventsList6(runtimeScene);
}


{


gdjs.abejas_95nivel3Code.eventsList7(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.abejas_95nivel3Code.GDregresarObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects, runtimeScene, true, false);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDregresarObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.abejas_95nivel3Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.abejas_95nivel3Code.GDregresarObjects1);

gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = false;
{
gdjs.abejas_95nivel3Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.abejas_95nivel3Code.mapOfGDgdjs_46abejas_9595nivel3Code_46GDregresarObjects1Objects, runtimeScene, true, true);
}if (gdjs.abejas_95nivel3Code.condition0IsTrue_0.val) {
/* Reuse gdjs.abejas_95nivel3Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.abejas_95nivel3Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.abejas_95nivel3Code.GDregresarObjects1[i].setAnimationName("normal");
}
}}

}


{


gdjs.abejas_95nivel3Code.eventsList11(runtimeScene);
}


{


{
}

}


{


{
}

}


};

gdjs.abejas_95nivel3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.abejas_95nivel3Code.GDabeja1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDabeja1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor3Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor4Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor5Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDflor6Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95arribaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95abajoObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95izquierdaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDmuro_95derechaObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador1Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador3Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDcreador4Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDbloque2Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects1.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects2.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects3.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects4.length = 0;
gdjs.abejas_95nivel3Code.GDbloque3Objects5.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDfondoObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDNivelObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDParejasObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDParejasObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDParejasObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDParejasObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDParejasObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDposicionObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDparticulasObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDnivelObjects5.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects1.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects2.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects3.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects4.length = 0;
gdjs.abejas_95nivel3Code.GDregresarObjects5.length = 0;

gdjs.abejas_95nivel3Code.eventsList12(runtimeScene);

return;

}

gdjs['abejas_95nivel3Code'] = gdjs.abejas_95nivel3Code;
