gdjs.Outro_95memoriaCode = {};
gdjs.Outro_95memoriaCode.GDpersonajeObjects1= [];
gdjs.Outro_95memoriaCode.GDpersonajeObjects2= [];
gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1= [];
gdjs.Outro_95memoriaCode.GDCarta_95R1Objects2= [];
gdjs.Outro_95memoriaCode.GDCarta_95K2Objects1= [];
gdjs.Outro_95memoriaCode.GDCarta_95K2Objects2= [];
gdjs.Outro_95memoriaCode.GDCarta_95K1Objects1= [];
gdjs.Outro_95memoriaCode.GDCarta_95K1Objects2= [];
gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1= [];
gdjs.Outro_95memoriaCode.GDCarta_95R2Objects2= [];
gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1= [];
gdjs.Outro_95memoriaCode.GDCarta_95S1Objects2= [];
gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1= [];
gdjs.Outro_95memoriaCode.GDCarta_95S2Objects2= [];
gdjs.Outro_95memoriaCode.GDpersonajeDObjects1= [];
gdjs.Outro_95memoriaCode.GDpersonajeDObjects2= [];
gdjs.Outro_95memoriaCode.GDabeja1Objects1= [];
gdjs.Outro_95memoriaCode.GDabeja1Objects2= [];
gdjs.Outro_95memoriaCode.GDflor1Objects1= [];
gdjs.Outro_95memoriaCode.GDflor1Objects2= [];
gdjs.Outro_95memoriaCode.GDflor_95moradaObjects1= [];
gdjs.Outro_95memoriaCode.GDflor_95moradaObjects2= [];
gdjs.Outro_95memoriaCode.GDflor2Objects1= [];
gdjs.Outro_95memoriaCode.GDflor2Objects2= [];
gdjs.Outro_95memoriaCode.GDflor_95rosaObjects1= [];
gdjs.Outro_95memoriaCode.GDflor_95rosaObjects2= [];
gdjs.Outro_95memoriaCode.GDflor3Objects1= [];
gdjs.Outro_95memoriaCode.GDflor3Objects2= [];
gdjs.Outro_95memoriaCode.GDflor_95naranjaObjects1= [];
gdjs.Outro_95memoriaCode.GDflor_95naranjaObjects2= [];
gdjs.Outro_95memoriaCode.GDflor4Objects1= [];
gdjs.Outro_95memoriaCode.GDflor4Objects2= [];
gdjs.Outro_95memoriaCode.GDflor_95rosadaObjects1= [];
gdjs.Outro_95memoriaCode.GDflor_95rosadaObjects2= [];
gdjs.Outro_95memoriaCode.GDflor5Objects1= [];
gdjs.Outro_95memoriaCode.GDflor5Objects2= [];
gdjs.Outro_95memoriaCode.GDflor_95amarillaObjects1= [];
gdjs.Outro_95memoriaCode.GDflor_95amarillaObjects2= [];
gdjs.Outro_95memoriaCode.GDflor6Objects1= [];
gdjs.Outro_95memoriaCode.GDflor6Objects2= [];
gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1= [];
gdjs.Outro_95memoriaCode.GDflor_95verdeObjects2= [];
gdjs.Outro_95memoriaCode.GDmuro_95arribaObjects1= [];
gdjs.Outro_95memoriaCode.GDmuro_95arribaObjects2= [];
gdjs.Outro_95memoriaCode.GDmuro_95abajoObjects1= [];
gdjs.Outro_95memoriaCode.GDmuro_95abajoObjects2= [];
gdjs.Outro_95memoriaCode.GDmuro_95izquierdaObjects1= [];
gdjs.Outro_95memoriaCode.GDmuro_95izquierdaObjects2= [];
gdjs.Outro_95memoriaCode.GDmuro_95derechaObjects1= [];
gdjs.Outro_95memoriaCode.GDmuro_95derechaObjects2= [];
gdjs.Outro_95memoriaCode.GDcreador1Objects1= [];
gdjs.Outro_95memoriaCode.GDcreador1Objects2= [];
gdjs.Outro_95memoriaCode.GDcreador2Objects1= [];
gdjs.Outro_95memoriaCode.GDcreador2Objects2= [];
gdjs.Outro_95memoriaCode.GDcreador3Objects1= [];
gdjs.Outro_95memoriaCode.GDcreador3Objects2= [];
gdjs.Outro_95memoriaCode.GDcreador4Objects1= [];
gdjs.Outro_95memoriaCode.GDcreador4Objects2= [];
gdjs.Outro_95memoriaCode.GDbloque2Objects1= [];
gdjs.Outro_95memoriaCode.GDbloque2Objects2= [];
gdjs.Outro_95memoriaCode.GDbloque3Objects1= [];
gdjs.Outro_95memoriaCode.GDbloque3Objects2= [];
gdjs.Outro_95memoriaCode.GDfondoObjects1= [];
gdjs.Outro_95memoriaCode.GDfondoObjects2= [];
gdjs.Outro_95memoriaCode.GDNivelObjects1= [];
gdjs.Outro_95memoriaCode.GDNivelObjects2= [];
gdjs.Outro_95memoriaCode.GDContadorObjects1= [];
gdjs.Outro_95memoriaCode.GDContadorObjects2= [];
gdjs.Outro_95memoriaCode.GDposicionObjects1= [];
gdjs.Outro_95memoriaCode.GDposicionObjects2= [];
gdjs.Outro_95memoriaCode.GDparticulasObjects1= [];
gdjs.Outro_95memoriaCode.GDparticulasObjects2= [];
gdjs.Outro_95memoriaCode.GDnivelObjects1= [];
gdjs.Outro_95memoriaCode.GDnivelObjects2= [];
gdjs.Outro_95memoriaCode.GDregresarObjects1= [];
gdjs.Outro_95memoriaCode.GDregresarObjects2= [];
gdjs.Outro_95memoriaCode.GDNewParticlesEmitterObjects1= [];
gdjs.Outro_95memoriaCode.GDNewParticlesEmitterObjects2= [];
gdjs.Outro_95memoriaCode.GDNewTextObjects1= [];
gdjs.Outro_95memoriaCode.GDNewTextObjects2= [];
gdjs.Outro_95memoriaCode.GDINDICACIONESObjects1= [];
gdjs.Outro_95memoriaCode.GDINDICACIONESObjects2= [];
gdjs.Outro_95memoriaCode.GDtituloObjects1= [];
gdjs.Outro_95memoriaCode.GDtituloObjects2= [];
gdjs.Outro_95memoriaCode.GDdenuevoObjects1= [];
gdjs.Outro_95memoriaCode.GDdenuevoObjects2= [];
gdjs.Outro_95memoriaCode.GDsalirObjects1= [];
gdjs.Outro_95memoriaCode.GDsalirObjects2= [];

gdjs.Outro_95memoriaCode.conditionTrue_0 = {val:false};
gdjs.Outro_95memoriaCode.condition0IsTrue_0 = {val:false};
gdjs.Outro_95memoriaCode.condition1IsTrue_0 = {val:false};
gdjs.Outro_95memoriaCode.condition2IsTrue_0 = {val:false};
gdjs.Outro_95memoriaCode.conditionTrue_1 = {val:false};
gdjs.Outro_95memoriaCode.condition0IsTrue_1 = {val:false};
gdjs.Outro_95memoriaCode.condition1IsTrue_1 = {val:false};
gdjs.Outro_95memoriaCode.condition2IsTrue_1 = {val:false};


gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDdenuevoObjects1Objects = Hashtable.newFrom({"denuevo": gdjs.Outro_95memoriaCode.GDdenuevoObjects1});
gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDdenuevoObjects1Objects = Hashtable.newFrom({"denuevo": gdjs.Outro_95memoriaCode.GDdenuevoObjects1});
gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDdenuevoObjects1Objects = Hashtable.newFrom({"denuevo": gdjs.Outro_95memoriaCode.GDdenuevoObjects1});
gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDsalirObjects1Objects = Hashtable.newFrom({"salir": gdjs.Outro_95memoriaCode.GDsalirObjects1});
gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDsalirObjects1Objects = Hashtable.newFrom({"salir": gdjs.Outro_95memoriaCode.GDsalirObjects1});
gdjs.Outro_95memoriaCode.eventsList0 = function(runtimeScene) {

{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("flor_verde"), gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1[i].setAnimationName("atrapada");
}
}{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1[i].flipX(true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\gran-juego.wav", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "animación");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("denuevo"), gdjs.Outro_95memoriaCode.GDdenuevoObjects1);

gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDdenuevoObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Outro_95memoriaCode.conditionTrue_1 = gdjs.Outro_95memoriaCode.condition1IsTrue_0;
gdjs.Outro_95memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(36118876);
}
}}
if (gdjs.Outro_95memoriaCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Outro_95memoriaCode.GDdenuevoObjects1 */
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDdenuevoObjects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDdenuevoObjects1[i].setAnimationName("hover");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\juguemos-otra-vez.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("denuevo"), gdjs.Outro_95memoriaCode.GDdenuevoObjects1);

gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDdenuevoObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95memoriaCode.condition0IsTrue_0.val ) {
{
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Outro_95memoriaCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "nivel 1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("denuevo"), gdjs.Outro_95memoriaCode.GDdenuevoObjects1);

gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDdenuevoObjects1Objects, runtimeScene, true, true);
}if ( gdjs.Outro_95memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Outro_95memoriaCode.conditionTrue_1 = gdjs.Outro_95memoriaCode.condition1IsTrue_0;
gdjs.Outro_95memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(36120780);
}
}}
if (gdjs.Outro_95memoriaCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Outro_95memoriaCode.GDdenuevoObjects1 */
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDdenuevoObjects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDdenuevoObjects1[i].setAnimationName("normal");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("salir"), gdjs.Outro_95memoriaCode.GDsalirObjects1);

gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDsalirObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95memoriaCode.condition0IsTrue_0.val ) {
{
{gdjs.Outro_95memoriaCode.conditionTrue_1 = gdjs.Outro_95memoriaCode.condition1IsTrue_0;
gdjs.Outro_95memoriaCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(36121812);
}
}}
if (gdjs.Outro_95memoriaCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\pronunciacion\\cazador_abejas\\sonidos\\-busquemos otro juego.wav", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("salir"), gdjs.Outro_95memoriaCode.GDsalirObjects1);

gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Outro_95memoriaCode.mapOfGDgdjs_46Outro_9595memoriaCode_46GDsalirObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Outro_95memoriaCode.condition0IsTrue_0.val ) {
{
gdjs.Outro_95memoriaCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.Outro_95memoriaCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_semantica", false);
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 1;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 9;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 2;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 3;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 4;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 5;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 6;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 7;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 8;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 10;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 11;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = false;
{
gdjs.Outro_95memoriaCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 12;
}if (gdjs.Outro_95memoriaCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1);
{for(var i = 0, len = gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1[i].setAnimationName("front");
}
}}

}


{


{
}

}


{


{
}

}


};

gdjs.Outro_95memoriaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Outro_95memoriaCode.GDpersonajeObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDpersonajeObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95R1Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95R1Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95K2Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95K2Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95K1Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95K1Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95R2Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95R2Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95S1Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95S1Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95S2Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDCarta_95S2Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDpersonajeDObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDpersonajeDObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDabeja1Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDabeja1Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor1Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor1Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95moradaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95moradaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor2Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor2Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95rosaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95rosaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor3Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor3Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95naranjaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95naranjaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor4Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor4Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95rosadaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95rosadaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor5Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor5Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95amarillaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95amarillaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor6Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor6Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95verdeObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDflor_95verdeObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95arribaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95arribaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95abajoObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95abajoObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95izquierdaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95izquierdaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95derechaObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDmuro_95derechaObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDcreador1Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDcreador1Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDcreador2Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDcreador2Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDcreador3Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDcreador3Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDcreador4Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDcreador4Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDbloque2Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDbloque2Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDbloque3Objects1.length = 0;
gdjs.Outro_95memoriaCode.GDbloque3Objects2.length = 0;
gdjs.Outro_95memoriaCode.GDfondoObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDfondoObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDNivelObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDNivelObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDContadorObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDContadorObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDposicionObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDposicionObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDparticulasObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDparticulasObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDnivelObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDnivelObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDregresarObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDregresarObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDNewTextObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDNewTextObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDINDICACIONESObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDINDICACIONESObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDtituloObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDtituloObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDdenuevoObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDdenuevoObjects2.length = 0;
gdjs.Outro_95memoriaCode.GDsalirObjects1.length = 0;
gdjs.Outro_95memoriaCode.GDsalirObjects2.length = 0;

gdjs.Outro_95memoriaCode.eventsList0(runtimeScene);

return;

}

gdjs['Outro_95memoriaCode'] = gdjs.Outro_95memoriaCode;
