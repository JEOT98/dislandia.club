gdjs.Intro_95memoria2Code = {};
gdjs.Intro_95memoria2Code.GDpersonajeObjects1= [];
gdjs.Intro_95memoria2Code.GDpersonajeObjects2= [];
gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1= [];
gdjs.Intro_95memoria2Code.GDCarta_95R1Objects2= [];
gdjs.Intro_95memoria2Code.GDCarta_95K2Objects1= [];
gdjs.Intro_95memoria2Code.GDCarta_95K2Objects2= [];
gdjs.Intro_95memoria2Code.GDCarta_95K1Objects1= [];
gdjs.Intro_95memoria2Code.GDCarta_95K1Objects2= [];
gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1= [];
gdjs.Intro_95memoria2Code.GDCarta_95R2Objects2= [];
gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1= [];
gdjs.Intro_95memoria2Code.GDCarta_95S1Objects2= [];
gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1= [];
gdjs.Intro_95memoria2Code.GDCarta_95S2Objects2= [];
gdjs.Intro_95memoria2Code.GDpersonajeDObjects1= [];
gdjs.Intro_95memoria2Code.GDpersonajeDObjects2= [];
gdjs.Intro_95memoria2Code.GDabeja1Objects1= [];
gdjs.Intro_95memoria2Code.GDabeja1Objects2= [];
gdjs.Intro_95memoria2Code.GDflor1Objects1= [];
gdjs.Intro_95memoria2Code.GDflor1Objects2= [];
gdjs.Intro_95memoria2Code.GDflor_95moradaObjects1= [];
gdjs.Intro_95memoria2Code.GDflor_95moradaObjects2= [];
gdjs.Intro_95memoria2Code.GDflor2Objects1= [];
gdjs.Intro_95memoria2Code.GDflor2Objects2= [];
gdjs.Intro_95memoria2Code.GDflor_95rosaObjects1= [];
gdjs.Intro_95memoria2Code.GDflor_95rosaObjects2= [];
gdjs.Intro_95memoria2Code.GDflor3Objects1= [];
gdjs.Intro_95memoria2Code.GDflor3Objects2= [];
gdjs.Intro_95memoria2Code.GDflor_95naranjaObjects1= [];
gdjs.Intro_95memoria2Code.GDflor_95naranjaObjects2= [];
gdjs.Intro_95memoria2Code.GDflor4Objects1= [];
gdjs.Intro_95memoria2Code.GDflor4Objects2= [];
gdjs.Intro_95memoria2Code.GDflor_95rosadaObjects1= [];
gdjs.Intro_95memoria2Code.GDflor_95rosadaObjects2= [];
gdjs.Intro_95memoria2Code.GDflor5Objects1= [];
gdjs.Intro_95memoria2Code.GDflor5Objects2= [];
gdjs.Intro_95memoria2Code.GDflor_95amarillaObjects1= [];
gdjs.Intro_95memoria2Code.GDflor_95amarillaObjects2= [];
gdjs.Intro_95memoria2Code.GDflor6Objects1= [];
gdjs.Intro_95memoria2Code.GDflor6Objects2= [];
gdjs.Intro_95memoria2Code.GDflor_95verdeObjects1= [];
gdjs.Intro_95memoria2Code.GDflor_95verdeObjects2= [];
gdjs.Intro_95memoria2Code.GDmuro_95arribaObjects1= [];
gdjs.Intro_95memoria2Code.GDmuro_95arribaObjects2= [];
gdjs.Intro_95memoria2Code.GDmuro_95abajoObjects1= [];
gdjs.Intro_95memoria2Code.GDmuro_95abajoObjects2= [];
gdjs.Intro_95memoria2Code.GDmuro_95izquierdaObjects1= [];
gdjs.Intro_95memoria2Code.GDmuro_95izquierdaObjects2= [];
gdjs.Intro_95memoria2Code.GDmuro_95derechaObjects1= [];
gdjs.Intro_95memoria2Code.GDmuro_95derechaObjects2= [];
gdjs.Intro_95memoria2Code.GDcreador1Objects1= [];
gdjs.Intro_95memoria2Code.GDcreador1Objects2= [];
gdjs.Intro_95memoria2Code.GDcreador2Objects1= [];
gdjs.Intro_95memoria2Code.GDcreador2Objects2= [];
gdjs.Intro_95memoria2Code.GDcreador3Objects1= [];
gdjs.Intro_95memoria2Code.GDcreador3Objects2= [];
gdjs.Intro_95memoria2Code.GDcreador4Objects1= [];
gdjs.Intro_95memoria2Code.GDcreador4Objects2= [];
gdjs.Intro_95memoria2Code.GDbloque2Objects1= [];
gdjs.Intro_95memoria2Code.GDbloque2Objects2= [];
gdjs.Intro_95memoria2Code.GDbloque3Objects1= [];
gdjs.Intro_95memoria2Code.GDbloque3Objects2= [];
gdjs.Intro_95memoria2Code.GDfondoObjects1= [];
gdjs.Intro_95memoria2Code.GDfondoObjects2= [];
gdjs.Intro_95memoria2Code.GDNivelObjects1= [];
gdjs.Intro_95memoria2Code.GDNivelObjects2= [];
gdjs.Intro_95memoria2Code.GDContadorObjects1= [];
gdjs.Intro_95memoria2Code.GDContadorObjects2= [];
gdjs.Intro_95memoria2Code.GDposicionObjects1= [];
gdjs.Intro_95memoria2Code.GDposicionObjects2= [];
gdjs.Intro_95memoria2Code.GDparticulasObjects1= [];
gdjs.Intro_95memoria2Code.GDparticulasObjects2= [];
gdjs.Intro_95memoria2Code.GDnivelObjects1= [];
gdjs.Intro_95memoria2Code.GDnivelObjects2= [];
gdjs.Intro_95memoria2Code.GDregresarObjects1= [];
gdjs.Intro_95memoria2Code.GDregresarObjects2= [];
gdjs.Intro_95memoria2Code.GDNewParticlesEmitterObjects1= [];
gdjs.Intro_95memoria2Code.GDNewParticlesEmitterObjects2= [];
gdjs.Intro_95memoria2Code.GDNewTextObjects1= [];
gdjs.Intro_95memoria2Code.GDNewTextObjects2= [];
gdjs.Intro_95memoria2Code.GDINDICACIONESObjects1= [];
gdjs.Intro_95memoria2Code.GDINDICACIONESObjects2= [];
gdjs.Intro_95memoria2Code.GDtituloObjects1= [];
gdjs.Intro_95memoria2Code.GDtituloObjects2= [];

gdjs.Intro_95memoria2Code.conditionTrue_0 = {val:false};
gdjs.Intro_95memoria2Code.condition0IsTrue_0 = {val:false};
gdjs.Intro_95memoria2Code.condition1IsTrue_0 = {val:false};


gdjs.Intro_95memoria2Code.eventsList0 = function(runtimeScene) {

{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1);
gdjs.copyArray(runtimeScene.getObjects("flor_morada"), gdjs.Intro_95memoria2Code.GDflor_95moradaObjects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDflor_95moradaObjects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDflor_95moradaObjects1[i].setAnimationName("atrapada");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\busquemos_los_pares\\sonidos\\Para jugar al juego de memoria tienes qu.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "nivel1");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "animación");
}{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 1;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 2;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 3;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 4;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 5;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 6;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 7;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 8;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1[i].setAnimationName("back");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 9;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R1"), gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 10;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_R2"), gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 11;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S1"), gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "animación") >= 12;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Carta_S2"), gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1);
{for(var i = 0, len = gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1.length ;i < len;++i) {
    gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1[i].setAnimationName("front");
}
}}

}


{


gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = false;
{
gdjs.Intro_95memoria2Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "nivel1") >= 13;
}if (gdjs.Intro_95memoria2Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "nivel 1", false);
}}

}


};

gdjs.Intro_95memoria2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Intro_95memoria2Code.GDpersonajeObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDpersonajeObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95R1Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95R1Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95K2Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95K2Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95K1Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95K1Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95R2Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95R2Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95S1Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95S1Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95S2Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDCarta_95S2Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDpersonajeDObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDpersonajeDObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDabeja1Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDabeja1Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor1Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor1Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95moradaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95moradaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor2Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor2Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95rosaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95rosaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor3Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor3Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95naranjaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95naranjaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor4Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor4Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95rosadaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95rosadaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor5Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor5Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95amarillaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95amarillaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor6Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor6Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95verdeObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDflor_95verdeObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95arribaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95arribaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95abajoObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95abajoObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95izquierdaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95izquierdaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95derechaObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDmuro_95derechaObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDcreador1Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDcreador1Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDcreador2Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDcreador2Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDcreador3Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDcreador3Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDcreador4Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDcreador4Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDbloque2Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDbloque2Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDbloque3Objects1.length = 0;
gdjs.Intro_95memoria2Code.GDbloque3Objects2.length = 0;
gdjs.Intro_95memoria2Code.GDfondoObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDfondoObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDNivelObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDNivelObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDContadorObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDContadorObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDposicionObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDposicionObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDparticulasObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDparticulasObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDnivelObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDnivelObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDregresarObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDregresarObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDNewTextObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDNewTextObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDINDICACIONESObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDINDICACIONESObjects2.length = 0;
gdjs.Intro_95memoria2Code.GDtituloObjects1.length = 0;
gdjs.Intro_95memoria2Code.GDtituloObjects2.length = 0;

gdjs.Intro_95memoria2Code.eventsList0(runtimeScene);

return;

}

gdjs['Intro_95memoria2Code'] = gdjs.Intro_95memoria2Code;
