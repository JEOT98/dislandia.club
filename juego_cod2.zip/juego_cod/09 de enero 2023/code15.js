gdjs.palabra_95correcta1Code = {};
gdjs.palabra_95correcta1Code.forEachIndex2 = 0;

gdjs.palabra_95correcta1Code.forEachObjects2 = [];

gdjs.palabra_95correcta1Code.forEachTemporary2 = null;

gdjs.palabra_95correcta1Code.forEachTotalCount2 = 0;

gdjs.palabra_95correcta1Code.GDpersonajeObjects1= [];
gdjs.palabra_95correcta1Code.GDpersonajeObjects2= [];
gdjs.palabra_95correcta1Code.GDpersonajeObjects3= [];
gdjs.palabra_95correcta1Code.GDpersonajeObjects4= [];
gdjs.palabra_95correcta1Code.GDpersonajeObjects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects5= [];
gdjs.palabra_95correcta1Code.GDpersonajeDObjects1= [];
gdjs.palabra_95correcta1Code.GDpersonajeDObjects2= [];
gdjs.palabra_95correcta1Code.GDpersonajeDObjects3= [];
gdjs.palabra_95correcta1Code.GDpersonajeDObjects4= [];
gdjs.palabra_95correcta1Code.GDpersonajeDObjects5= [];
gdjs.palabra_95correcta1Code.GDpersonaje1Objects1= [];
gdjs.palabra_95correcta1Code.GDpersonaje1Objects2= [];
gdjs.palabra_95correcta1Code.GDpersonaje1Objects3= [];
gdjs.palabra_95correcta1Code.GDpersonaje1Objects4= [];
gdjs.palabra_95correcta1Code.GDpersonaje1Objects5= [];
gdjs.palabra_95correcta1Code.GDop1Objects1= [];
gdjs.palabra_95correcta1Code.GDop1Objects2= [];
gdjs.palabra_95correcta1Code.GDop1Objects3= [];
gdjs.palabra_95correcta1Code.GDop1Objects4= [];
gdjs.palabra_95correcta1Code.GDop1Objects5= [];
gdjs.palabra_95correcta1Code.GDop1aObjects1= [];
gdjs.palabra_95correcta1Code.GDop1aObjects2= [];
gdjs.palabra_95correcta1Code.GDop1aObjects3= [];
gdjs.palabra_95correcta1Code.GDop1aObjects4= [];
gdjs.palabra_95correcta1Code.GDop1aObjects5= [];
gdjs.palabra_95correcta1Code.GDop2Objects1= [];
gdjs.palabra_95correcta1Code.GDop2Objects2= [];
gdjs.palabra_95correcta1Code.GDop2Objects3= [];
gdjs.palabra_95correcta1Code.GDop2Objects4= [];
gdjs.palabra_95correcta1Code.GDop2Objects5= [];
gdjs.palabra_95correcta1Code.GDop2aObjects1= [];
gdjs.palabra_95correcta1Code.GDop2aObjects2= [];
gdjs.palabra_95correcta1Code.GDop2aObjects3= [];
gdjs.palabra_95correcta1Code.GDop2aObjects4= [];
gdjs.palabra_95correcta1Code.GDop2aObjects5= [];
gdjs.palabra_95correcta1Code.GDcomprobarObjects1= [];
gdjs.palabra_95correcta1Code.GDcomprobarObjects2= [];
gdjs.palabra_95correcta1Code.GDcomprobarObjects3= [];
gdjs.palabra_95correcta1Code.GDcomprobarObjects4= [];
gdjs.palabra_95correcta1Code.GDcomprobarObjects5= [];
gdjs.palabra_95correcta1Code.GDcomproselectObjects1= [];
gdjs.palabra_95correcta1Code.GDcomproselectObjects2= [];
gdjs.palabra_95correcta1Code.GDcomproselectObjects3= [];
gdjs.palabra_95correcta1Code.GDcomproselectObjects4= [];
gdjs.palabra_95correcta1Code.GDcomproselectObjects5= [];
gdjs.palabra_95correcta1Code.GDcomprobar2Objects1= [];
gdjs.palabra_95correcta1Code.GDcomprobar2Objects2= [];
gdjs.palabra_95correcta1Code.GDcomprobar2Objects3= [];
gdjs.palabra_95correcta1Code.GDcomprobar2Objects4= [];
gdjs.palabra_95correcta1Code.GDcomprobar2Objects5= [];
gdjs.palabra_95correcta1Code.GDcomprobar3Objects1= [];
gdjs.palabra_95correcta1Code.GDcomprobar3Objects2= [];
gdjs.palabra_95correcta1Code.GDcomprobar3Objects3= [];
gdjs.palabra_95correcta1Code.GDcomprobar3Objects4= [];
gdjs.palabra_95correcta1Code.GDcomprobar3Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects5= [];
gdjs.palabra_95correcta1Code.GDpreguntaObjects1= [];
gdjs.palabra_95correcta1Code.GDpreguntaObjects2= [];
gdjs.palabra_95correcta1Code.GDpreguntaObjects3= [];
gdjs.palabra_95correcta1Code.GDpreguntaObjects4= [];
gdjs.palabra_95correcta1Code.GDpreguntaObjects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects5= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects1= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects2= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects3= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects4= [];
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects5= [];
gdjs.palabra_95correcta1Code.GDbloque1Objects1= [];
gdjs.palabra_95correcta1Code.GDbloque1Objects2= [];
gdjs.palabra_95correcta1Code.GDbloque1Objects3= [];
gdjs.palabra_95correcta1Code.GDbloque1Objects4= [];
gdjs.palabra_95correcta1Code.GDbloque1Objects5= [];
gdjs.palabra_95correcta1Code.GDbloque2Objects1= [];
gdjs.palabra_95correcta1Code.GDbloque2Objects2= [];
gdjs.palabra_95correcta1Code.GDbloque2Objects3= [];
gdjs.palabra_95correcta1Code.GDbloque2Objects4= [];
gdjs.palabra_95correcta1Code.GDbloque2Objects5= [];
gdjs.palabra_95correcta1Code.GDbloque3Objects1= [];
gdjs.palabra_95correcta1Code.GDbloque3Objects2= [];
gdjs.palabra_95correcta1Code.GDbloque3Objects3= [];
gdjs.palabra_95correcta1Code.GDbloque3Objects4= [];
gdjs.palabra_95correcta1Code.GDbloque3Objects5= [];
gdjs.palabra_95correcta1Code.GDfondoObjects1= [];
gdjs.palabra_95correcta1Code.GDfondoObjects2= [];
gdjs.palabra_95correcta1Code.GDfondoObjects3= [];
gdjs.palabra_95correcta1Code.GDfondoObjects4= [];
gdjs.palabra_95correcta1Code.GDfondoObjects5= [];
gdjs.palabra_95correcta1Code.GDNivelObjects1= [];
gdjs.palabra_95correcta1Code.GDNivelObjects2= [];
gdjs.palabra_95correcta1Code.GDNivelObjects3= [];
gdjs.palabra_95correcta1Code.GDNivelObjects4= [];
gdjs.palabra_95correcta1Code.GDNivelObjects5= [];
gdjs.palabra_95correcta1Code.GDParejasObjects1= [];
gdjs.palabra_95correcta1Code.GDParejasObjects2= [];
gdjs.palabra_95correcta1Code.GDParejasObjects3= [];
gdjs.palabra_95correcta1Code.GDParejasObjects4= [];
gdjs.palabra_95correcta1Code.GDParejasObjects5= [];
gdjs.palabra_95correcta1Code.GDposicionObjects1= [];
gdjs.palabra_95correcta1Code.GDposicionObjects2= [];
gdjs.palabra_95correcta1Code.GDposicionObjects3= [];
gdjs.palabra_95correcta1Code.GDposicionObjects4= [];
gdjs.palabra_95correcta1Code.GDposicionObjects5= [];
gdjs.palabra_95correcta1Code.GDparticulasObjects1= [];
gdjs.palabra_95correcta1Code.GDparticulasObjects2= [];
gdjs.palabra_95correcta1Code.GDparticulasObjects3= [];
gdjs.palabra_95correcta1Code.GDparticulasObjects4= [];
gdjs.palabra_95correcta1Code.GDparticulasObjects5= [];
gdjs.palabra_95correcta1Code.GDnivelObjects1= [];
gdjs.palabra_95correcta1Code.GDnivelObjects2= [];
gdjs.palabra_95correcta1Code.GDnivelObjects3= [];
gdjs.palabra_95correcta1Code.GDnivelObjects4= [];
gdjs.palabra_95correcta1Code.GDnivelObjects5= [];
gdjs.palabra_95correcta1Code.GDregresarObjects1= [];
gdjs.palabra_95correcta1Code.GDregresarObjects2= [];
gdjs.palabra_95correcta1Code.GDregresarObjects3= [];
gdjs.palabra_95correcta1Code.GDregresarObjects4= [];
gdjs.palabra_95correcta1Code.GDregresarObjects5= [];

gdjs.palabra_95correcta1Code.conditionTrue_0 = {val:false};
gdjs.palabra_95correcta1Code.condition0IsTrue_0 = {val:false};
gdjs.palabra_95correcta1Code.condition1IsTrue_0 = {val:false};
gdjs.palabra_95correcta1Code.condition2IsTrue_0 = {val:false};
gdjs.palabra_95correcta1Code.conditionTrue_1 = {val:false};
gdjs.palabra_95correcta1Code.condition0IsTrue_1 = {val:false};
gdjs.palabra_95correcta1Code.condition1IsTrue_1 = {val:false};
gdjs.palabra_95correcta1Code.condition2IsTrue_1 = {val:false};


gdjs.palabra_95correcta1Code.eventsList0 = function(runtimeScene) {

{


{
}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDbloque1Objects2Objects = Hashtable.newFrom({"bloque1": gdjs.palabra_95correcta1Code.GDbloque1Objects2});
gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDbloque2Objects2Objects = Hashtable.newFrom({"bloque2": gdjs.palabra_95correcta1Code.GDbloque2Objects2});
gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDpersonajeDObjects2Objects = Hashtable.newFrom({"personajeD": gdjs.palabra_95correcta1Code.GDpersonajeDObjects2});
gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDfondoObjects1Objects = Hashtable.newFrom({"fondo": gdjs.palabra_95correcta1Code.GDfondoObjects1});
gdjs.palabra_95correcta1Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("personajeD"), gdjs.palabra_95correcta1Code.GDpersonajeDObjects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.palabra_95correcta1Code.GDpersonajeDObjects2.length;i<l;++i) {
    if ( gdjs.palabra_95correcta1Code.GDpersonajeDObjects2[i].isCurrentAnimationName("normal") ) {
        gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = true;
        gdjs.palabra_95correcta1Code.GDpersonajeDObjects2[k] = gdjs.palabra_95correcta1Code.GDpersonajeDObjects2[i];
        ++k;
    }
}
gdjs.palabra_95correcta1Code.GDpersonajeDObjects2.length = k;}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.palabra_95correcta1Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bloque1"), gdjs.palabra_95correcta1Code.GDbloque1Objects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDbloque1Objects2Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personajeD"), gdjs.palabra_95correcta1Code.GDpersonajeDObjects2);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDpersonajeDObjects2.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDpersonajeDObjects2[i].setAnimationName("opciones");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bloque2"), gdjs.palabra_95correcta1Code.GDbloque2Objects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDbloque2Objects2Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personajeD"), gdjs.palabra_95correcta1Code.GDpersonajeDObjects2);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDpersonajeDObjects2.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDpersonajeDObjects2[i].setAnimationName("comporbar");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("personajeD"), gdjs.palabra_95correcta1Code.GDpersonajeDObjects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDpersonajeDObjects2Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDpersonajeDObjects2 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDpersonajeDObjects2.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDpersonajeDObjects2[i].setAnimationName("personaje");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fondo"), gdjs.palabra_95correcta1Code.GDfondoObjects1);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDfondoObjects1Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("personajeD"), gdjs.palabra_95correcta1Code.GDpersonajeDObjects1);
gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.palabra_95correcta1Code.GDregresarObjects1);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDpersonajeDObjects1.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDpersonajeDObjects1[i].setAnimationName("normal");
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDregresarObjects1[i].setAnimationName("normal");
}
}}

}


};gdjs.palabra_95correcta1Code.eventsList2 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("personajeD"), gdjs.palabra_95correcta1Code.GDpersonajeDObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDpersonajeDObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDpersonajeDObjects3[i].setAnimationName("normal");
}
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\ALTO1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\ALTO2.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\BAÑO1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\BAÑO2.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\DAÑO1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\DAÑO2.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\JUGAR1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\JUGAR2.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\MUY BIEN.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SALTO1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SALTO2.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SUMAR1.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SUMAR2.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\ALTO.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SALTO.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\sumar.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\JUGAR.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\DAÑO.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\BAÑO.wav");
}}

}


{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SUMAR1.wav", false, 100, 1);
}}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop1Objects3ObjectsGDgdjs_46palabra_9595correcta1Code_46GDop2Objects3ObjectsGDgdjs_46palabra_9595correcta1Code_46GDCarta_9595L1Objects3ObjectsGDgdjs_46palabra_9595correcta1Code_46GDCarta_9595L2Objects3Objects = Hashtable.newFrom({"op1": gdjs.palabra_95correcta1Code.GDop1Objects3, "op2": gdjs.palabra_95correcta1Code.GDop2Objects3, "Carta_L1": gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3, "Carta_L2": gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3});
gdjs.palabra_95correcta1Code.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDop1Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDop2Objects3 */

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop1Objects3ObjectsGDgdjs_46palabra_9595correcta1Code_46GDop2Objects3ObjectsGDgdjs_46palabra_9595correcta1Code_46GDCarta_9595L1Objects3ObjectsGDgdjs_46palabra_9595correcta1Code_46GDCarta_9595L2Objects3Objects);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDop1Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDop2Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDposicionObjects3 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDposicionObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDposicionObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.palabra_95correcta1Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Carta_L1"), gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Carta_L2"), gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3);
gdjs.copyArray(runtimeScene.getObjects("op1"), gdjs.palabra_95correcta1Code.GDop1Objects3);
gdjs.copyArray(runtimeScene.getObjects("op2"), gdjs.palabra_95correcta1Code.GDop2Objects3);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.palabra_95correcta1Code.GDop1Objects3.length;i<l;++i) {
    if ( gdjs.palabra_95correcta1Code.GDop1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = true;
        gdjs.palabra_95correcta1Code.GDop1Objects3[k] = gdjs.palabra_95correcta1Code.GDop1Objects3[i];
        ++k;
    }
}
gdjs.palabra_95correcta1Code.GDop1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.palabra_95correcta1Code.GDop2Objects3.length;i<l;++i) {
    if ( gdjs.palabra_95correcta1Code.GDop2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = true;
        gdjs.palabra_95correcta1Code.GDop2Objects3[k] = gdjs.palabra_95correcta1Code.GDop2Objects3[i];
        ++k;
    }
}
gdjs.palabra_95correcta1Code.GDop2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3.length;i<l;++i) {
    if ( gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = true;
        gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3[k] = gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3[i];
        ++k;
    }
}
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3.length;i<l;++i) {
    if ( gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3[i].isCurrentAnimationName("front") ) {
        gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = true;
        gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3[k] = gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3[i];
        ++k;
    }
}
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3.length = k;}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDop1Objects3 */
/* Reuse gdjs.palabra_95correcta1Code.GDop2Objects3 */
gdjs.copyArray(gdjs.palabra_95correcta1Code.GDposicionObjects2, gdjs.palabra_95correcta1Code.GDposicionObjects3);

{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
for(var i = 0, len = gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDposicionObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDposicionObjects3[0].getPointY("")), "easeOutCubic", 1000, false);
}
}
{ //Subevents
gdjs.palabra_95correcta1Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.palabra_95correcta1Code.eventsList5 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.palabra_95correcta1Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("posicion"), gdjs.palabra_95correcta1Code.GDposicionObjects1);

for(gdjs.palabra_95correcta1Code.forEachIndex2 = 0;gdjs.palabra_95correcta1Code.forEachIndex2 < gdjs.palabra_95correcta1Code.GDposicionObjects1.length;++gdjs.palabra_95correcta1Code.forEachIndex2) {
gdjs.palabra_95correcta1Code.GDposicionObjects2.length = 0;


gdjs.palabra_95correcta1Code.forEachTemporary2 = gdjs.palabra_95correcta1Code.GDposicionObjects1[gdjs.palabra_95correcta1Code.forEachIndex2];
gdjs.palabra_95correcta1Code.GDposicionObjects2.push(gdjs.palabra_95correcta1Code.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.palabra_95correcta1Code.eventsList4(runtimeScene);} //Subevents end.
}
}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop1Objects3Objects = Hashtable.newFrom({"op1": gdjs.palabra_95correcta1Code.GDop1Objects3});
gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop1Objects3Objects = Hashtable.newFrom({"op1": gdjs.palabra_95correcta1Code.GDop1Objects3});
gdjs.palabra_95correcta1Code.eventsList6 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("comprobar"), gdjs.palabra_95correcta1Code.GDcomprobarObjects4);
gdjs.copyArray(runtimeScene.getObjects("comprobar2"), gdjs.palabra_95correcta1Code.GDcomprobar2Objects4);
gdjs.copyArray(gdjs.palabra_95correcta1Code.GDop1Objects3, gdjs.palabra_95correcta1Code.GDop1Objects4);

gdjs.copyArray(runtimeScene.getObjects("op1a"), gdjs.palabra_95correcta1Code.GDop1aObjects4);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1aObjects4.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1aObjects4[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.palabra_95correcta1Code.GDop1Objects4.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDop1Objects4[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDop1Objects4.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDop1Objects4[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1aObjects4.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1aObjects4[i].setAnimationName("over");
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomprobar2Objects4.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomprobar2Objects4[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.palabra_95correcta1Code.GDcomprobarObjects4.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobarObjects4[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDcomprobarObjects4.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobarObjects4[0].getPointY("")), "linear", -(1000), false);
}
}}

}


{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
{gdjs.palabra_95correcta1Code.conditionTrue_1 = gdjs.palabra_95correcta1Code.condition0IsTrue_0;
gdjs.palabra_95correcta1Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35164764);
}
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\JUGAR.wav", false, 100, 1);
}}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDcomprobar2Objects3Objects = Hashtable.newFrom({"comprobar2": gdjs.palabra_95correcta1Code.GDcomprobar2Objects3});
gdjs.palabra_95correcta1Code.eventsList7 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
gdjs.palabra_95correcta1Code.condition1IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.palabra_95correcta1Code.condition0IsTrue_0.val ) {
{
{gdjs.palabra_95correcta1Code.conditionTrue_1 = gdjs.palabra_95correcta1Code.condition1IsTrue_0;
gdjs.palabra_95correcta1Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35166620);
}
}}
if (gdjs.palabra_95correcta1Code.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.palabra_95correcta1Code.GDcomprobar2Objects3, gdjs.palabra_95correcta1Code.GDcomprobar2Objects4);

gdjs.copyArray(runtimeScene.getObjects("comproselect"), gdjs.palabra_95correcta1Code.GDcomproselectObjects4);
gdjs.copyArray(runtimeScene.getObjects("op1a"), gdjs.palabra_95correcta1Code.GDop1aObjects4);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomproselectObjects4.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomproselectObjects4[i].getBehavior("Tween").addObjectPositionTween("opcion", (( gdjs.palabra_95correcta1Code.GDcomprobar2Objects4.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobar2Objects4[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDcomprobar2Objects4.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobar2Objects4[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1aObjects4.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1aObjects4[i].setAnimationName("mal");
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomproselectObjects4.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomproselectObjects4[i].setAnimationName("mal");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "pasar");
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\SUMAR2.wav", false, 100, 1);
}}

}


{


{
}

}


};gdjs.palabra_95correcta1Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("op1"), gdjs.palabra_95correcta1Code.GDop1Objects3);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop1Objects3Objects, runtimeScene, true, true);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDop1Objects3 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1Objects3[i].setAnimationName("front");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("op1"), gdjs.palabra_95correcta1Code.GDop1Objects3);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop1Objects3Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDop1Objects3 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop1Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop1Objects3[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.palabra_95correcta1Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("comprobar2"), gdjs.palabra_95correcta1Code.GDcomprobar2Objects3);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDcomprobar2Objects3Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDcomprobar2Objects3 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomprobar2Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomprobar2Objects3[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.palabra_95correcta1Code.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pasar") >= 3;
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "palabra_correcta2", false);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "pasar");
}}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop2Objects2Objects = Hashtable.newFrom({"op2": gdjs.palabra_95correcta1Code.GDop2Objects2});
gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop2Objects2Objects = Hashtable.newFrom({"op2": gdjs.palabra_95correcta1Code.GDop2Objects2});
gdjs.palabra_95correcta1Code.eventsList9 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("comprobar"), gdjs.palabra_95correcta1Code.GDcomprobarObjects3);
gdjs.copyArray(runtimeScene.getObjects("comprobar3"), gdjs.palabra_95correcta1Code.GDcomprobar3Objects3);
gdjs.copyArray(gdjs.palabra_95correcta1Code.GDop2Objects2, gdjs.palabra_95correcta1Code.GDop2Objects3);

gdjs.copyArray(runtimeScene.getObjects("op2a"), gdjs.palabra_95correcta1Code.GDop2aObjects3);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2aObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2aObjects3[i].getBehavior("Tween").addObjectPositionTween("opcion2", (( gdjs.palabra_95correcta1Code.GDop2Objects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDop2Objects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDop2Objects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDop2Objects3[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2aObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2aObjects3[i].setAnimationName("over");
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomprobar3Objects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomprobar3Objects3[i].getBehavior("Tween").addObjectPositionTween("opcion2", (( gdjs.palabra_95correcta1Code.GDcomprobarObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobarObjects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDcomprobarObjects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobarObjects3[0].getPointY("")), "linear", -(1000), false);
}
}}

}


{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
{gdjs.palabra_95correcta1Code.conditionTrue_1 = gdjs.palabra_95correcta1Code.condition0IsTrue_0;
gdjs.palabra_95correcta1Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35170860);
}
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\sumar.wav", false, 100, 1);
}}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDcomprobar3Objects2Objects = Hashtable.newFrom({"comprobar3": gdjs.palabra_95correcta1Code.GDcomprobar3Objects2});
gdjs.palabra_95correcta1Code.eventsList10 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
gdjs.palabra_95correcta1Code.condition1IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.palabra_95correcta1Code.condition0IsTrue_0.val ) {
{
{gdjs.palabra_95correcta1Code.conditionTrue_1 = gdjs.palabra_95correcta1Code.condition1IsTrue_0;
gdjs.palabra_95correcta1Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(35173804);
}
}}
if (gdjs.palabra_95correcta1Code.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.palabra_95correcta1Code.GDcomprobar3Objects2, gdjs.palabra_95correcta1Code.GDcomprobar3Objects3);

gdjs.copyArray(runtimeScene.getObjects("comproselect"), gdjs.palabra_95correcta1Code.GDcomproselectObjects3);
gdjs.copyArray(runtimeScene.getObjects("op2a"), gdjs.palabra_95correcta1Code.GDop2aObjects3);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomproselectObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomproselectObjects3[i].getBehavior("Tween").addObjectPositionTween("opcion2", (( gdjs.palabra_95correcta1Code.GDcomprobar3Objects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobar3Objects3[0].getPointX("")), (( gdjs.palabra_95correcta1Code.GDcomprobar3Objects3.length === 0 ) ? 0 :gdjs.palabra_95correcta1Code.GDcomprobar3Objects3[0].getPointY("")), "linear", -(1000), false);
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2aObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2aObjects3[i].setAnimationName("bien");
}
}{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomproselectObjects3.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomproselectObjects3[i].setAnimationName("bien");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "pasar");
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\semantica\\palabra_correcta\\sonidos\\MUY BIEN.wav", false, 100, 1);
}}

}


{


{
}

}


};gdjs.palabra_95correcta1Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("op2"), gdjs.palabra_95correcta1Code.GDop2Objects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop2Objects2Objects, runtimeScene, true, true);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDop2Objects2 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2Objects2.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2Objects2[i].setAnimationName("front");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("op2"), gdjs.palabra_95correcta1Code.GDop2Objects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDop2Objects2Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDop2Objects2 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDop2Objects2.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDop2Objects2[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.palabra_95correcta1Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("comprobar3"), gdjs.palabra_95correcta1Code.GDcomprobar3Objects2);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDcomprobar3Objects2Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDcomprobar3Objects2 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDcomprobar3Objects2.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDcomprobar3Objects2[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.palabra_95correcta1Code.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "pasar") >= 3;
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "palabra_correcta2", false);
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "pasar");
}}

}


};gdjs.palabra_95correcta1Code.eventsList12 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.eventsList8(runtimeScene);
}


{


gdjs.palabra_95correcta1Code.eventsList11(runtimeScene);
}


};gdjs.palabra_95correcta1Code.eventsList13 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.palabra_95correcta1Code.GDParejasObjects1);
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDParejasObjects1.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDParejasObjects1[i].setString("Parejas: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}}

}


};gdjs.palabra_95correcta1Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Parejas"), gdjs.palabra_95correcta1Code.GDParejasObjects1);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.palabra_95correcta1Code.GDParejasObjects1.length;i<l;++i) {
    if ( gdjs.palabra_95correcta1Code.GDParejasObjects1[i].getString() == "Parejas: 2" ) {
        gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = true;
        gdjs.palabra_95correcta1Code.GDParejasObjects1[k] = gdjs.palabra_95correcta1Code.GDParejasObjects1[i];
        ++k;
    }
}
gdjs.palabra_95correcta1Code.GDParejasObjects1.length = k;}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "p_nivel2", false);
}}

}


};gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDregresarObjects1Objects = Hashtable.newFrom({"regresar": gdjs.palabra_95correcta1Code.GDregresarObjects1});
gdjs.palabra_95correcta1Code.eventsList15 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "menu_semantica", false);
}}

}


};gdjs.palabra_95correcta1Code.eventsList16 = function(runtimeScene) {

{


gdjs.palabra_95correcta1Code.eventsList1(runtimeScene);
}


{


gdjs.palabra_95correcta1Code.eventsList5(runtimeScene);
}


{


gdjs.palabra_95correcta1Code.eventsList12(runtimeScene);
}


{


gdjs.palabra_95correcta1Code.eventsList13(runtimeScene);
}


{


gdjs.palabra_95correcta1Code.eventsList14(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("regresar"), gdjs.palabra_95correcta1Code.GDregresarObjects1);

gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = false;
{
gdjs.palabra_95correcta1Code.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.palabra_95correcta1Code.mapOfGDgdjs_46palabra_9595correcta1Code_46GDregresarObjects1Objects, runtimeScene, true, false);
}if (gdjs.palabra_95correcta1Code.condition0IsTrue_0.val) {
/* Reuse gdjs.palabra_95correcta1Code.GDregresarObjects1 */
{for(var i = 0, len = gdjs.palabra_95correcta1Code.GDregresarObjects1.length ;i < len;++i) {
    gdjs.palabra_95correcta1Code.GDregresarObjects1[i].setAnimationName("over");
}
}
{ //Subevents
gdjs.palabra_95correcta1Code.eventsList15(runtimeScene);} //End of subevents
}

}


};

gdjs.palabra_95correcta1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.palabra_95correcta1Code.GDpersonajeObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95R2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeDObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeDObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeDObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeDObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDpersonajeDObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDpersonaje1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDpersonaje1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDpersonaje1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDpersonaje1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDpersonaje1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDop1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDop1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDop1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDop1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDop1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDop1aObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDop1aObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDop1aObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDop1aObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDop1aObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDop2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDop2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDop2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDop2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDop2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDop2aObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDop2aObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDop2aObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDop2aObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDop2aObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobarObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobarObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobarObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobarObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobarObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDcomproselectObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDcomproselectObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDcomproselectObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDcomproselectObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDcomproselectObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar3Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar3Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar3Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar3Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDcomprobar3Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDpreguntaObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDpreguntaObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDpreguntaObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDpreguntaObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDpreguntaObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95L2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95r2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95K2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95l2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDCarta_95S2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDbloque1Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDbloque1Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDbloque1Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDbloque1Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDbloque1Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDbloque2Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDbloque2Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDbloque2Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDbloque2Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDbloque2Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDbloque3Objects1.length = 0;
gdjs.palabra_95correcta1Code.GDbloque3Objects2.length = 0;
gdjs.palabra_95correcta1Code.GDbloque3Objects3.length = 0;
gdjs.palabra_95correcta1Code.GDbloque3Objects4.length = 0;
gdjs.palabra_95correcta1Code.GDbloque3Objects5.length = 0;
gdjs.palabra_95correcta1Code.GDfondoObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDfondoObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDfondoObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDfondoObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDfondoObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDNivelObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDNivelObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDNivelObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDNivelObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDNivelObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDParejasObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDParejasObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDParejasObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDParejasObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDParejasObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDposicionObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDposicionObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDposicionObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDposicionObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDposicionObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDparticulasObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDparticulasObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDparticulasObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDparticulasObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDparticulasObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDnivelObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDnivelObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDnivelObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDnivelObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDnivelObjects5.length = 0;
gdjs.palabra_95correcta1Code.GDregresarObjects1.length = 0;
gdjs.palabra_95correcta1Code.GDregresarObjects2.length = 0;
gdjs.palabra_95correcta1Code.GDregresarObjects3.length = 0;
gdjs.palabra_95correcta1Code.GDregresarObjects4.length = 0;
gdjs.palabra_95correcta1Code.GDregresarObjects5.length = 0;

gdjs.palabra_95correcta1Code.eventsList16(runtimeScene);

return;

}

gdjs['palabra_95correcta1Code'] = gdjs.palabra_95correcta1Code;
